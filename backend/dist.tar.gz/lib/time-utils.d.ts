export declare function resolutionToMinutes(resolution: string): number;
export declare function resolutionToCron(resolution: string): string;
export declare function computeNextCandleClose(currentTime?: Date, resolution?: string): Date;
export declare function roundToIntervalBoundary(timestamp: Date, resolution?: string): Date;
export declare function formatIntervalKey(timestamp: Date, resolution?: string): string;
export declare function computeLockTTL(resolution: string, safetyMarginSeconds?: number): number;
export declare function validateExecutionTiming(scheduledTime: Date, actualTime: Date, maxDriftSeconds?: number): {
    isValid: boolean;
    driftSeconds: number;
};
export declare function getCandleIntervalRange(timestamp: Date, resolution?: string): {
    start: Date;
    end: Date;
};
export declare function logExecutionTiming(strategyId: string, resolution: string, scheduledTime: Date, actualStartTime: Date, executionDuration: number): void;
export interface CandleEvent {
    symbol: string;
    resolution: string;
    closeTime: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
}
export declare function isCandleCloseEvent(event: CandleEvent, now?: Date): boolean;
//# sourceMappingURL=time-utils.d.ts.map