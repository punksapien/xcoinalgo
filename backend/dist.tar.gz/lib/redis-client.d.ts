import Redis from 'ioredis';
export declare function getRedisClient(): Redis;
export declare function closeRedisClient(): Promise<void>;
export declare function checkRedisHealth(): Promise<boolean>;
export declare const redis: Redis;
//# sourceMappingURL=redis-client.d.ts.map