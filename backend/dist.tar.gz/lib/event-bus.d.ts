import type { CandleEvent } from './time-utils';
export interface EventMap {
    'candle.close': CandleEvent;
    'strategy.execution.start': {
        strategyId: string;
        interval: string;
    };
    'strategy.execution.complete': {
        strategyId: string;
        interval: string;
        success: boolean;
        duration: number;
    };
    'strategy.execution.error': {
        strategyId: string;
        interval: string;
        error: Error;
    };
    'subscription.created': {
        subscriptionId: string;
        strategyId: string;
        userId: string;
    };
    'subscription.cancelled': {
        subscriptionId: string;
        strategyId: string;
        userId: string;
    };
    'trade.created': {
        tradeId: string;
        subscriptionId: string;
        symbol: string;
    };
    'trade.filled': {
        tradeId: string;
        price: number;
        quantity: number;
    };
    'trade.closed': {
        tradeId: string;
        pnl: number;
    };
}
declare class TypedEventEmitter {
    private emitter;
    constructor();
    emit<K extends keyof EventMap>(event: K, data: EventMap[K]): void;
    on<K extends keyof EventMap>(event: K, listener: (data: EventMap[K]) => void | Promise<void>): void;
    once<K extends keyof EventMap>(event: K, listener: (data: EventMap[K]) => void | Promise<void>): void;
    off<K extends keyof EventMap>(event: K, listener: (data: EventMap[K]) => void | Promise<void>): void;
    removeAllListeners<K extends keyof EventMap>(event?: K): void;
    listenerCount<K extends keyof EventMap>(event: K): number;
}
export declare const eventBus: TypedEventEmitter;
export declare function waitForEvent<K extends keyof EventMap>(event: K, timeout?: number): Promise<EventMap[K]>;
export {};
//# sourceMappingURL=event-bus.d.ts.map