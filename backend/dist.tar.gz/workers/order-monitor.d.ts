export declare function startOrderMonitoring(): void;
export declare function triggerOrderMonitor(): Promise<void>;
declare const _default: {
    startOrderMonitoring: typeof startOrderMonitoring;
    triggerOrderMonitor: typeof triggerOrderMonitor;
};
export default _default;
//# sourceMappingURL=order-monitor.d.ts.map