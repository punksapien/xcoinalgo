#!/usr/bin/env ts-node
declare class StrategyScheduler {
    private scheduledJobs;
    private workerId;
    private isShuttingDown;
    constructor();
    initialize(): Promise<void>;
    scheduleCandle(symbol: string, resolution: string): Promise<void>;
    unscheduleCandle(symbol: string, resolution: string): Promise<void>;
    private executeCandle;
    private scheduleRefresh;
    getStatus(): {
        workerId: string;
        pid: number;
        scheduledJobs: number;
        candles: string[];
    };
    shutdown(): Promise<void>;
}
declare const scheduler: StrategyScheduler;
export { scheduler };
//# sourceMappingURL=strategy-scheduler.d.ts.map