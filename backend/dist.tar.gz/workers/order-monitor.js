"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startOrderMonitoring = startOrderMonitoring;
exports.triggerOrderMonitor = triggerOrderMonitor;
const node_cron_1 = __importDefault(require("node-cron"));
const order_manager_1 = require("../services/order-manager");
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('OrderMonitor');
function startOrderMonitoring() {
    logger.info('Starting order monitoring service...');
    node_cron_1.default.schedule('0 * * * * *', async () => {
        try {
            logger.debug('Running order monitor check...');
            await order_manager_1.orderManager.monitorAllOpenTrades();
        }
        catch (error) {
            logger.error('Order monitoring failed:', error);
        }
    });
    logger.info('✓ Order monitoring service started (runs every minute)');
}
async function triggerOrderMonitor() {
    logger.info('Manually triggering order monitor...');
    await order_manager_1.orderManager.monitorAllOpenTrades();
    logger.info('✓ Manual order monitor complete');
}
exports.default = {
    startOrderMonitoring,
    triggerOrderMonitor,
};
//# sourceMappingURL=order-monitor.js.map