#!/usr/bin/env ts-node
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduler = void 0;
const cron = __importStar(require("node-cron"));
const dotenv_1 = __importDefault(require("dotenv"));
const strategy_registry_1 = require("../services/strategy-execution/strategy-registry");
const execution_coordinator_1 = require("../services/strategy-execution/execution-coordinator");
const time_utils_1 = require("../lib/time-utils");
dotenv_1.default.config();
class StrategyScheduler {
    constructor() {
        this.scheduledJobs = new Map();
        this.isShuttingDown = false;
        this.workerId = process.env.WORKER_ID || `scheduler-${process.pid}`;
        console.log(`\n${'='.repeat(80)}`);
        console.log(`Strategy Scheduler Worker Started`);
        console.log(`Worker ID: ${this.workerId}`);
        console.log(`PID: ${process.pid}`);
        console.log(`${'='.repeat(80)}\n`);
    }
    async initialize() {
        try {
            console.log('Initializing strategy scheduler...');
            await strategy_registry_1.strategyRegistry.initialize();
            const activeCandles = await strategy_registry_1.strategyRegistry.getActiveCandles();
            console.log(`Found ${activeCandles.length} active candles to schedule`);
            for (const candle of activeCandles) {
                await this.scheduleCandle(candle.symbol, candle.resolution);
            }
            console.log(`\nScheduler initialized with ${this.scheduledJobs.size} scheduled jobs\n`);
            this.scheduleRefresh();
        }
        catch (error) {
            console.error('Failed to initialize scheduler:', error);
            throw error;
        }
    }
    async scheduleCandle(symbol, resolution) {
        const candleKey = `${symbol}:${resolution}`;
        if (this.scheduledJobs.has(candleKey)) {
            console.log(`Candle ${candleKey} already scheduled, skipping`);
            return;
        }
        try {
            const cronPattern = (0, time_utils_1.resolutionToCron)(resolution);
            console.log(`Scheduling ${candleKey} with cron: ${cronPattern}`);
            const job = cron.schedule(cronPattern, async () => {
                if (this.isShuttingDown) {
                    console.log('Scheduler is shutting down, skipping execution');
                    return;
                }
                await this.executeCandle(symbol, resolution);
            });
            this.scheduledJobs.set(candleKey, {
                symbol,
                resolution,
                cronPattern,
                job
            });
            console.log(`✓ Scheduled ${candleKey} successfully`);
        }
        catch (error) {
            console.error(`Failed to schedule ${candleKey}:`, error);
        }
    }
    async unscheduleCandle(symbol, resolution) {
        const candleKey = `${symbol}:${resolution}`;
        const scheduledJob = this.scheduledJobs.get(candleKey);
        if (!scheduledJob) {
            console.log(`Candle ${candleKey} not scheduled, nothing to unschedule`);
            return;
        }
        console.log(`Unscheduling ${candleKey}...`);
        scheduledJob.job.stop();
        this.scheduledJobs.delete(candleKey);
        console.log(`✓ Unscheduled ${candleKey} successfully`);
    }
    async executeCandle(symbol, resolution) {
        const candleKey = `${symbol}:${resolution}`;
        try {
            const scheduledTime = (0, time_utils_1.computeNextCandleClose)(new Date(), resolution);
            console.log(`\n${'─'.repeat(80)}\n` +
                `Executing strategies for ${candleKey} at ${scheduledTime.toISOString()}\n` +
                `${'─'.repeat(80)}`);
            await execution_coordinator_1.executionCoordinator.executeCandleStrategies(symbol, resolution, scheduledTime);
            console.log(`${'─'.repeat(80)}\n`);
        }
        catch (error) {
            console.error(`Error executing ${candleKey}:`, error);
        }
    }
    scheduleRefresh() {
        console.log('Scheduling periodic refresh every 5 minutes');
        cron.schedule('*/5 * * * *', async () => {
            if (this.isShuttingDown) {
                return;
            }
            console.log('\n📋 Refreshing schedules...');
            try {
                await strategy_registry_1.strategyRegistry.refreshCache();
                const activeCandles = await strategy_registry_1.strategyRegistry.getActiveCandles();
                const activeCandleKeys = new Set(activeCandles.map(c => `${c.symbol}:${c.resolution}`));
                const currentKeys = Array.from(this.scheduledJobs.keys());
                for (const key of currentKeys) {
                    if (!activeCandleKeys.has(key)) {
                        const [symbol, resolution] = key.split(':');
                        console.log(`Removing inactive schedule: ${key}`);
                        await this.unscheduleCandle(symbol, resolution);
                    }
                }
                for (const candle of activeCandles) {
                    const key = `${candle.symbol}:${candle.resolution}`;
                    if (!this.scheduledJobs.has(key)) {
                        console.log(`Adding new schedule: ${key}`);
                        await this.scheduleCandle(candle.symbol, candle.resolution);
                    }
                }
                console.log(`✓ Refresh complete. Active schedules: ${this.scheduledJobs.size}\n`);
            }
            catch (error) {
                console.error('Error refreshing schedules:', error);
            }
        });
    }
    getStatus() {
        return {
            workerId: this.workerId,
            pid: process.pid,
            scheduledJobs: this.scheduledJobs.size,
            candles: Array.from(this.scheduledJobs.keys())
        };
    }
    async shutdown() {
        if (this.isShuttingDown) {
            return;
        }
        this.isShuttingDown = true;
        console.log('\n🛑 Shutting down strategy scheduler...');
        for (const [candleKey, scheduledJob] of this.scheduledJobs) {
            console.log(`Stopping job for ${candleKey}...`);
            scheduledJob.job.stop();
        }
        this.scheduledJobs.clear();
        console.log('✓ All jobs stopped. Shutdown complete.\n');
    }
}
const scheduler = new StrategyScheduler();
exports.scheduler = scheduler;
scheduler.initialize().catch((error) => {
    console.error('Fatal error initializing scheduler:', error);
    process.exit(1);
});
process.on('SIGTERM', async () => {
    console.log('\nReceived SIGTERM signal');
    await scheduler.shutdown();
    process.exit(0);
});
process.on('SIGINT', async () => {
    console.log('\nReceived SIGINT signal');
    await scheduler.shutdown();
    process.exit(0);
});
process.on('uncaughtException', (error) => {
    console.error('Uncaught exception:', error);
    scheduler.shutdown().then(() => {
        process.exit(1);
    });
});
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled rejection at:', promise, 'reason:', reason);
    scheduler.shutdown().then(() => {
        process.exit(1);
    });
});
setInterval(() => {
    const status = scheduler.getStatus();
    console.log(`\n💓 Scheduler Heartbeat: ${status.scheduledJobs} jobs running | ` +
        `Worker: ${status.workerId} | PID: ${status.pid}`);
}, 60000);
//# sourceMappingURL=strategy-scheduler.js.map