#!/usr/bin/env ts-node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const backtest_engine_1 = require("../services/backtest-engine");
const logger_1 = require("../utils/logger");
const prisma = new client_1.PrismaClient();
const logger = new logger_1.Logger('BacktestScript');
async function main() {
    try {
        const strategyId = process.argv[2];
        if (!strategyId) {
            logger.error('Usage: npx ts-node src/scripts/backtest-and-update-strategy.ts <strategyId>');
            process.exit(1);
        }
        logger.info(`Starting backtest for strategy: ${strategyId}`);
        const strategy = await prisma.strategy.findUnique({
            where: { id: strategyId },
            include: {
                versions: {
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                },
            },
        });
        if (!strategy) {
            logger.error(`Strategy not found: ${strategyId}`);
            process.exit(1);
        }
        logger.info(`Found strategy: ${strategy.name} (${strategy.code})`);
        const executionConfig = strategy.executionConfig;
        if (!executionConfig || !executionConfig.symbol || !executionConfig.resolution) {
            logger.error('Strategy execution config is missing required fields (symbol, resolution)');
            process.exit(1);
        }
        const symbol = executionConfig.symbol;
        const resolution = executionConfig.resolution;
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - 30);
        const initialCapital = 10000;
        const riskPerTrade = 0.02;
        const leverage = 10;
        const commission = 0.0004;
        logger.info(`Backtest parameters:`);
        logger.info(`  Symbol: ${symbol}`);
        logger.info(`  Resolution: ${resolution} minutes`);
        logger.info(`  Period: ${startDate.toISOString()} to ${endDate.toISOString()}`);
        logger.info(`  Initial Capital: $${initialCapital}`);
        logger.info(`  Risk per Trade: ${riskPerTrade * 100}%`);
        logger.info(`  Leverage: ${leverage}x`);
        logger.info('Running backtest... This may take a few minutes.');
        const backtestResult = await backtest_engine_1.backtestEngine.runBacktest({
            strategyId,
            symbol,
            resolution: `${resolution}m`,
            startDate,
            endDate,
            initialCapital,
            riskPerTrade,
            leverage,
            commission,
        });
        logger.info('Backtest completed successfully!');
        logger.info('Results:');
        logger.info(`  Total Trades: ${backtestResult.metrics.totalTrades}`);
        logger.info(`  Win Rate: ${backtestResult.metrics.winRate.toFixed(2)}%`);
        logger.info(`  ROI: ${backtestResult.metrics.totalPnlPct.toFixed(2)}%`);
        logger.info(`  Max Drawdown: ${backtestResult.metrics.maxDrawdownPct.toFixed(2)}%`);
        logger.info(`  Sharpe Ratio: ${backtestResult.metrics.sharpeRatio.toFixed(2)}`);
        logger.info(`  Profit Factor: ${backtestResult.metrics.profitFactor.toFixed(2)}`);
        const riskReward = backtestResult.metrics.avgLoss > 0
            ? backtestResult.metrics.avgWin / backtestResult.metrics.avgLoss
            : 0;
        logger.info('Updating strategy metrics in database...');
        await prisma.strategy.update({
            where: { id: strategyId },
            data: {
                winRate: backtestResult.metrics.winRate,
                roi: backtestResult.metrics.totalPnlPct,
                maxDrawdown: backtestResult.metrics.maxDrawdownPct,
                sharpeRatio: backtestResult.metrics.sharpeRatio,
                profitFactor: backtestResult.metrics.profitFactor,
                totalTrades: backtestResult.metrics.totalTrades,
                riskReward: riskReward,
                avgTradeReturn: backtestResult.metrics.totalTrades > 0
                    ? backtestResult.metrics.totalPnl / backtestResult.metrics.totalTrades
                    : 0,
                updatedAt: new Date(),
            },
        });
        logger.info('✅ Strategy metrics updated successfully!');
        logger.info('The strategy dashboard will now display these backtested metrics.');
        process.exit(0);
    }
    catch (error) {
        logger.error('Backtest script failed:', error);
        process.exit(1);
    }
    finally {
        await prisma.$disconnect();
    }
}
process.on('unhandledRejection', (error) => {
    logger.error('Unhandled rejection:', error);
    process.exit(1);
});
main();
//# sourceMappingURL=backtest-and-update-strategy.js.map