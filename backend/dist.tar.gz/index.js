"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const express_session_1 = __importDefault(require("express-session"));
const passport_1 = __importDefault(require("passport"));
const dotenv_1 = __importDefault(require("dotenv"));
const auth_1 = require("./routes/auth");
const broker_1 = require("./routes/broker");
const strategy_upload_1 = require("./routes/strategy-upload");
const bot_1 = require("./routes/bot");
const webhooks_1 = require("./routes/webhooks");
const positions_1 = require("./routes/positions");
const strategy_execution_1 = require("./routes/strategy-execution");
const backtest_1 = require("./routes/backtest");
const backtest_progress_1 = require("./routes/backtest-progress");
const settings_1 = require("./routes/settings");
const marketplace_1 = require("./routes/marketplace");
const market_data_1 = require("./routes/market-data");
const logs_1 = require("./routes/logs");
const execution_audit_1 = require("./routes/execution-audit");
const errorHandler_1 = require("./middleware/errorHandler");
const strategyExecutor_1 = require("./services/strategyExecutor");
const order_monitor_1 = require("./workers/order-monitor");
require("./config/passport");
dotenv_1.default.config();
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3001;
app.use((0, helmet_1.default)({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            connectSrc: ["'self'", "https://accounts.google.com", "https://oauth2.googleapis.com"],
            frameSrc: ["'self'", "https://accounts.google.com"],
            scriptSrc: ["'self'", "'unsafe-inline'", "https://accounts.google.com"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://accounts.google.com"],
        },
    },
}));
const allowedOrigins = [
    process.env.FRONTEND_URL || 'http://localhost:3000',
    'https://xcoinalgo.com',
    'https://www.xcoinalgo.com',
    'http://localhost:3000'
];
app.use((0, cors_1.default)({
    origin: (origin, callback) => {
        if (!origin)
            return callback(null, true);
        if (allowedOrigins.indexOf(origin) !== -1) {
            callback(null, true);
        }
        else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));
app.use((0, express_session_1.default)({
    secret: process.env.SESSION_SECRET || 'xcoinalgo-session-secret-key-2024',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        maxAge: 24 * 60 * 60 * 1000
    }
}));
app.use(passport_1.default.initialize());
app.use(passport_1.default.session());
app.use(express_1.default.json({ limit: '10mb' }));
app.use(express_1.default.urlencoded({ extended: true }));
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV
    });
});
app.use('/api/auth', auth_1.authRoutes);
app.use('/api/broker', broker_1.brokerRoutes);
app.use('/api/strategy-upload', strategy_upload_1.strategyUploadRoutes);
app.use('/api/bot', bot_1.botRoutes);
app.use('/api/webhooks', webhooks_1.webhookRoutes);
app.use('/api/positions', positions_1.positionsRoutes);
app.use('/api/strategies', strategy_execution_1.strategyExecutionRoutes);
app.use('/api/strategies', backtest_progress_1.backtestProgressRoutes);
app.use('/api/backtest', backtest_1.backtestRoutes);
app.use('/api/settings', settings_1.settingsRoutes);
app.use('/api/logs', logs_1.logsRoutes);
app.use('/api/execution/audit', execution_audit_1.executionAuditRoutes);
app.use('/api/marketplace', marketplace_1.marketplaceRoutes);
app.use('/api/market-data', market_data_1.marketDataRoutes);
app.use(errorHandler_1.errorHandler);
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📊 Environment: ${process.env.NODE_ENV}`);
    console.log(`🔒 CORS enabled for: ${process.env.FRONTEND_URL}`);
    (0, strategyExecutor_1.startHealthCheckMonitoring)();
    console.log(`💓 Strategy executor health monitoring started`);
    (0, order_monitor_1.startOrderMonitoring)();
    console.log(`📊 Order monitoring service started`);
});
exports.default = app;
//# sourceMappingURL=index.js.map