export interface EnvironmentInfo {
    strategyId: string;
    environmentPath: string;
    pythonPath: string;
    createdAt: Date;
    status: 'ready' | 'creating' | 'error';
}
export declare class StrategyEnvironmentManager {
    private environmentCache;
    private uvPath;
    constructor();
    private findUvBinary;
    private initializeBaseDirectory;
    private getEnvironmentPath;
    private getPythonPath;
    checkUvInstalled(): Promise<boolean>;
    environmentExists(strategyId: string): Promise<boolean>;
    createEnvironment(strategyId: string): Promise<EnvironmentInfo>;
    getEnvironmentInfo(strategyId: string): Promise<EnvironmentInfo>;
    deleteEnvironment(strategyId: string): Promise<void>;
    executeInEnvironment(strategyId: string, scriptPath: string, args?: string[], env?: Record<string, string>): Promise<{
        stdout: string;
        stderr: string;
    }>;
    listEnvironments(): Promise<string[]>;
    cleanupAllEnvironments(): Promise<void>;
    private runCommand;
}
export declare const strategyEnvironmentManager: StrategyEnvironmentManager;
//# sourceMappingURL=strategy-environment-manager.d.ts.map