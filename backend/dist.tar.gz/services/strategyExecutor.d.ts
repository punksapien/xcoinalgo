export interface StrategyConfig {
    name: string;
    code: string;
    author: string;
    description?: string;
    leverage: number;
    risk_per_trade: number;
    pair: string;
    margin_currency: string;
    resolution: string;
    lookback_period: number;
    sl_atr_multiplier: number;
    tp_atr_multiplier: number;
    max_positions: number;
    max_daily_loss: number;
    custom_params?: Record<string, any>;
}
export interface DeployStrategyRequest {
    strategy_id: string;
    user_id: string;
    deployment_id: string;
    strategy_code: string;
    config: StrategyConfig;
    execution_interval: number;
    api_key: string;
    api_secret: string;
    auto_start: boolean;
}
export interface StrategyExecutionStats {
    total_executions: number;
    successful_executions: number;
    failed_executions: number;
    avg_execution_time: number;
    last_execution_at?: string;
    last_error?: string;
}
export declare class StrategyExecutorClient {
    private client;
    private baseUrl;
    constructor(baseUrl?: string);
    healthCheck(): Promise<boolean>;
    deployStrategy(deploymentId: string): Promise<{
        success: boolean;
        strategy_id: string;
        message: string;
    }>;
    stopStrategy(deploymentId: string): Promise<void>;
    deleteStrategy(deploymentId: string): Promise<void>;
    getStrategyStatus(deploymentId: string): Promise<{
        status: string;
        stats: StrategyExecutionStats;
    } | null>;
    syncDeploymentStatus(deploymentId: string): Promise<void>;
    healthCheckDeployments(): Promise<void>;
}
export declare const strategyExecutor: StrategyExecutorClient;
export declare function startHealthCheckMonitoring(): void;
//# sourceMappingURL=strategyExecutor.d.ts.map