import { EventEmitter } from 'events';
export interface BacktestProgress {
    strategyId: string;
    stage: 'fetching_data' | 'data_fetched' | 'running_backtest' | 'calculating_metrics' | 'complete' | 'error';
    progress: number;
    message: string;
    totalCandles?: number;
    fetchDuration?: number;
    backtestDuration?: number;
    totalDuration?: number;
    error?: string;
    metrics?: any;
    trades?: any[];
    totalTrades?: number;
}
export declare class BacktestProgressTracker extends EventEmitter {
    private progressMap;
    updateProgress(strategyId: string, update: Partial<BacktestProgress>): void;
    getProgress(strategyId: string): BacktestProgress | null;
    markComplete(strategyId: string, result: {
        metrics?: any;
        trades?: any[];
        totalTrades?: number;
    }): void;
    markError(strategyId: string, error: string): void;
    clearProgress(strategyId: string): void;
    getActiveBacktests(): BacktestProgress[];
    subscribeToStrategy(strategyId: string, callback: (progress: BacktestProgress) => void): () => void;
}
export declare const backtestProgressTracker: BacktestProgressTracker;
//# sourceMappingURL=backtest-progress-tracker.d.ts.map