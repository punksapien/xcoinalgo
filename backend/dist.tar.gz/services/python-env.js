"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uvEnvManager = exports.UvEnvManager = void 0;
const crypto_1 = __importDefault(require("crypto"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const child_process_1 = require("child_process");
class UvEnvManager {
    constructor(cacheRoot) {
        this.cacheRoot = cacheRoot || path_1.default.join(process.cwd(), '.cache', 'xcoin', 'uv');
    }
    extractPythonVersion(requirements) {
        const lines = requirements.split('\n');
        for (const line of lines) {
            const match = line.match(/^#\s*python\s*([>=<]+)\s*(\d+\.\d+(?:\.\d+)?)/i);
            if (match) {
                return match[2];
            }
        }
        return null;
    }
    computeRequirementsHash(requirements, pythonVersion) {
        const pyVer = pythonVersion || this.extractPythonVersion(requirements) || 'system';
        const h = crypto_1.default.createHash('sha256');
        h.update(requirements.trim());
        h.update('|python:');
        h.update(pyVer);
        return h.digest('hex').slice(0, 16);
    }
    ensureDir(dir) {
        if (!fs_1.default.existsSync(dir)) {
            fs_1.default.mkdirSync(dir, { recursive: true });
        }
    }
    hasUv() {
        const uvPaths = [
            path_1.default.join(process.env.HOME || '/home/ubuntu', '.local/bin/uv'),
            path_1.default.join(process.env.HOME || '/home/ubuntu', '.cargo/bin/uv'),
            'uv'
        ];
        for (const uvPath of uvPaths) {
            if (fs_1.default.existsSync(uvPath)) {
                return true;
            }
        }
        const which = (0, child_process_1.spawnSync)(process.platform === 'win32' ? 'where' : 'which', ['uv'], { encoding: 'utf-8' });
        return which.status === 0;
    }
    ensureEnv(requirements) {
        const pythonVersion = this.extractPythonVersion(requirements);
        const hash = this.computeRequirementsHash(requirements);
        const envDir = path_1.default.join(this.cacheRoot, hash);
        const pythonBin = process.platform === 'win32'
            ? path_1.default.join(envDir, 'Scripts', 'python.exe')
            : path_1.default.join(envDir, 'bin', 'python');
        this.ensureDir(envDir);
        const marker = path_1.default.join(envDir, '.ready');
        if (fs_1.default.existsSync(marker) && fs_1.default.existsSync(pythonBin)) {
            return { pythonPath: pythonBin, created: false };
        }
        if (this.hasUv()) {
            const uvCmd = fs_1.default.existsSync(path_1.default.join(process.env.HOME || '/home/ubuntu', '.local/bin/uv'))
                ? path_1.default.join(process.env.HOME || '/home/ubuntu', '.local/bin/uv')
                : fs_1.default.existsSync(path_1.default.join(process.env.HOME || '/home/ubuntu', '.cargo/bin/uv'))
                    ? path_1.default.join(process.env.HOME || '/home/ubuntu', '.cargo/bin/uv')
                    : 'uv';
            const venvArgs = pythonVersion
                ? ['venv', '--python', pythonVersion, envDir]
                : ['venv', envDir];
            const venv = (0, child_process_1.spawnSync)(uvCmd, venvArgs, { stdio: 'inherit' });
            if (venv.status === 0) {
                const reqFile = path_1.default.join(envDir, 'requirements.txt');
                fs_1.default.writeFileSync(reqFile, requirements);
                const pip = (0, child_process_1.spawnSync)(uvCmd, ['pip', 'install', '--python', pythonBin, '-r', reqFile], { stdio: 'inherit' });
                if (pip.status === 0 && fs_1.default.existsSync(pythonBin)) {
                    fs_1.default.writeFileSync(marker, new Date().toISOString());
                    return { pythonPath: pythonBin, created: true };
                }
            }
        }
        const py = process.env.PYTHON || 'python3';
        const create = (0, child_process_1.spawnSync)(py, ['-m', 'venv', envDir], { stdio: 'inherit' });
        if (create.status !== 0) {
            return { pythonPath: 'python3', created: false };
        }
        const pipBin = process.platform === 'win32'
            ? path_1.default.join(envDir, 'Scripts', 'pip')
            : path_1.default.join(envDir, 'bin', 'pip');
        const reqFile = path_1.default.join(envDir, 'requirements.txt');
        fs_1.default.writeFileSync(reqFile, requirements);
        (0, child_process_1.spawnSync)(pipBin, ['install', '--upgrade', 'pip', 'setuptools', 'wheel'], { stdio: 'inherit' });
        const install = (0, child_process_1.spawnSync)(pipBin, ['install', '-r', reqFile], { stdio: 'inherit' });
        if (install.status !== 0) {
            return { pythonPath: 'python3', created: false };
        }
        fs_1.default.writeFileSync(marker, new Date().toISOString());
        return { pythonPath: pythonBin, created: true };
    }
}
exports.UvEnvManager = UvEnvManager;
exports.uvEnvManager = new UvEnvManager();
//# sourceMappingURL=python-env.js.map