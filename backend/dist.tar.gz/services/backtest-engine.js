"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.backtestEngine = void 0;
exports.getBacktestStatus = getBacktestStatus;
const client_1 = require("@prisma/client");
const coindcx_client_1 = __importDefault(require("./coindcx-client"));
const symbol_validator_1 = require("./symbol-validator");
const logger_1 = require("../utils/logger");
const child_process_1 = require("child_process");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const os_1 = __importDefault(require("os"));
const prisma = new client_1.PrismaClient();
const logger = new logger_1.Logger('BacktestEngine');
const backtestStatus = {};
function setBacktestStatus(strategyId, update) {
    const prev = backtestStatus[strategyId] || { stage: 'NO_RUN', progress: 0, message: 'No active backtest' };
    backtestStatus[strategyId] = { ...prev, ...update };
}
function getBacktestStatus(strategyId) {
    return backtestStatus[strategyId] || { stage: 'NO_RUN', progress: 0, message: 'No active backtest' };
}
class BacktestEngine {
    async runBacktest(config) {
        const startTime = Date.now();
        logger.info(`Starting backtest for strategy ${config.strategyId}`);
        logger.info(`Period: ${config.startDate.toISOString()} to ${config.endDate.toISOString()}`);
        logger.info(`Market: ${config.symbol} ${config.resolution}`);
        setBacktestStatus(config.strategyId, { stage: 'FETCHING', progress: 10, startedAt: startTime, message: `Preparing data for ${config.symbol} ${config.resolution}` });
        try {
            const strategy = await prisma.strategy.findUnique({
                where: { id: config.strategyId },
                include: {
                    versions: {
                        orderBy: { createdAt: 'desc' },
                        take: 1,
                        select: { version: true, strategyCode: true, requirements: true, configData: true }
                    },
                },
            });
            if (!strategy) {
                throw new Error(`Strategy ${config.strategyId} not found`);
            }
            if (!strategy.versions || strategy.versions.length === 0) {
                throw new Error(`Strategy ${config.strategyId} has no uploaded code versions`);
            }
            const latestVersion = strategy.versions[0];
            const strategyCode = latestVersion.strategyCode;
            if (!strategyCode) {
                throw new Error(`Strategy ${config.strategyId} version ${latestVersion.version} has no code`);
            }
            logger.info(`Using strategy version ${latestVersion.version} (${strategyCode.length} bytes)`);
            const historicalData = await this.fetchHistoricalData(config.symbol, config.resolution, config.startDate, config.endDate);
            logger.info(`Fetched ${historicalData.length} candles for backtesting`);
            setBacktestStatus(config.strategyId, { stage: 'RUNNING', progress: 40, message: `Running backtest (${historicalData.length} candles)` });
            logger.info('Running batch backtest (single-pass processing)...');
            const batchResult = await this.executeBatchBacktest(strategyCode, historicalData, config);
            if (!batchResult.success) {
                setBacktestStatus(config.strategyId, { stage: 'FAILED', progress: 100, error: batchResult.error, endedAt: Date.now() });
                throw new Error(`Batch backtest failed: ${batchResult.error}`);
            }
            const trades = batchResult.trades.map((trade) => ({
                entryTime: new Date(trade.entry_time),
                exitTime: new Date(trade.exit_time),
                side: trade.side,
                entryPrice: trade.entry_price,
                exitPrice: trade.exit_price,
                quantity: trade.quantity,
                pnl: trade.pnl,
                pnlPct: trade.pnl_pct,
                commission: trade.commission,
                reason: trade.reason,
            }));
            const equityCurve = batchResult.equity_curve.map((point) => ({
                time: new Date(point.timestamp || point.time),
                equity: point.equity,
                drawdown: point.drawdown || 0,
            }));
            const pythonMetrics = batchResult.metrics;
            setBacktestStatus(config.strategyId, { stage: 'SAVING', progress: 80, message: 'Saving results' });
            const metrics = {
                totalTrades: pythonMetrics.total_trades || pythonMetrics.totalTrades || 0,
                winningTrades: pythonMetrics.winning_trades || pythonMetrics.winningTrades || 0,
                losingTrades: pythonMetrics.losing_trades || pythonMetrics.losingTrades || 0,
                winRate: pythonMetrics.win_rate ?? pythonMetrics.winRate ?? 0,
                totalPnl: pythonMetrics.total_pnl ?? pythonMetrics.totalPnl ?? 0,
                totalPnlPct: pythonMetrics.total_pnl_pct ?? pythonMetrics.totalPnlPct ?? 0,
                avgWin: trades.filter(t => t.pnl > 0).reduce((sum, t) => sum + t.pnl, 0) / Math.max(1, pythonMetrics.winning_trades || pythonMetrics.winningTrades || 0),
                avgLoss: Math.abs(trades.filter(t => t.pnl < 0).reduce((sum, t) => sum + t.pnl, 0)) / Math.max(1, pythonMetrics.losing_trades || pythonMetrics.losingTrades || 0),
                largestWin: trades.length > 0 ? Math.max(...trades.filter(t => t.pnl > 0).map(t => t.pnl), 0) : 0,
                largestLoss: trades.length > 0 ? Math.min(...trades.filter(t => t.pnl < 0).map(t => t.pnl), 0) : 0,
                profitFactor: pythonMetrics.profit_factor ?? pythonMetrics.profitFactor ?? 0,
                sharpeRatio: pythonMetrics.sharpe_ratio ?? pythonMetrics.sharpeRatio ?? 0,
                maxDrawdown: pythonMetrics.max_drawdown ?? pythonMetrics.maxDrawdown ?? 0,
                maxDrawdownPct: pythonMetrics.max_drawdown_pct ?? pythonMetrics.maxDrawdownPct ?? 0,
                avgTradeDuration: trades.length > 0
                    ? trades.reduce((sum, t) => sum + (t.exitTime.getTime() - t.entryTime.getTime()), 0) / trades.length / 60000
                    : 0,
                totalCommission: trades.reduce((sum, t) => sum + t.commission, 0),
                netPnl: pythonMetrics.total_pnl ?? pythonMetrics.totalPnl ?? 0,
                finalCapital: pythonMetrics.final_capital ?? pythonMetrics.finalCapital ?? (pythonMetrics.total_pnl ?? pythonMetrics.totalPnl ?? 0) + config.initialCapital,
            };
            logger.info(`Batch backtest completed: ${trades.length} trades, ${metrics.winRate.toFixed(2)}% win rate`);
            const result = {
                config,
                trades,
                metrics,
                equityCurve,
                executionTime: Date.now() - startTime,
            };
            await this.storeBacktestResult(config.strategyId, result);
            logger.info(`Backtest completed in ${result.executionTime}ms`);
            setBacktestStatus(config.strategyId, { stage: 'DONE', progress: 100, endedAt: Date.now(), message: 'Completed' });
            logger.info(`Total Trades: ${metrics.totalTrades}, Win Rate: ${metrics.winRate.toFixed(2)}%`);
            logger.info(`Total P&L: ${metrics.totalPnl.toFixed(2)} (${metrics.totalPnlPct.toFixed(2)}%)`);
            logger.info(`Sharpe Ratio: ${metrics.sharpeRatio.toFixed(2)}, Max Drawdown: ${metrics.maxDrawdownPct.toFixed(2)}%`);
            return result;
        }
        catch (error) {
            logger.error('Backtest failed:', error);
            setBacktestStatus(config.strategyId, { stage: 'FAILED', progress: 100, error: error instanceof Error ? error.message : String(error), endedAt: Date.now() });
            throw error;
        }
    }
    mapResolution(resolution) {
        const mapping = {
            '1m': '1',
            '5m': '5',
            '15m': '15',
            '30m': '30',
            '1h': '60',
            '2h': '120',
            '4h': '240',
            '6h': '360',
            '8h': '480',
            '1d': '1D',
            '1w': '1W',
            '1M': '1M',
        };
        return mapping[resolution] || resolution;
    }
    async fetchHistoricalData(symbol, resolution, startDate, endDate) {
        const validation = await symbol_validator_1.symbolValidator.validateSymbol(symbol);
        if (!validation.isValid) {
            const suggestions = validation.suggestions.slice(0, 3);
            const suggestionText = suggestions.length > 0
                ? `Did you mean: ${suggestions.join(', ')}?`
                : 'Please check CoinDCX for available symbols.';
            throw new Error(`Symbol "${symbol}" not found on CoinDCX. ${suggestionText}`);
        }
        logger.info(`Symbol validated: ${validation.normalized} (${validation.type})`);
        const validatedSymbol = validation.normalized;
        const isFutures = validation.type === 'futures';
        if (isFutures) {
            logger.info(`Fetching futures data for ${validatedSymbol} from ${startDate.toISOString()} to ${endDate.toISOString()}`);
            const fromTimestamp = Math.floor(startDate.getTime() / 1000);
            const toTimestamp = Math.floor(endDate.getTime() / 1000);
            const apiResolution = this.mapResolution(resolution);
            const candles = await coindcx_client_1.default.getFuturesCandles(validatedSymbol, fromTimestamp, toTimestamp, apiResolution);
            logger.info(`Fetched ${candles.length} futures candles for ${validatedSymbol}`);
            if (candles.length === 0) {
                const errorMsg = `No historical data available for ${validatedSymbol}. ` +
                    `Please verify: (1) Symbol exists on CoinDCX, (2) Has trading history, (3) Date range contains data. ` +
                    `API params: from=${new Date(fromTimestamp * 1000).toISOString()}, to=${new Date(toTimestamp * 1000).toISOString()}, resolution=${apiResolution}`;
                logger.error(errorMsg);
                throw new Error(errorMsg);
            }
            return candles;
        }
        else {
            logger.info(`Fetching spot data for ${validatedSymbol}`);
            const market = coindcx_client_1.default.normalizeMarket(validatedSymbol) + 'INR';
            const candles = await coindcx_client_1.default.getHistoricalCandles(market, resolution, 1000);
            const filtered = candles.filter(candle => {
                const candleTime = new Date(candle.time);
                return candleTime >= startDate && candleTime <= endDate;
            });
            logger.info(`Fetched ${filtered.length} spot candles for ${validatedSymbol}`);
            if (filtered.length === 0) {
                const errorMsg = `No historical data available for ${validatedSymbol}. ` +
                    `Please verify: (1) Symbol exists on CoinDCX, (2) Has trading history in date range. ` +
                    `Date range: ${startDate.toISOString()} to ${endDate.toISOString()}`;
                logger.error(errorMsg);
                throw new Error(errorMsg);
            }
            return filtered;
        }
    }
    async executeBatchBacktest(strategyCode, historicalData, config) {
        return new Promise(async (resolve, reject) => {
            const pythonScriptPath = path_1.default.join(__dirname, '../../python/batch_backtest.py');
            const input = JSON.stringify({
                strategy_code: strategyCode,
                historical_data: historicalData,
                config: {
                    symbol: config.symbol,
                    resolution: config.resolution,
                    lookback_period: 200,
                },
                initial_capital: config.initialCapital,
                risk_per_trade: config.riskPerTrade,
                leverage: config.leverage,
                commission: config.commission,
            });
            const tempFilePath = path_1.default.join(os_1.default.tmpdir(), `backtest-${Date.now()}-${Math.random().toString(36).substring(7)}.json`);
            fs_1.default.writeFileSync(tempFilePath, input);
            logger.info(`Wrote ${input.length} bytes to temp file: ${tempFilePath}`);
            let pythonCmd = 'python3';
            try {
                const strat = await prisma.strategy.findUnique({
                    where: { id: config.strategyId },
                    include: { versions: { orderBy: { createdAt: 'desc' }, take: 1 } }
                });
                const ver = strat?.versions?.[0];
                let reqString = (ver?.requirements || '').trim();
                if (!reqString || reqString.length === 0) {
                    const deps = ver?.configData?.dependencies;
                    if (Array.isArray(deps) && deps.length > 0) {
                        reqString = deps.join('\n');
                        logger.info(`Derived requirements from config.dependencies (${deps.length} packages)`);
                    }
                }
                if (reqString && reqString.trim().length > 0) {
                    const { uvEnvManager } = await Promise.resolve().then(() => __importStar(require('./python-env')));
                    const env = uvEnvManager.ensureEnv(reqString);
                    pythonCmd = env.pythonPath || pythonCmd;
                    logger.info(`Using python interpreter: ${pythonCmd}`);
                }
                else {
                    logger.info('No requirements provided; using system python3');
                }
            }
            catch (e) {
                logger.warn(`UV env setup failed or skipped: ${e}`);
            }
            const pythonProcess = (0, child_process_1.spawn)(pythonCmd, [pythonScriptPath, tempFilePath], {
                env: { ...process.env },
            });
            let stdout = '';
            let stderr = '';
            pythonProcess.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            pythonProcess.stderr.on('data', (data) => {
                stderr += data.toString();
            });
            pythonProcess.on('close', (code) => {
                try {
                    fs_1.default.unlinkSync(tempFilePath);
                }
                catch (e) {
                    logger.warn(`Failed to delete temp file ${tempFilePath}: ${e}`);
                }
                if (code !== 0) {
                    logger.error(`Batch backtest failed with code ${code}`);
                    logger.error(`stderr: ${stderr}`);
                    resolve({
                        success: false,
                        error: `Python process exited with code ${code}${stderr ? `: ${stderr.split('\n').slice(-5).join(' | ')}` : ''}`,
                        trades: [],
                        metrics: {},
                    });
                    return;
                }
                try {
                    const result = JSON.parse(stdout);
                    resolve(result);
                }
                catch (error) {
                    logger.error(`Failed to parse batch backtest result: ${error}`);
                    logger.error(`stdout: ${stdout}`);
                    resolve({
                        success: false,
                        error: `Failed to parse Python output: ${error}`,
                        trades: [],
                        metrics: {},
                    });
                }
            });
            setTimeout(() => {
                pythonProcess.kill();
                try {
                    fs_1.default.unlinkSync(tempFilePath);
                }
                catch (e) {
                }
                resolve({
                    success: false,
                    error: 'Batch backtest timed out after 10 minutes',
                    trades: [],
                    metrics: {},
                });
            }, 600000);
        });
    }
    async executeStrategyOnCandle(strategyCode, historicalData, config) {
        return new Promise((resolve) => {
            const pythonScriptPath = path_1.default.join(__dirname, '../../python/strategy_runner.py');
            const input = JSON.stringify({
                strategy_code: strategyCode,
                historical_data: historicalData,
                config: {
                    symbol: config.symbol,
                    resolution: config.resolution,
                },
            });
            const pythonProcess = (0, child_process_1.spawn)('python3', [pythonScriptPath], {
                env: { ...process.env },
            });
            let stdout = '';
            let stderr = '';
            pythonProcess.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            pythonProcess.stderr.on('data', (data) => {
                stderr += data.toString();
            });
            pythonProcess.on('close', (code) => {
                if (code !== 0) {
                    resolve(null);
                    return;
                }
                try {
                    const result = JSON.parse(stdout);
                    resolve(result.signal || null);
                }
                catch (error) {
                    resolve(null);
                }
            });
            pythonProcess.stdin.write(input);
            pythonProcess.stdin.end();
            setTimeout(() => {
                pythonProcess.kill();
                resolve(null);
            }, 5000);
        });
    }
    shouldExitPosition(position, currentCandle, signal) {
        if (position.stopLoss) {
            if (position.side === 'LONG' && currentCandle.low <= position.stopLoss) {
                return { should: true, reason: 'STOP_LOSS' };
            }
            if (position.side === 'SHORT' && currentCandle.high >= position.stopLoss) {
                return { should: true, reason: 'STOP_LOSS' };
            }
        }
        if (position.takeProfit) {
            if (position.side === 'LONG' && currentCandle.high >= position.takeProfit) {
                return { should: true, reason: 'TAKE_PROFIT' };
            }
            if (position.side === 'SHORT' && currentCandle.low <= position.takeProfit) {
                return { should: true, reason: 'TAKE_PROFIT' };
            }
        }
        if ((position.side === 'LONG' && (signal.signal === 'EXIT_LONG' || signal.signal === 'SHORT')) ||
            (position.side === 'SHORT' && (signal.signal === 'EXIT_SHORT' || signal.signal === 'LONG'))) {
            return { should: true, reason: 'SIGNAL' };
        }
        return null;
    }
    calculatePnl(side, entryPrice, exitPrice, quantity) {
        if (side === 'LONG') {
            return (exitPrice - entryPrice) * quantity;
        }
        else {
            return (entryPrice - exitPrice) * quantity;
        }
    }
    calculatePositionSize(capital, riskPerTrade, entryPrice, stopLoss, leverage = 1) {
        if (!stopLoss) {
            const riskAmount = capital * riskPerTrade;
            return (riskAmount * leverage) / entryPrice;
        }
        const riskAmount = capital * riskPerTrade;
        const stopLossDistance = Math.abs(entryPrice - stopLoss);
        const riskPerUnit = stopLossDistance;
        if (riskPerUnit === 0) {
            return 0;
        }
        return (riskAmount / riskPerUnit) * leverage;
    }
    calculateMetrics(trades, initialCapital, finalCapital, equityCurve) {
        const totalTrades = trades.length;
        const winningTrades = trades.filter(t => t.pnl > 0).length;
        const losingTrades = trades.filter(t => t.pnl < 0).length;
        const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;
        const totalPnl = finalCapital - initialCapital;
        const totalPnlPct = (totalPnl / initialCapital) * 100;
        const wins = trades.filter(t => t.pnl > 0);
        const losses = trades.filter(t => t.pnl < 0);
        const avgWin = wins.length > 0 ? wins.reduce((sum, t) => sum + t.pnl, 0) / wins.length : 0;
        const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((sum, t) => sum + t.pnl, 0) / losses.length) : 0;
        const largestWin = wins.length > 0 ? Math.max(...wins.map(t => t.pnl)) : 0;
        const largestLoss = losses.length > 0 ? Math.min(...losses.map(t => t.pnl)) : 0;
        const totalWins = wins.reduce((sum, t) => sum + t.pnl, 0);
        const totalLosses = Math.abs(losses.reduce((sum, t) => sum + t.pnl, 0));
        const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;
        const returns = trades.map(t => t.pnlPct / 100);
        const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
        const stdDev = Math.sqrt(returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length);
        const sharpeRatio = stdDev > 0 ? (avgReturn / stdDev) * Math.sqrt(252) : 0;
        let maxDrawdown = 0;
        let maxDrawdownPct = 0;
        let peak = initialCapital;
        equityCurve.forEach(point => {
            if (point.equity > peak) {
                peak = point.equity;
            }
            const drawdown = peak - point.equity;
            const drawdownPct = (drawdown / peak) * 100;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
                maxDrawdownPct = drawdownPct;
            }
        });
        const avgTradeDuration = trades.length > 0
            ? trades.reduce((sum, t) => sum + (t.exitTime.getTime() - t.entryTime.getTime()), 0) / trades.length / 60000
            : 0;
        const totalCommission = trades.reduce((sum, t) => sum + t.commission, 0);
        const netPnl = totalPnl - totalCommission;
        return {
            totalTrades,
            winningTrades,
            losingTrades,
            winRate,
            totalPnl,
            totalPnlPct,
            avgWin,
            avgLoss,
            largestWin,
            largestLoss,
            profitFactor,
            sharpeRatio,
            maxDrawdown,
            maxDrawdownPct,
            avgTradeDuration,
            totalCommission,
            netPnl,
            finalCapital,
        };
    }
    calculateMonthlyReturns(trades) {
        const monthlyReturns = {};
        trades.forEach(trade => {
            const year = trade.exitTime.getFullYear();
            const month = trade.exitTime.getMonth() + 1;
            const key = `${year}-${month.toString().padStart(2, '0')}`;
            if (!monthlyReturns[key]) {
                monthlyReturns[key] = 0;
            }
            monthlyReturns[key] += trade.pnl;
        });
        return monthlyReturns;
    }
    transformTradesForFrontend(trades) {
        return trades.map((trade, index) => {
            const entryDate = trade.entryTime.toISOString().split('T')[0];
            const exitDate = trade.exitTime.toISOString().split('T')[0];
            const entryTime = trade.entryTime.toISOString().split('T')[1].split('.')[0];
            const exitTime = trade.exitTime.toISOString().split('T')[1].split('.')[0];
            const remarksMap = {
                'SIGNAL': 'Strategy signal',
                'STOP_LOSS': 'Stop loss hit',
                'TAKE_PROFIT': 'Take profit reached',
            };
            return {
                index: index + 1,
                entryTime,
                exitTime,
                entryDate,
                exitDate,
                orderType: 'Market',
                strike: 'N/A',
                action: trade.side === 'LONG' ? 'buy' : 'sell',
                quantity: trade.quantity,
                entryPrice: trade.entryPrice,
                exitPrice: trade.exitPrice,
                profitLoss: trade.pnl,
                charges: trade.commission,
                remarks: remarksMap[trade.reason] || trade.reason,
            };
        });
    }
    async storeBacktestResult(strategyId, result) {
        try {
            const monthlyReturns = this.calculateMonthlyReturns(result.trades);
            const transformedTrades = this.transformTradesForFrontend(result.trades);
            await prisma.backtestResult.create({
                data: {
                    strategy: {
                        connect: { id: strategyId }
                    },
                    version: '1.0.0',
                    startDate: result.config.startDate,
                    endDate: result.config.endDate,
                    initialBalance: result.config.initialCapital,
                    timeframe: result.config.resolution,
                    finalBalance: result.metrics.finalCapital,
                    totalReturn: result.metrics.netPnl,
                    totalReturnPct: result.metrics.totalPnlPct,
                    maxDrawdown: result.metrics.maxDrawdown,
                    sharpeRatio: result.metrics.sharpeRatio,
                    winRate: result.metrics.winRate,
                    profitFactor: result.metrics.profitFactor,
                    totalTrades: result.metrics.totalTrades,
                    avgTrade: result.metrics.totalTrades > 0 ? result.metrics.totalPnl / result.metrics.totalTrades : 0,
                    equityCurve: result.equityCurve,
                    tradeHistory: transformedTrades,
                    monthlyReturns: monthlyReturns,
                    backtestDuration: result.executionTime / 1000,
                },
            });
            logger.info(`Backtest result stored for strategy ${strategyId} with ${transformedTrades.length} trades`);
        }
        catch (error) {
            logger.error('Failed to store backtest result:', error);
        }
    }
    async getBacktestResults(strategyId, limit = 10) {
        return await prisma.backtestResult.findMany({
            where: { strategyId },
            orderBy: { createdAt: 'desc' },
            take: limit,
        });
    }
    async getLatestBacktestResult(strategyId) {
        return await prisma.backtestResult.findFirst({
            where: { strategyId },
            orderBy: { createdAt: 'desc' },
        });
    }
}
exports.backtestEngine = new BacktestEngine();
exports.default = exports.backtestEngine;
//# sourceMappingURL=backtest-engine.js.map