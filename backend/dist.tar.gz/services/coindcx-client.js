"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getBalances = getBalances;
exports.getBalance = getBalance;
exports.placeMarketOrder = placeMarketOrder;
exports.placeLimitOrder = placeLimitOrder;
exports.cancelOrder = cancelOrder;
exports.getOrderStatus = getOrderStatus;
exports.getActiveOrders = getActiveOrders;
exports.getOrderHistory = getOrderHistory;
exports.getTradeHistory = getTradeHistory;
exports.getTicker = getTicker;
exports.getAllTickers = getAllTickers;
exports.getOrderBook = getOrderBook;
exports.getHistoricalCandles = getHistoricalCandles;
exports.getMarkets = getMarkets;
exports.getFuturesInstrumentDetails = getFuturesInstrumentDetails;
exports.getFuturesWallets = getFuturesWallets;
exports.createFuturesOrder = createFuturesOrder;
exports.listFuturesPositions = listFuturesPositions;
exports.listFuturesOrders = listFuturesOrders;
exports.exitFuturesPosition = exitFuturesPosition;
exports.getFuturesCandles = getFuturesCandles;
exports.normalizeMarket = normalizeMarket;
exports.testConnection = testConnection;
const crypto_1 = __importDefault(require("crypto"));
const https_1 = __importDefault(require("https"));
const url_1 = require("url");
const simple_crypto_1 = require("../utils/simple-crypto");
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('CoinDCX-Client');
const COINDCX_BASE_URL = 'https://api.coindcx.com';
const COINDCX_PUBLIC_BASE_URL = 'https://public.coindcx.com';
const RATE_LIMIT_DELAY = 100;
let lastRequestTime = 0;
async function rateLimit() {
    const now = Date.now();
    const timeSinceLastRequest = now - lastRequestTime;
    if (timeSinceLastRequest < RATE_LIMIT_DELAY) {
        await new Promise(resolve => setTimeout(resolve, RATE_LIMIT_DELAY - timeSinceLastRequest));
    }
    lastRequestTime = Date.now();
}
function createSignature(payload, secret) {
    return crypto_1.default
        .createHmac('sha256', secret)
        .update(payload)
        .digest('hex');
}
async function makeAuthenticatedRequest(endpoint, credentials, payload = {}) {
    await rateLimit();
    const timestamp = Date.now();
    const bodyWithTimestamp = { ...payload, timestamp };
    const body = JSON.stringify(bodyWithTimestamp).replace(/\s/g, '');
    const signature = createSignature(body, credentials.apiSecret);
    logger.debug(`Making authenticated POST request to ${endpoint}`);
    const response = await fetch(`${COINDCX_BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-AUTH-APIKEY': credentials.apiKey,
            'X-AUTH-SIGNATURE': signature,
        },
        body,
    });
    if (!response.ok) {
        const errorText = await response.text();
        logger.error(`CoinDCX API error (${response.status}): ${errorText}`);
        throw new Error(`CoinDCX API error: ${errorText || response.statusText}`);
    }
    const data = await response.json();
    return data;
}
async function makeAuthenticatedGetRequest(endpoint, credentials, payload = {}) {
    await rateLimit();
    const timestamp = Date.now();
    payload.timestamp = timestamp;
    const body = JSON.stringify(payload).replace(/:\s+/g, ':').replace(/,\s+/g, ',');
    const signature = createSignature(body, credentials.apiSecret);
    logger.info(`Making authenticated request to ${endpoint}`);
    logger.info(`Timestamp: ${timestamp}`);
    logger.info(`Body: ${body}`);
    logger.info(`API Key (first 20): ${credentials.apiKey.substring(0, 20)}`);
    logger.info(`Signature (first 20): ${signature.substring(0, 20)}`);
    const url = new url_1.URL(`${COINDCX_BASE_URL}${endpoint}`);
    const response = await new Promise((resolve, reject) => {
        const options = {
            hostname: url.hostname,
            port: url.port || 443,
            path: url.pathname,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(body),
                'X-AUTH-APIKEY': credentials.apiKey,
                'X-AUTH-SIGNATURE': signature,
            },
        };
        const req = https_1.default.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => { data += chunk; });
            res.on('end', () => {
                resolve({
                    ok: res.statusCode >= 200 && res.statusCode < 300,
                    status: res.statusCode,
                    text: async () => data,
                    json: async () => JSON.parse(data),
                });
            });
        });
        req.on('error', reject);
        req.write(body);
        req.end();
    });
    logger.info(`CoinDCX response status: ${response.status}`);
    if (!response.ok) {
        const errorText = await response.text();
        logger.error(`CoinDCX API error (${response.status}): ${errorText}`);
        throw new Error(`CoinDCX API error: ${errorText || response.statusText}`);
    }
    const data = await response.json();
    logger.debug('CoinDCX response:', JSON.stringify(data));
    return data;
}
async function makePublicRequest(endpoint) {
    await rateLimit();
    logger.debug(`Making public request to ${endpoint}`);
    const response = await fetch(`${COINDCX_PUBLIC_BASE_URL}${endpoint}`);
    if (!response.ok) {
        const errorText = await response.text();
        logger.error(`CoinDCX public API error (${response.status}): ${errorText}`);
        throw new Error(`CoinDCX public API error: ${errorText || response.statusText}`);
    }
    const data = await response.json();
    return data;
}
function prepareCredentials(encryptedApiKey, encryptedApiSecret) {
    return {
        apiKey: (0, simple_crypto_1.decrypt)(encryptedApiKey),
        apiSecret: (0, simple_crypto_1.decrypt)(encryptedApiSecret),
    };
}
async function getBalances(encryptedApiKey, encryptedApiSecret) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    const balances = await makeAuthenticatedRequest('/exchange/v1/users/balances', credentials);
    logger.info(`Fetched ${balances.length} balances`);
    return balances;
}
async function getBalance(encryptedApiKey, encryptedApiSecret, currency) {
    const balances = await getBalances(encryptedApiKey, encryptedApiSecret);
    return balances.find(b => b.currency.toUpperCase() === currency.toUpperCase()) || null;
}
async function placeMarketOrder(encryptedApiKey, encryptedApiSecret, params) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    logger.info(`Placing market ${params.side} order: ${params.total_quantity} ${params.market}`);
    const order = await makeAuthenticatedRequest('/exchange/v1/orders/create', credentials, {
        side: params.side,
        order_type: 'market_order',
        market: params.market,
        total_quantity: params.total_quantity,
        client_order_id: params.client_order_id,
    });
    logger.info(`Market order placed successfully: ${order.id}`);
    return order;
}
async function placeLimitOrder(encryptedApiKey, encryptedApiSecret, params) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    logger.info(`Placing limit ${params.side} order: ${params.total_quantity} @ ${params.price_per_unit} ${params.market}`);
    const order = await makeAuthenticatedRequest('/exchange/v1/orders/create', credentials, {
        side: params.side,
        order_type: 'limit_order',
        market: params.market,
        price_per_unit: params.price_per_unit,
        total_quantity: params.total_quantity,
        client_order_id: params.client_order_id,
    });
    logger.info(`Limit order placed successfully: ${order.id}`);
    return order;
}
async function cancelOrder(encryptedApiKey, encryptedApiSecret, orderId) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    logger.info(`Cancelling order: ${orderId}`);
    const result = await makeAuthenticatedRequest('/exchange/v1/orders/cancel', credentials, { id: orderId });
    logger.info(`Order cancelled: ${orderId}`);
    return result;
}
async function getOrderStatus(encryptedApiKey, encryptedApiSecret, orderId) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    const order = await makeAuthenticatedRequest('/exchange/v1/orders/status', credentials, { id: orderId });
    return order;
}
async function getActiveOrders(encryptedApiKey, encryptedApiSecret, market) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    const payload = {};
    if (market) {
        payload.market = market;
    }
    const orders = await makeAuthenticatedRequest('/exchange/v1/orders/active_orders', credentials, payload);
    logger.info(`Fetched ${orders.length} active orders`);
    return orders;
}
async function getOrderHistory(encryptedApiKey, encryptedApiSecret, params) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    const orders = await makeAuthenticatedRequest('/exchange/v1/orders/trade_history', credentials, params || {});
    logger.info(`Fetched ${orders.length} historical orders`);
    return orders;
}
async function getTradeHistory(encryptedApiKey, encryptedApiSecret, params) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    const trades = await makeAuthenticatedRequest('/exchange/v1/users/trade_history', credentials, params || {});
    logger.info(`Fetched ${trades.length} trades`);
    return trades;
}
async function getTicker(market) {
    const tickers = await makePublicRequest('/market_data/ticker');
    const ticker = tickers.find(t => t.market === market);
    if (!ticker) {
        throw new Error(`Ticker not found for market: ${market}`);
    }
    return ticker;
}
async function getAllTickers() {
    return await makePublicRequest('/market_data/ticker');
}
async function getOrderBook(market) {
    return await makePublicRequest(`/market_data/orderbook?pair=${market}`);
}
async function getHistoricalCandles(market, interval, limit = 500) {
    const response = await makePublicRequest(`/market_data/candles?pair=${market}&interval=${interval}&limit=${limit}`);
    const candles = response.map(candle => ({
        time: candle[0],
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4],
        volume: candle[5],
    }));
    logger.info(`Fetched ${candles.length} candles for ${market} (${interval})`);
    return candles;
}
async function getMarkets() {
    return await makePublicRequest('/market_data/markets');
}
async function getFuturesInstrumentDetails(pair, marginCurrencyShortName = 'USDT') {
    const response = await makePublicRequest(`/exchange/v1/derivatives/futures/data/instrument?pair=${pair}&margin_currency_short_name=${marginCurrencyShortName}`);
    logger.info(`Fetched futures instrument details for ${pair}`);
    return response.instrument;
}
async function getFuturesWallets(encryptedApiKey, encryptedApiSecret) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    const wallets = await makeAuthenticatedGetRequest('/exchange/v1/derivatives/futures/wallets', credentials);
    logger.info(`Fetched ${wallets.length} futures wallets`);
    logger.debug('Futures wallets response:', JSON.stringify(wallets));
    return wallets;
}
async function createFuturesOrder(encryptedApiKey, encryptedApiSecret, params) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    logger.info(`Placing futures ${params.order_type} ${params.side} order: ` +
        `${params.total_quantity} ${params.pair} @ ${params.leverage}x leverage`);
    const orderPayload = {
        side: params.side,
        pair: params.pair,
        order_type: params.order_type,
        total_quantity: params.total_quantity,
        leverage: params.leverage,
        margin_currency_short_name: params.margin_currency_short_name || 'USDT',
        position_margin_type: params.position_margin_type || 'isolated',
    };
    if (params.price)
        orderPayload.price = params.price;
    if (params.stop_price)
        orderPayload.stop_price = params.stop_price;
    if (params.take_profit_price)
        orderPayload.take_profit_price = params.take_profit_price;
    if (params.stop_loss_price)
        orderPayload.stop_loss_price = params.stop_loss_price;
    if (params.client_order_id)
        orderPayload.client_order_id = params.client_order_id;
    if (params.time_in_force)
        orderPayload.time_in_force = params.time_in_force;
    if (params.hidden !== undefined)
        orderPayload.hidden = params.hidden;
    if (params.post_only !== undefined)
        orderPayload.post_only = params.post_only;
    const orders = await makeAuthenticatedRequest('/exchange/v1/derivatives/futures/orders/create', credentials, { order: orderPayload });
    logger.info(`Futures order(s) created: ${orders.map(o => o.id).join(', ')}`);
    return orders;
}
async function listFuturesPositions(encryptedApiKey, encryptedApiSecret, params) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    const payload = {
        page: params?.page || 1,
        size: params?.size || 100,
        margin_currency_short_name: params?.margin_currency_short_name || ['USDT', 'INR'],
    };
    const positions = await makeAuthenticatedRequest('/exchange/v1/derivatives/futures/positions', credentials, payload);
    logger.info(`Fetched ${positions.length} futures positions`);
    return positions;
}
async function listFuturesOrders(encryptedApiKey, encryptedApiSecret, params) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    logger.info(`Fetching futures orders with status: ${params.status}`);
    const orders = await makeAuthenticatedRequest('/exchange/v1/derivatives/futures/orders', credentials, params);
    logger.info(`Fetched ${orders.length} futures orders`);
    return orders;
}
async function exitFuturesPosition(encryptedApiKey, encryptedApiSecret, positionId) {
    const credentials = prepareCredentials(encryptedApiKey, encryptedApiSecret);
    logger.info(`Exiting futures position: ${positionId}`);
    const result = await makeAuthenticatedRequest('/exchange/v1/derivatives/futures/positions/exit', credentials, { id: positionId });
    logger.info(`Position exited: ${positionId}`);
    return result;
}
async function getFuturesCandles(pair, fromTimestamp, toTimestamp, resolution) {
    const API_LIMIT = 30000;
    const resolutionSeconds = {
        '1': 60, '5': 300, '15': 900, '30': 1800, '60': 3600,
        '1D': 86400, '1W': 604800, '1M': 2592000
    };
    const secondsPerCandle = resolutionSeconds[resolution] || 300;
    const maxDurationPerCall = API_LIMIT * secondsPerCandle;
    const allCandles = [];
    let currentEndTs = toTimestamp;
    while (currentEndTs > fromTimestamp) {
        const chunkStartTs = Math.max(fromTimestamp, currentEndTs - maxDurationPerCall);
        const response = await makePublicRequest(`/market_data/candlesticks?pair=${pair}&from=${chunkStartTs}&to=${currentEndTs}&resolution=${resolution}&pcode=f`);
        const candles = response.data.map((candle) => ({
            time: candle.time,
            open: candle.open,
            high: candle.high,
            low: candle.low,
            close: candle.close,
            volume: candle.volume,
        }));
        allCandles.unshift(...candles);
        currentEndTs = chunkStartTs;
        if (candles.length === 0)
            break;
        if (currentEndTs > fromTimestamp) {
            await new Promise(resolve => setTimeout(resolve, 500));
        }
    }
    logger.info(`Fetched ${allCandles.length} futures candles for ${pair} (${resolution})`);
    return allCandles;
}
function normalizeMarket(symbol) {
    return symbol.replace('-', '').replace('/', '').toUpperCase();
}
async function testConnection(encryptedApiKey, encryptedApiSecret) {
    try {
        await getBalances(encryptedApiKey, encryptedApiSecret);
        return true;
    }
    catch (error) {
        logger.error('Connection test failed:', error);
        return false;
    }
}
exports.default = {
    getBalances,
    getBalance,
    placeMarketOrder,
    placeLimitOrder,
    cancelOrder,
    getOrderStatus,
    getActiveOrders,
    getOrderHistory,
    getTradeHistory,
    getTicker,
    getAllTickers,
    getOrderBook,
    getHistoricalCandles,
    getMarkets,
    getFuturesInstrumentDetails,
    getFuturesWallets,
    createFuturesOrder,
    listFuturesPositions,
    exitFuturesPosition,
    getFuturesCandles,
    normalizeMarket,
    testConnection,
};
//# sourceMappingURL=coindcx-client.js.map