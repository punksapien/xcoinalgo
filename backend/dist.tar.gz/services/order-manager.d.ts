declare class OrderManager {
    monitorTradeOrders(tradeId: string): Promise<void>;
    private checkTimeBasedExit;
    private checkOppositeSignalExit;
    private closeTradeManually;
    private handleOrderFilled;
    private calculatePnl;
    monitorAllOpenTrades(): Promise<void>;
    cancelTradeOrders(tradeId: string, apiKey: string, apiSecret: string): Promise<void>;
    getTradeOrderStatus(tradeId: string): Promise<{
        entryOrder: any;
        stopLossOrder: any;
        takeProfitOrder: any;
    }>;
}
export declare const orderManager: OrderManager;
export default orderManager;
//# sourceMappingURL=order-manager.d.ts.map