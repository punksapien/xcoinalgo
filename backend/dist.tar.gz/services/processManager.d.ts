import { ProcessInfo } from '../types';
export declare class ProcessManager {
    private static instance;
    private isConnected;
    static getInstance(): ProcessManager;
    private ensureConnection;
    startBot(deploymentId: string): Promise<ProcessInfo>;
    stopBot(deploymentId: string): Promise<void>;
    getProcessInfo(processName: string): Promise<ProcessInfo | null>;
    healthCheck(): Promise<void>;
    shutdown(): Promise<void>;
}
export declare function startHealthCheckMonitoring(): void;
//# sourceMappingURL=processManager.d.ts.map