type BacktestStage = 'NO_RUN' | 'IDLE' | 'FETCHING' | 'RUNNING' | 'SAVING' | 'DONE' | 'FAILED';
interface BacktestStatus {
    stage: BacktestStage;
    progress: number;
    startedAt?: number;
    endedAt?: number;
    message?: string;
    error?: string;
}
export declare function getBacktestStatus(strategyId: string): BacktestStatus;
interface BacktestConfig {
    strategyId: string;
    symbol: string;
    resolution: '1m' | '5m' | '15m' | '30m' | '1h' | '2h' | '4h' | '6h' | '8h' | '1d' | '1w' | '1M';
    startDate: Date;
    endDate: Date;
    initialCapital: number;
    riskPerTrade: number;
    leverage: number;
    commission: number;
}
interface Trade {
    entryTime: Date;
    exitTime: Date;
    side: 'LONG' | 'SHORT';
    entryPrice: number;
    exitPrice: number;
    quantity: number;
    pnl: number;
    pnlPct: number;
    commission: number;
    reason: 'SIGNAL' | 'STOP_LOSS' | 'TAKE_PROFIT';
}
interface BacktestResult {
    config: BacktestConfig;
    trades: Trade[];
    metrics: {
        totalTrades: number;
        winningTrades: number;
        losingTrades: number;
        winRate: number;
        totalPnl: number;
        totalPnlPct: number;
        avgWin: number;
        avgLoss: number;
        largestWin: number;
        largestLoss: number;
        profitFactor: number;
        sharpeRatio: number;
        maxDrawdown: number;
        maxDrawdownPct: number;
        avgTradeDuration: number;
        totalCommission: number;
        netPnl: number;
        finalCapital: number;
    };
    equityCurve: Array<{
        time: Date;
        equity: number;
        drawdown: number;
    }>;
    executionTime: number;
}
declare class BacktestEngine {
    runBacktest(config: BacktestConfig): Promise<BacktestResult>;
    private mapResolution;
    private fetchHistoricalData;
    private executeBatchBacktest;
    private executeStrategyOnCandle;
    private shouldExitPosition;
    private calculatePnl;
    private calculatePositionSize;
    private calculateMetrics;
    private calculateMonthlyReturns;
    private transformTradesForFrontend;
    private storeBacktestResult;
    getBacktestResults(strategyId: string, limit?: number): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        strategyId: string;
        totalTrades: number;
        version: string;
        winRate: number;
        maxDrawdown: number;
        sharpeRatio: number;
        profitFactor: number;
        startDate: Date;
        endDate: Date;
        initialBalance: number;
        timeframe: string;
        finalBalance: number;
        totalReturn: number;
        totalReturnPct: number;
        avgTrade: number;
        volatility: number | null;
        calmarRatio: number | null;
        sortinoRatio: number | null;
        maxDrawdownDuration: number | null;
        equityCurve: import("@prisma/client/runtime/library").JsonValue;
        tradeHistory: import("@prisma/client/runtime/library").JsonValue;
        monthlyReturns: import("@prisma/client/runtime/library").JsonValue;
        backtestDuration: number;
        dataQuality: string | null;
    }[]>;
    getLatestBacktestResult(strategyId: string): Promise<{
        id: string;
        createdAt: Date;
        updatedAt: Date;
        strategyId: string;
        totalTrades: number;
        version: string;
        winRate: number;
        maxDrawdown: number;
        sharpeRatio: number;
        profitFactor: number;
        startDate: Date;
        endDate: Date;
        initialBalance: number;
        timeframe: string;
        finalBalance: number;
        totalReturn: number;
        totalReturnPct: number;
        avgTrade: number;
        volatility: number | null;
        calmarRatio: number | null;
        sortinoRatio: number | null;
        maxDrawdownDuration: number | null;
        equityCurve: import("@prisma/client/runtime/library").JsonValue;
        tradeHistory: import("@prisma/client/runtime/library").JsonValue;
        monthlyReturns: import("@prisma/client/runtime/library").JsonValue;
        backtestDuration: number;
        dataQuality: string | null;
    }>;
}
export declare const backtestEngine: BacktestEngine;
export default backtestEngine;
//# sourceMappingURL=backtest-engine.d.ts.map