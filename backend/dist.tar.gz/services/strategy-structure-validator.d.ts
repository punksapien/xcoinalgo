export interface ValidationError {
    class_name: string | null;
    method_name: string | null;
    error_type: string;
    message: string;
}
export interface ValidationResult {
    is_valid: boolean;
    errors: ValidationError[];
    warnings: string[];
    found_classes: string[];
    found_methods: {
        [className: string]: string[];
    };
    summary: {
        total_errors: number;
        total_warnings: number;
        classes_found: number;
        classes_expected: number;
    };
}
export declare class StrategyStructureValidatorService {
    private validatorScriptPath;
    constructor();
    validate(code: string): Promise<ValidationResult>;
    formatErrors(result: ValidationResult): string[];
    getSummary(result: ValidationResult): string;
    isValid(code: string): Promise<boolean>;
}
export declare const strategyStructureValidator: StrategyStructureValidatorService;
//# sourceMappingURL=strategy-structure-validator.d.ts.map