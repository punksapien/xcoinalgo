interface Balance {
    currency: string;
    balance: number;
    locked_balance: number;
}
interface Order {
    id: string;
    market: string;
    order_type: 'market_order' | 'limit_order' | 'stop_limit';
    side: 'buy' | 'sell';
    status: 'init' | 'open' | 'partially_filled' | 'filled' | 'cancelled' | 'rejected';
    fee_amount: number;
    fee: number;
    total_quantity: number;
    remaining_quantity: number;
    avg_price: number;
    price_per_unit: number;
    created_at: string;
    updated_at: string;
}
interface Trade {
    id: string;
    order_id: string;
    market: string;
    side: 'buy' | 'sell';
    fee_amount: number;
    ecode: string;
    quantity: number;
    price: number;
    symbol: string;
    timestamp: number;
}
interface Ticker {
    market: string;
    change_24_hour: number;
    high: number;
    low: number;
    volume: number;
    last_price: number;
    bid: number;
    ask: number;
    timestamp: number;
}
interface OHLCVCandle {
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
}
interface FuturesInstrument {
    id: string;
    pair: string;
    base_currency_short_name: string;
    target_currency_short_name: string;
    margin_currency_short_name: string;
    quantity_increment: string;
    price_tick_size: string;
    max_leverage: number;
    min_quantity: string;
    max_quantity: string;
    status: string;
}
interface FuturesWallet {
    id: string;
    currency_short_name: string;
    balance: number;
    locked_balance: number;
    unrealized_pnl: number;
}
interface FuturesPosition {
    id: string;
    pair: string;
    side: 'buy' | 'sell';
    active_pos: number;
    mark_price: number;
    entry_price: number;
    liquidation_price: number;
    leverage: number;
    margin: number;
    unrealized_pnl: number;
    realized_pnl: number;
    margin_currency_short_name: string;
}
interface FuturesOrder {
    id: string;
    pair: string;
    side: 'buy' | 'sell';
    order_type: string;
    total_quantity: number;
    remaining_quantity: number;
    price: number | null;
    stop_price: number | null;
    status: string;
    leverage: number;
    take_profit_price: number | null;
    stop_loss_price: number | null;
    created_at: string;
    updated_at: string;
}
export declare function getBalances(encryptedApiKey: string, encryptedApiSecret: string): Promise<Balance[]>;
export declare function getBalance(encryptedApiKey: string, encryptedApiSecret: string, currency: string): Promise<Balance | null>;
export declare function placeMarketOrder(encryptedApiKey: string, encryptedApiSecret: string, params: {
    market: string;
    side: 'buy' | 'sell';
    total_quantity: number;
    client_order_id?: string;
}): Promise<Order>;
export declare function placeLimitOrder(encryptedApiKey: string, encryptedApiSecret: string, params: {
    market: string;
    side: 'buy' | 'sell';
    price_per_unit: number;
    total_quantity: number;
    client_order_id?: string;
}): Promise<Order>;
export declare function cancelOrder(encryptedApiKey: string, encryptedApiSecret: string, orderId: string): Promise<{
    message: string;
}>;
export declare function getOrderStatus(encryptedApiKey: string, encryptedApiSecret: string, orderId: string): Promise<Order>;
export declare function getActiveOrders(encryptedApiKey: string, encryptedApiSecret: string, market?: string): Promise<Order[]>;
export declare function getOrderHistory(encryptedApiKey: string, encryptedApiSecret: string, params?: {
    market?: string;
    limit?: number;
    page?: number;
}): Promise<Order[]>;
export declare function getTradeHistory(encryptedApiKey: string, encryptedApiSecret: string, params?: {
    market?: string;
    limit?: number;
    page?: number;
    from_timestamp?: number;
    to_timestamp?: number;
}): Promise<Trade[]>;
export declare function getTicker(market: string): Promise<Ticker>;
export declare function getAllTickers(): Promise<Ticker[]>;
export declare function getOrderBook(market: string): Promise<{
    bids: {
        price: string;
        quantity: string;
    }[];
    asks: {
        price: string;
        quantity: string;
    }[];
}>;
export declare function getHistoricalCandles(market: string, interval: '1m' | '5m' | '15m' | '30m' | '1h' | '2h' | '4h' | '6h' | '8h' | '1d' | '1w' | '1M', limit?: number): Promise<OHLCVCandle[]>;
export declare function getMarkets(): Promise<Array<{
    symbol: string;
    base_currency_short_name: string;
    target_currency_short_name: string;
    status: string;
}>>;
export declare function getFuturesInstrumentDetails(pair: string, marginCurrencyShortName?: string): Promise<FuturesInstrument>;
export declare function getFuturesWallets(encryptedApiKey: string, encryptedApiSecret: string): Promise<FuturesWallet[]>;
export declare function createFuturesOrder(encryptedApiKey: string, encryptedApiSecret: string, params: {
    pair: string;
    side: 'buy' | 'sell';
    order_type: 'market_order' | 'limit_order' | 'stop_limit';
    total_quantity: number;
    leverage: number;
    price?: number;
    stop_price?: number;
    take_profit_price?: number;
    stop_loss_price?: number;
    margin_currency_short_name?: string;
    position_margin_type?: 'isolated' | 'cross';
    client_order_id?: string;
    time_in_force?: 'GTC' | 'IOC' | 'FOK';
    hidden?: boolean;
    post_only?: boolean;
}): Promise<FuturesOrder[]>;
export declare function listFuturesPositions(encryptedApiKey: string, encryptedApiSecret: string, params?: {
    page?: number;
    size?: number;
    margin_currency_short_name?: string[];
}): Promise<FuturesPosition[]>;
export declare function listFuturesOrders(encryptedApiKey: string, encryptedApiSecret: string, params: {
    timestamp: number;
    status: string;
    side: string;
    page: string;
    size: string;
    margin_currency_short_name: string[];
}): Promise<any[]>;
export declare function exitFuturesPosition(encryptedApiKey: string, encryptedApiSecret: string, positionId: string): Promise<{
    message: string;
}>;
export declare function getFuturesCandles(pair: string, fromTimestamp: number, toTimestamp: number, resolution: '1' | '5' | '15' | '30' | '60' | '1D' | '1W' | '1M'): Promise<OHLCVCandle[]>;
export declare function normalizeMarket(symbol: string): string;
export declare function testConnection(encryptedApiKey: string, encryptedApiSecret: string): Promise<boolean>;
declare const _default: {
    getBalances: typeof getBalances;
    getBalance: typeof getBalance;
    placeMarketOrder: typeof placeMarketOrder;
    placeLimitOrder: typeof placeLimitOrder;
    cancelOrder: typeof cancelOrder;
    getOrderStatus: typeof getOrderStatus;
    getActiveOrders: typeof getActiveOrders;
    getOrderHistory: typeof getOrderHistory;
    getTradeHistory: typeof getTradeHistory;
    getTicker: typeof getTicker;
    getAllTickers: typeof getAllTickers;
    getOrderBook: typeof getOrderBook;
    getHistoricalCandles: typeof getHistoricalCandles;
    getMarkets: typeof getMarkets;
    getFuturesInstrumentDetails: typeof getFuturesInstrumentDetails;
    getFuturesWallets: typeof getFuturesWallets;
    createFuturesOrder: typeof createFuturesOrder;
    listFuturesPositions: typeof listFuturesPositions;
    exitFuturesPosition: typeof exitFuturesPosition;
    getFuturesCandles: typeof getFuturesCandles;
    normalizeMarket: typeof normalizeMarket;
    testConnection: typeof testConnection;
};
export default _default;
//# sourceMappingURL=coindcx-client.d.ts.map