"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.backtestProgressTracker = exports.BacktestProgressTracker = void 0;
const events_1 = require("events");
const logger_1 = require("../utils/logger");
class BacktestProgressTracker extends events_1.EventEmitter {
    constructor() {
        super(...arguments);
        this.progressMap = new Map();
    }
    updateProgress(strategyId, update) {
        const current = this.progressMap.get(strategyId) || {
            strategyId,
            stage: 'fetching_data',
            progress: 0,
            message: 'Starting backtest...'
        };
        const updated = {
            ...current,
            ...update,
            strategyId
        };
        this.progressMap.set(strategyId, updated);
        this.emit(`progress:${strategyId}`, updated);
        this.emit('progress', updated);
        logger_1.logger.debug(`Backtest progress [${strategyId}]: ${updated.stage} (${(updated.progress * 100).toFixed(0)}%)`);
    }
    getProgress(strategyId) {
        return this.progressMap.get(strategyId) || null;
    }
    markComplete(strategyId, result) {
        this.updateProgress(strategyId, {
            stage: 'complete',
            progress: 1.0,
            message: `Backtest complete! ${result.totalTrades || 0} trades executed`,
            metrics: result.metrics,
            trades: result.trades,
            totalTrades: result.totalTrades
        });
        setTimeout(() => {
            this.progressMap.delete(strategyId);
            logger_1.logger.debug(`Cleaned up progress data for strategy ${strategyId}`);
        }, 5 * 60 * 1000);
    }
    markError(strategyId, error) {
        this.updateProgress(strategyId, {
            stage: 'error',
            progress: 0,
            message: `Backtest failed: ${error}`,
            error
        });
        setTimeout(() => {
            this.progressMap.delete(strategyId);
        }, 5 * 60 * 1000);
    }
    clearProgress(strategyId) {
        this.progressMap.delete(strategyId);
    }
    getActiveBacktests() {
        return Array.from(this.progressMap.values());
    }
    subscribeToStrategy(strategyId, callback) {
        const listener = (progress) => callback(progress);
        this.on(`progress:${strategyId}`, listener);
        return () => {
            this.off(`progress:${strategyId}`, listener);
        };
    }
}
exports.BacktestProgressTracker = BacktestProgressTracker;
exports.backtestProgressTracker = new BacktestProgressTracker();
//# sourceMappingURL=backtest-progress-tracker.js.map