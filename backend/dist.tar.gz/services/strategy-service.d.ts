export interface StrategyConfig {
    name: string;
    code: string;
    author: string;
    description?: string;
    leverage: number;
    risk_per_trade: number;
    pair: string;
    margin_currency: string;
    resolution: string;
    lookback_period: number;
    sl_atr_multiplier: number;
    tp_atr_multiplier: number;
    max_positions: number;
    max_daily_loss: number;
    custom_params?: Record<string, any>;
}
export interface StrategyDeploymentRequest {
    user_id: string;
    strategy_code: string;
    config: StrategyConfig;
    auto_start?: boolean;
    environment?: string;
    resource_limits?: Record<string, any>;
}
export interface StrategyResponse {
    success: boolean;
    message: string;
    strategy_id?: string;
    status?: string;
    metrics?: any;
    data?: any;
    error_code?: string;
    error_details?: any;
}
export interface StrategyMetrics {
    total_trades: number;
    winning_trades: number;
    losing_trades: number;
    total_pnl: number;
    total_pnl_pct: number;
    win_rate: number;
    max_drawdown: number;
    max_drawdown_pct: number;
    sharpe_ratio?: number;
    current_position: string;
    unrealized_pnl: number;
    started_at?: string;
    last_signal_at?: string;
    last_update_at: string;
}
export interface StrategyInfo {
    strategy_id: string;
    user_id: string;
    config: StrategyConfig;
    status: string;
    deployed_at: string;
    started_at?: string;
    stopped_at?: string;
    metrics?: StrategyMetrics;
    process_id?: number;
    memory_usage?: number;
    cpu_usage?: number;
    last_error?: string;
    error_count: number;
}
export interface MarketData {
    symbol: string;
    timestamp: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    bid?: number;
    ask?: number;
    spread?: number;
    exchange?: string;
    data_type?: string;
}
export declare class StrategyService {
    private client;
    private baseUrl;
    constructor(baseUrl?: string);
    healthCheck(): Promise<boolean>;
    deployStrategy(request: StrategyDeploymentRequest): Promise<StrategyResponse>;
    getStrategyStatus(strategyId: string): Promise<StrategyResponse>;
    stopStrategy(strategyId: string): Promise<boolean>;
    listStrategies(): Promise<StrategyInfo[]>;
    sendMarketData(marketData: MarketData): Promise<boolean>;
    getStrategySignals(strategyId: string, limit?: number): Promise<any[]>;
    validateStrategy(strategyCode: string, config: StrategyConfig): Promise<any>;
    getServiceMetrics(): Promise<any>;
    getMultipleStrategyStatus(strategyIds: string[]): Promise<Record<string, StrategyResponse>>;
}
export declare const strategyService: StrategyService;
//# sourceMappingURL=strategy-service.d.ts.map