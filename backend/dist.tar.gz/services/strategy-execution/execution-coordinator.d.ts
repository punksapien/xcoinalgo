interface ExecutionResult {
    success: boolean;
    signal?: 'LONG' | 'SHORT' | 'HOLD' | 'EXIT_LONG' | 'EXIT_SHORT';
    subscribersProcessed: number;
    tradesGenerated: number;
    executionTime: number;
    error?: string;
}
declare class ExecutionCoordinator {
    executeStrategy(strategyId: string, scheduledTime: Date, workerId?: string): Promise<ExecutionResult>;
    private getStrategyExecutionEnvironment;
    private executePythonStrategy;
    private executeMultiTenantStrategy;
    private executeLiveTraderStrategy;
    private filterSubscribersWithoutOpenPositions;
    private processSignalForSubscriber;
    private calculatePositionSize;
    private placeOrderWithTracking;
    private placeOrder;
    private logExecution;
    executeCandleStrategies(symbol: string, resolution: string, closeTime: Date): Promise<void>;
    getExecutionStats(strategyId: string): Promise<{
        totalExecutions: number;
        successfulExecutions: number;
        failedExecutions: number;
        totalTrades: number;
        avgDuration: number;
        lastExecution: Date | null;
    }>;
}
export declare const executionCoordinator: ExecutionCoordinator;
export {};
//# sourceMappingURL=execution-coordinator.d.ts.map