"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.executionCoordinator = void 0;
const client_1 = require("@prisma/client");
const strategy_registry_1 = require("./strategy-registry");
const settings_service_1 = require("./settings-service");
const subscription_service_1 = require("./subscription-service");
const event_bus_1 = require("../../lib/event-bus");
const time_utils_1 = require("../../lib/time-utils");
const child_process_1 = require("child_process");
const path_1 = __importDefault(require("path"));
const coindcx_client_1 = __importDefault(require("../coindcx-client"));
const logger_1 = require("../../utils/logger");
const strategy_environment_manager_1 = require("../strategy-environment-manager");
const prisma = new client_1.PrismaClient();
const logger = new logger_1.Logger('ExecutionCoordinator');
class ExecutionCoordinator {
    async executeStrategy(strategyId, scheduledTime, workerId = process.env.WORKER_ID || 'worker-default') {
        const startTime = Date.now();
        const actualTime = new Date();
        let symbol = 'UNKNOWN';
        let resolution = '1m';
        console.log(`\n${'='.repeat(80)}\n` +
            `Strategy Execution Started: ${strategyId}\n` +
            `Scheduled: ${scheduledTime.toISOString()}\n` +
            `Actual: ${actualTime.toISOString()}\n` +
            `Worker: ${workerId}\n` +
            `${'='.repeat(80)}`);
        try {
            (0, time_utils_1.validateExecutionTiming)(scheduledTime, actualTime, 2.0);
            const strategySettings = await settings_service_1.settingsService.getStrategySettings(strategyId);
            if (!strategySettings) {
                throw new Error(`Strategy ${strategyId} settings not found`);
            }
            symbol = strategySettings.symbol;
            resolution = strategySettings.resolution;
            const intervalKey = (0, time_utils_1.formatIntervalKey)(scheduledTime, resolution);
            const lockTTL = (0, time_utils_1.computeLockTTL)(resolution, 10);
            const lockAcquired = await settings_service_1.settingsService.acquireExecutionLock(strategyId, intervalKey, lockTTL, workerId);
            if (!lockAcquired) {
                console.log(`Lock already held for ${strategyId} at ${intervalKey}, skipping execution`);
                return {
                    success: false,
                    subscribersProcessed: 0,
                    tradesGenerated: 0,
                    executionTime: Date.now() - startTime,
                    error: 'Lock already held by another worker',
                };
            }
            event_bus_1.eventBus.emit('strategy.execution.start', {
                strategyId,
                interval: resolution,
            });
            const subscribers = await subscription_service_1.subscriptionService.getActiveSubscribers(strategyId);
            if (subscribers.length === 0) {
                console.log(`No active subscribers for strategy ${strategyId}, skipping execution`);
                await this.logExecution(strategyId, symbol, resolution, intervalKey, {
                    status: 'SKIPPED',
                    subscribersCount: 0,
                    tradesGenerated: 0,
                    duration: Date.now() - startTime,
                    workerId,
                });
                return {
                    success: true,
                    subscribersProcessed: 0,
                    tradesGenerated: 0,
                    executionTime: Date.now() - startTime,
                };
            }
            console.log(`Executing strategy for ${subscribers.length} active subscribers`);
            const strategy = await prisma.strategy.findUnique({
                where: { id: strategyId },
                include: {
                    versions: {
                        orderBy: { createdAt: 'desc' },
                        take: 1,
                        select: { strategyCode: true }
                    }
                }
            });
            const strategyType = strategy?.strategyType;
            const strategyCode = strategy?.versions?.[0]?.strategyCode || '';
            const isMultiTenant = strategyType === 'multi_tenant';
            const isLiveTrader = strategyType === 'livetrader';
            let pythonResult;
            if (isMultiTenant) {
                console.log('✨ Detected multi-tenant strategy - using wrapper');
                pythonResult = await this.executeMultiTenantStrategy(strategyId, strategySettings, subscribers, strategyCode);
                const executionTime = Date.now() - startTime;
                await this.logExecution(strategyId, symbol, resolution, intervalKey, {
                    status: pythonResult.success ? 'SUCCESS' : 'FAILED',
                    subscribersCount: subscribers.length,
                    tradesGenerated: pythonResult.success ? subscribers.length : 0,
                    duration: executionTime,
                    workerId,
                    signalType: pythonResult.success ? 'MULTI_TENANT' : undefined,
                });
                return {
                    success: pythonResult.success,
                    subscribersProcessed: pythonResult.success ? subscribers.length : 0,
                    tradesGenerated: pythonResult.success ? subscribers.length : 0,
                    executionTime,
                    error: pythonResult.error
                };
            }
            if (isLiveTrader) {
                console.log('✨ Detected LiveTrader format - executing with multi-tenant support');
                const { filtered: eligibleSubscribers, skipped: skippedCount } = await this.filterSubscribersWithoutOpenPositions(subscribers, symbol);
                logger.info(`Filtered subscribers: ${eligibleSubscribers.length} eligible, ${skippedCount} skipped (existing positions)`);
                if (eligibleSubscribers.length === 0) {
                    console.log('No eligible subscribers after filtering - all have open positions');
                    return {
                        success: true,
                        subscribersProcessed: 0,
                        tradesGenerated: 0,
                        executionTime: Date.now() - startTime,
                    };
                }
                pythonResult = await this.executeLiveTraderStrategy(strategyId, strategySettings, eligibleSubscribers, strategyCode);
                const executionTime = Date.now() - startTime;
                await this.logExecution(strategyId, symbol, resolution, intervalKey, {
                    status: pythonResult.success ? 'SUCCESS' : 'FAILED',
                    subscribersCount: subscribers.length,
                    tradesGenerated: pythonResult.success ? subscribers.length : 0,
                    duration: executionTime,
                    workerId,
                    signalType: pythonResult.success ? 'LIVETRADER_MULTI_TENANT' : undefined,
                });
                return {
                    success: pythonResult.success,
                    subscribersProcessed: pythonResult.success ? subscribers.length : 0,
                    tradesGenerated: pythonResult.success ? subscribers.length : 0,
                    executionTime,
                    error: pythonResult.error
                };
            }
            console.log('Using legacy format - TypeScript places orders');
            pythonResult = await this.executePythonStrategy(strategyId, strategySettings, scheduledTime);
            if (!pythonResult.success || !pythonResult.signal) {
                console.warn(`Strategy execution failed or returned no signal`);
                await this.logExecution(strategyId, symbol, resolution, intervalKey, {
                    status: pythonResult.success ? 'NO_SIGNAL' : 'FAILED',
                    subscribersCount: subscribers.length,
                    tradesGenerated: 0,
                    duration: Date.now() - startTime,
                    workerId,
                    error: pythonResult.error,
                });
                return {
                    success: pythonResult.success,
                    subscribersProcessed: subscribers.length,
                    tradesGenerated: 0,
                    executionTime: Date.now() - startTime,
                    error: pythonResult.error,
                };
            }
            const signal = pythonResult.signal;
            console.log('\n' + '='.repeat(80));
            console.log('📊 STRATEGY SIGNAL GENERATED');
            console.log('='.repeat(80));
            console.log(`Signal Type: ${signal.signal}`);
            console.log(`Price: $${signal.price}`);
            console.log(`Stop Loss: ${signal.stopLoss || 'N/A'}`);
            console.log(`Take Profit: ${signal.takeProfit || 'N/A'}`);
            if (signal.metadata) {
                console.log('Metadata:');
                console.log(JSON.stringify(signal.metadata, null, 2));
            }
            console.log('='.repeat(80) + '\n');
            logger.info('Full signal object:', JSON.stringify(signal, null, 2));
            let tradesGenerated = 0;
            const fanoutPromises = subscribers.map(async (subscriber) => {
                try {
                    const tradeCreated = await this.processSignalForSubscriber(subscriber, signal, strategySettings);
                    if (tradeCreated) {
                        tradesGenerated++;
                    }
                }
                catch (error) {
                    console.error(`Failed to process signal for subscriber ${subscriber.id}:`, error);
                }
            });
            await Promise.all(fanoutPromises);
            console.log(`Signal processed for ${subscribers.length} subscribers, ${tradesGenerated} trades generated`);
            await this.logExecution(strategyId, symbol, resolution, intervalKey, {
                status: 'SUCCESS',
                signalType: signal.signal,
                subscribersCount: subscribers.length,
                tradesGenerated,
                duration: Date.now() - startTime,
                workerId,
            });
            await settings_service_1.settingsService.updateExecutionStatus(strategyId, {
                last_run: actualTime.toISOString(),
                subscribers: subscribers.length,
                duration: (Date.now() - startTime) / 1000,
                last_signal: signal.signal,
                worker_id: workerId,
                execution_count: 1,
            });
            event_bus_1.eventBus.emit('strategy.execution.complete', {
                strategyId,
                interval: resolution,
                success: true,
                duration: Date.now() - startTime,
            });
            console.log(`\n${'='.repeat(80)}\n` +
                `Execution Complete: ${strategyId}\n` +
                `Signal: ${signal.signal}\n` +
                `Subscribers: ${subscribers.length}\n` +
                `Trades: ${tradesGenerated}\n` +
                `Duration: ${Date.now() - startTime}ms\n` +
                `${'='.repeat(80)}\n`);
            return {
                success: true,
                signal: signal.signal,
                subscribersProcessed: subscribers.length,
                tradesGenerated,
                executionTime: Date.now() - startTime,
            };
        }
        catch (error) {
            console.error(`Strategy execution failed for ${strategyId}:`, error);
            event_bus_1.eventBus.emit('strategy.execution.error', {
                strategyId,
                interval: resolution,
                error: error instanceof Error ? error : new Error(String(error)),
            });
            return {
                success: false,
                subscribersProcessed: 0,
                tradesGenerated: 0,
                executionTime: Date.now() - startTime,
                error: error instanceof Error ? error.message : String(error),
            };
        }
    }
    async getStrategyExecutionEnvironment(strategyId) {
        const envInfo = await strategy_environment_manager_1.strategyEnvironmentManager.getEnvironmentInfo(strategyId);
        const strategiesDir = path_1.default.join(__dirname, '../../../strategies');
        const strategyDir = path_1.default.join(strategiesDir, strategyId);
        return {
            pythonPath: envInfo.pythonPath,
            strategyDir
        };
    }
    async executePythonStrategy(strategyId, strategySettings, executionTime) {
        return new Promise(async (resolve) => {
            const pythonScriptPath = path_1.default.join(__dirname, '../../../python/strategy_runner.py');
            let pythonPath;
            let strategyDir;
            try {
                const env = await this.getStrategyExecutionEnvironment(strategyId);
                pythonPath = env.pythonPath;
                strategyDir = env.strategyDir;
            }
            catch (error) {
                logger.error(`Failed to get environment for strategy ${strategyId}:`, error);
                resolve({
                    success: false,
                    signal: null,
                    error: `Environment not found: ${error}`,
                });
                return;
            }
            const input = JSON.stringify({
                strategy_id: strategyId,
                execution_time: executionTime.toISOString(),
                settings: strategySettings,
            });
            console.log(`Spawning Python subprocess: ${pythonScriptPath}`);
            console.log(`Using Python: ${pythonPath}`);
            console.log(`Working directory: ${strategyDir}`);
            const pythonProcess = (0, child_process_1.spawn)(pythonPath, [pythonScriptPath], {
                env: { ...process.env },
                cwd: strategyDir,
            });
            let stdout = '';
            let stderr = '';
            pythonProcess.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            pythonProcess.stderr.on('data', (data) => {
                stderr += data.toString();
            });
            pythonProcess.on('close', (code) => {
                if (code !== 0) {
                    console.error(`Python process exited with code ${code}`);
                    console.error(`stderr: ${stderr}`);
                    resolve({
                        success: false,
                        signal: null,
                        error: `Python process exited with code ${code}: ${stderr}`,
                    });
                    return;
                }
                try {
                    const result = JSON.parse(stdout);
                    resolve({
                        success: true,
                        signal: result.signal || null,
                        logs: result.logs || [],
                    });
                }
                catch (error) {
                    console.error(`Failed to parse Python output:`, error);
                    console.error(`stdout: ${stdout}`);
                    resolve({
                        success: false,
                        signal: null,
                        error: `Failed to parse Python output: ${error}`,
                    });
                }
            });
            pythonProcess.stdin.write(input);
            pythonProcess.stdin.end();
            setTimeout(() => {
                pythonProcess.kill();
                resolve({
                    success: false,
                    signal: null,
                    error: 'Python execution timeout (5min)',
                });
            }, 300000);
        });
    }
    async executeMultiTenantStrategy(strategyId, strategySettings, subscribers, strategyCode) {
        return new Promise(async (resolve) => {
            const pythonScriptPath = path_1.default.join(__dirname, '../../../python/multi_tenant_wrapper.py');
            let pythonPath;
            let strategyDir;
            try {
                const env = await this.getStrategyExecutionEnvironment(strategyId);
                pythonPath = env.pythonPath;
                strategyDir = env.strategyDir;
            }
            catch (error) {
                logger.error(`Failed to get environment for strategy ${strategyId}:`, error);
                resolve({
                    success: false,
                    signal: null,
                    error: `Environment not found: ${error}`,
                });
                return;
            }
            const subscribersData = subscribers.map(sub => ({
                user_id: sub.userId,
                api_key: sub.brokerCredential?.apiKey || '',
                api_secret: sub.brokerCredential?.apiSecret || '',
                capital: sub.capital || 10000,
                risk_per_trade: sub.riskPerTrade || 0.02,
                leverage: sub.leverage || 10
            }));
            const input = JSON.stringify({
                strategy_code: strategyCode,
                settings: strategySettings,
                subscribers: subscribersData
            });
            console.log(`Spawning multi-tenant wrapper: ${pythonScriptPath}`);
            console.log(`Using Python: ${pythonPath}`);
            console.log(`Working directory: ${strategyDir}`);
            console.log(`Subscribers: ${subscribersData.length}`);
            const pythonProcess = (0, child_process_1.spawn)(pythonPath, [pythonScriptPath], {
                env: { ...process.env },
                cwd: strategyDir,
            });
            let stdout = '';
            let stderr = '';
            pythonProcess.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            pythonProcess.stderr.on('data', (data) => {
                const stderrStr = data.toString();
                stderr += stderrStr;
                console.log('[Python stderr]:', stderrStr);
            });
            pythonProcess.on('close', (code) => {
                if (code !== 0) {
                    console.error(`Multi-tenant wrapper exited with code ${code}`);
                    console.error(`stderr: ${stderr}`);
                    resolve({
                        success: false,
                        signal: null,
                        error: `Multi-tenant wrapper exited with code ${code}: ${stderr}`,
                    });
                    return;
                }
                try {
                    const result = JSON.parse(stdout);
                    if (!result.success) {
                        console.error('Multi-tenant execution failed:', result.error);
                        console.error('Logs:', result.logs);
                    }
                    else {
                        console.log('✅ Multi-tenant execution successful');
                        console.log(`Subscribers processed: ${result.subscribers_processed || subscribersData.length}`);
                        console.log(`Trades attempted: ${result.trades_attempted || 0}`);
                    }
                    resolve({
                        success: result.success,
                        signal: null,
                        logs: result.logs || [],
                        error: result.error
                    });
                }
                catch (error) {
                    console.error(`Failed to parse multi-tenant wrapper output:`, error);
                    console.error(`stdout: ${stdout}`);
                    resolve({
                        success: false,
                        signal: null,
                        error: `Failed to parse multi-tenant wrapper output: ${error}`,
                    });
                }
            });
            pythonProcess.stdin.write(input);
            pythonProcess.stdin.end();
            setTimeout(() => {
                pythonProcess.kill();
                resolve({
                    success: false,
                    signal: null,
                    error: 'Multi-tenant wrapper execution timeout (10min)',
                });
            }, 600000);
        });
    }
    async executeLiveTraderStrategy(strategyId, strategySettings, subscribers, strategyCode) {
        return new Promise(async (resolve) => {
            const pythonScriptPath = path_1.default.join(__dirname, '../../../python/live_trader_executor.py');
            let pythonPath;
            let strategyDir;
            try {
                const env = await this.getStrategyExecutionEnvironment(strategyId);
                pythonPath = env.pythonPath;
                strategyDir = env.strategyDir;
            }
            catch (error) {
                logger.error(`Failed to get environment for strategy ${strategyId}:`, error);
                resolve({
                    success: false,
                    signal: null,
                    error: `Environment not found: ${error}`,
                });
                return;
            }
            const subscribersData = subscribers.map(sub => ({
                user_id: sub.userId,
                api_key: sub.brokerCredential?.apiKey || '',
                api_secret: sub.brokerCredential?.apiSecret || '',
                capital: sub.capital || 10000,
                risk_per_trade: sub.riskPerTrade || 0.05,
                leverage: sub.leverage || 10
            }));
            const input = JSON.stringify({
                strategy_code: strategyCode,
                settings: strategySettings,
                subscribers: subscribersData
            });
            console.log(`Spawning LiveTrader executor: ${pythonScriptPath}`);
            console.log(`Using Python: ${pythonPath}`);
            console.log(`Working directory: ${strategyDir}`);
            console.log(`Subscribers: ${subscribersData.length}`);
            const pythonProcess = (0, child_process_1.spawn)(pythonPath, [pythonScriptPath], {
                env: { ...process.env },
                cwd: strategyDir,
            });
            let stdout = '';
            let stderr = '';
            pythonProcess.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            pythonProcess.stderr.on('data', (data) => {
                const stderrStr = data.toString();
                stderr += stderrStr;
                console.log('[Python stderr]:', stderrStr);
            });
            pythonProcess.on('close', (code) => {
                if (code !== 0) {
                    console.error(`LiveTrader executor exited with code ${code}`);
                    console.error(`stderr: ${stderr}`);
                    resolve({
                        success: false,
                        signal: null,
                        error: `LiveTrader executor exited with code ${code}: ${stderr}`,
                    });
                    return;
                }
                try {
                    const result = JSON.parse(stdout);
                    if (!result.success) {
                        console.error('LiveTrader execution failed:', result.error);
                        console.error('Logs:', result.logs);
                    }
                    else {
                        console.log('✅ LiveTrader execution successful');
                        console.log(`Subscribers processed: ${result.subscribers_processed || subscribersData.length}`);
                    }
                    resolve({
                        success: result.success,
                        signal: null,
                        logs: result.logs || [],
                        error: result.error
                    });
                }
                catch (error) {
                    console.error(`Failed to parse LiveTrader output:`, error);
                    console.error(`stdout: ${stdout}`);
                    resolve({
                        success: false,
                        signal: null,
                        error: `Failed to parse LiveTrader output: ${error}`,
                    });
                }
            });
            pythonProcess.stdin.write(input);
            pythonProcess.stdin.end();
            setTimeout(() => {
                pythonProcess.kill();
                resolve({
                    success: false,
                    signal: null,
                    error: 'LiveTrader execution timeout (10min)',
                });
            }, 600000);
        });
    }
    async filterSubscribersWithoutOpenPositions(subscribers, symbol) {
        const filtered = [];
        let skipped = 0;
        for (const subscriber of subscribers) {
            const existingPosition = await prisma.trade.findFirst({
                where: {
                    subscriptionId: subscriber.id,
                    symbol: symbol,
                    status: 'OPEN'
                }
            });
            if (existingPosition) {
                logger.info(`Subscriber ${subscriber.userId} already has OPEN position for ${symbol} - skipping`);
                skipped++;
            }
            else {
                filtered.push(subscriber);
            }
        }
        return { filtered, skipped };
    }
    async processSignalForSubscriber(subscription, signal, strategySettings) {
        if (subscription.isPaused || !subscription.isActive) {
            console.log(`Skipping subscriber ${subscription.id} (paused or inactive)`);
            return false;
        }
        const userSettings = await settings_service_1.settingsService.getSubscriptionSettings(subscription.userId, subscription.strategyId);
        if (!userSettings || !userSettings.is_active) {
            console.log(`Skipping subscriber ${subscription.id} (no active settings)`);
            return false;
        }
        if (signal.signal === 'HOLD') {
            return false;
        }
        const existingPosition = await prisma.trade.findFirst({
            where: {
                subscriptionId: subscription.id,
                symbol: strategySettings.symbol,
                status: 'OPEN'
            }
        });
        if (existingPosition) {
            logger.info(`Subscriber ${subscription.id} already has OPEN position - skipping`);
            return false;
        }
        try {
            const positionSize = this.calculatePositionSize(userSettings.capital, userSettings.risk_per_trade, signal.price, signal.stopLoss, userSettings.leverage);
            if (positionSize <= 0) {
                console.warn(`Invalid position size for subscriber ${subscription.id}`);
                return false;
            }
            if (!subscription.brokerCredential) {
                console.warn(`No broker credentials for subscriber ${subscription.id}`);
                return false;
            }
            const { apiKey, apiSecret } = subscription.brokerCredential;
            const orderResult = await this.placeOrderWithTracking(strategySettings.symbol, signal.signal, positionSize, signal.price, signal.stopLoss, signal.takeProfit, apiKey, apiSecret, subscription);
            if (!orderResult.success) {
                console.warn(`Failed to place order for subscriber ${subscription.id}: ${orderResult.error}`);
                return false;
            }
            const trade = await prisma.trade.create({
                data: {
                    subscriptionId: subscription.id,
                    symbol: strategySettings.symbol,
                    side: signal.signal.includes('LONG') ? 'LONG' : 'SHORT',
                    quantity: positionSize,
                    entryPrice: signal.price,
                    stopLoss: signal.stopLoss,
                    takeProfit: signal.takeProfit,
                    status: 'OPEN',
                    tradingType: subscription.tradingType || 'spot',
                    leverage: subscription.leverage || 1,
                    marginCurrency: subscription.marginCurrency || 'USDT',
                    positionId: orderResult.positionId,
                    liquidationPrice: orderResult.liquidationPrice,
                    orderId: orderResult.orderId,
                    metadata: {
                        ...signal.metadata,
                        entrySignal: signal.signal,
                        strategyId: subscription.strategyId,
                        hold_period_hrs: strategySettings.hold_period_hrs || 24,
                        orderId: orderResult.orderId,
                        positionId: orderResult.positionId,
                        orderStatus: orderResult.orderStatus,
                        stopLossOrderId: orderResult.stopLossOrderId,
                        takeProfitOrderId: orderResult.takeProfitOrderId,
                        allOrderIds: orderResult.allOrderIds,
                        liquidationPrice: orderResult.liquidationPrice,
                        exchange: 'coindcx',
                        tradingType: subscription.tradingType || 'spot',
                        leverage: subscription.leverage || 1,
                        riskManagement: {
                            stopLoss: signal.stopLoss,
                            takeProfit: signal.takeProfit,
                            hasStopLoss: !!orderResult.stopLossOrderId || !!signal.stopLoss,
                            hasTakeProfit: !!orderResult.takeProfitOrderId || !!signal.takeProfit,
                        },
                    },
                },
            });
            console.log(`Created trade ${trade.id} for subscriber ${subscription.id}: ` +
                `${signal.signal} ${positionSize} @ ${signal.price}`);
            event_bus_1.eventBus.emit('trade.created', {
                tradeId: trade.id,
                subscriptionId: subscription.id,
                symbol: strategySettings.symbol,
            });
            return true;
        }
        catch (error) {
            console.error(`Failed to process signal for subscriber ${subscription.id}:`, error);
            return false;
        }
    }
    calculatePositionSize(capital, riskPerTrade, entryPrice, stopLoss, leverage = 1) {
        if (!stopLoss) {
            const riskAmount = capital * riskPerTrade;
            return (riskAmount * leverage) / entryPrice;
        }
        const riskAmount = capital * riskPerTrade;
        const stopLossDistance = Math.abs(entryPrice - stopLoss);
        const riskPerUnit = stopLossDistance;
        if (riskPerUnit === 0) {
            return 0;
        }
        const positionSize = (riskAmount / riskPerUnit) * leverage;
        return positionSize;
    }
    async placeOrderWithTracking(symbol, side, quantity, price, stopLoss, takeProfit, apiKey, apiSecret, subscription) {
        if (!apiKey || !apiSecret) {
            logger.error('Missing broker credentials for order placement');
            return {
                success: false,
                error: 'Missing broker credentials',
            };
        }
        try {
            const tradingType = subscription?.tradingType === 'futures' ? 'futures' : 'spot';
            const leverage = subscription?.leverage || 1;
            const marginCurrency = subscription?.marginCurrency || 'USDT';
            const marginConversionRate = subscription?.marginConversionRate || 1;
            const orderSide = side.includes('LONG') || side === 'BUY' ? 'buy' : 'sell';
            logger.info(`Placing ${tradingType} ${orderSide} order: ${quantity} ${symbol} @ ${leverage}x leverage`);
            if (tradingType === 'futures') {
                const instrument = await coindcx_client_1.default.getFuturesInstrumentDetails(symbol, marginCurrency);
                const quantityIncrement = parseFloat(instrument.quantity_increment);
                const maxAllowedLeverage = instrument.max_leverage;
                if (leverage > maxAllowedLeverage) {
                    logger.error(`Leverage ${leverage}x exceeds exchange limit of ${maxAllowedLeverage}x for ${symbol}`);
                    return {
                        success: false,
                        error: `Leverage ${leverage}x exceeds exchange limit of ${maxAllowedLeverage}x for this instrument`,
                    };
                }
                logger.info(`Using ${leverage}x leverage (max allowed: ${maxAllowedLeverage}x)`);
                const adjustedQuantity = Math.floor(quantity / quantityIncrement) * quantityIncrement;
                if (adjustedQuantity <= 0) {
                    logger.error(`Adjusted quantity is zero for ${symbol}. Raw: ${quantity}, Increment: ${quantityIncrement}`);
                    return {
                        success: false,
                        error: 'Calculated quantity is too small for instrument precision',
                    };
                }
                logger.info(`Adjusted quantity: ${adjustedQuantity} (raw: ${quantity}, increment: ${quantityIncrement})`);
                const orders = await coindcx_client_1.default.createFuturesOrder(apiKey, apiSecret, {
                    pair: symbol,
                    side: orderSide,
                    order_type: 'market_order',
                    total_quantity: adjustedQuantity,
                    leverage,
                    stop_loss_price: stopLoss,
                    take_profit_price: takeProfit,
                    margin_currency_short_name: marginCurrency,
                    position_margin_type: subscription?.positionMarginType || 'isolated',
                    client_order_id: `xcoin_fut_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                });
                if (!orders || orders.length === 0) {
                    logger.error('Futures order placement failed: No orders returned');
                    return {
                        success: false,
                        error: 'No orders returned from exchange',
                    };
                }
                const primaryOrder = orders[0];
                logger.info(`Futures order placed: ${primaryOrder.id}`);
                const positions = await coindcx_client_1.default.listFuturesPositions(apiKey, apiSecret, {
                    margin_currency_short_name: [marginCurrency],
                });
                const position = positions.find(p => p.pair === symbol && p.side === orderSide);
                return {
                    success: true,
                    orderId: primaryOrder.id,
                    positionId: position?.id,
                    orderStatus: primaryOrder.status,
                    liquidationPrice: position?.liquidation_price,
                    allOrderIds: orders.map(o => o.id),
                };
            }
            const market = coindcx_client_1.default.normalizeMarket(symbol);
            const order = await coindcx_client_1.default.placeMarketOrder(apiKey, apiSecret, {
                market,
                side: orderSide,
                total_quantity: quantity,
                client_order_id: `xcoin_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            });
            if (!order || !order.id) {
                logger.error('Order placement failed: No order ID returned');
                return {
                    success: false,
                    error: 'No order ID returned from exchange',
                };
            }
            logger.info(`Order placed successfully: ${order.id} (status: ${order.status})`);
            const orderIds = [order.id];
            let stopLossOrderId;
            let takeProfitOrderId;
            if (stopLoss && stopLoss > 0) {
                try {
                    logger.info(`Placing stop loss order at ${stopLoss}`);
                    const stopLossOrder = await coindcx_client_1.default.placeLimitOrder(apiKey, apiSecret, {
                        market,
                        side: orderSide === 'buy' ? 'sell' : 'buy',
                        price_per_unit: stopLoss,
                        total_quantity: quantity,
                        client_order_id: `xcoin_sl_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                    });
                    if (stopLossOrder && stopLossOrder.id) {
                        stopLossOrderId = stopLossOrder.id;
                        orderIds.push(stopLossOrder.id);
                        logger.info(`Stop loss order placed: ${stopLossOrder.id} at ${stopLoss}`);
                    }
                }
                catch (error) {
                    logger.error('Failed to place stop loss order:', error);
                }
            }
            if (takeProfit && takeProfit > 0) {
                try {
                    logger.info(`Placing take profit order at ${takeProfit}`);
                    const takeProfitOrder = await coindcx_client_1.default.placeLimitOrder(apiKey, apiSecret, {
                        market,
                        side: orderSide === 'buy' ? 'sell' : 'buy',
                        price_per_unit: takeProfit,
                        total_quantity: quantity,
                        client_order_id: `xcoin_tp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                    });
                    if (takeProfitOrder && takeProfitOrder.id) {
                        takeProfitOrderId = takeProfitOrder.id;
                        orderIds.push(takeProfitOrder.id);
                        logger.info(`Take profit order placed: ${takeProfitOrder.id} at ${takeProfit}`);
                    }
                }
                catch (error) {
                    logger.error('Failed to place take profit order:', error);
                }
            }
            return {
                success: true,
                orderId: order.id,
                orderStatus: order.status,
                stopLossOrderId,
                takeProfitOrderId,
                allOrderIds: orderIds,
            };
        }
        catch (error) {
            logger.error('Failed to place order:', error);
            logger.error('Order details:', {
                symbol,
                side,
                quantity,
                price,
            });
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error',
            };
        }
    }
    async placeOrder(symbol, side, quantity, price, stopLoss, takeProfit, apiKey, apiSecret) {
        if (!apiKey || !apiSecret) {
            logger.error('Missing broker credentials for order placement');
            return false;
        }
        try {
            const market = coindcx_client_1.default.normalizeMarket(symbol) + 'INR';
            const orderSide = side.includes('LONG') || side === 'BUY' ? 'buy' : 'sell';
            logger.info(`Placing ${orderSide} order: ${quantity} ${market} @ ${price}`);
            const order = await coindcx_client_1.default.placeMarketOrder(apiKey, apiSecret, {
                market,
                side: orderSide,
                total_quantity: quantity,
                client_order_id: `xcoin_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            });
            if (!order || !order.id) {
                logger.error('Order placement failed: No order ID returned');
                return false;
            }
            logger.info(`Order placed successfully: ${order.id} (status: ${order.status})`);
            if (stopLoss) {
                logger.warn(`Stop loss ${stopLoss} not implemented yet - requires separate order`);
            }
            if (takeProfit) {
                logger.warn(`Take profit ${takeProfit} not implemented yet - requires separate order`);
            }
            return true;
        }
        catch (error) {
            logger.error('Failed to place order:', error);
            logger.error('Order details:', {
                symbol,
                side,
                quantity,
                price,
            });
            return false;
        }
    }
    async logExecution(strategyId, symbol, resolution, intervalKey, metadata) {
        try {
            await prisma.strategyExecution.create({
                data: {
                    strategyId,
                    symbol,
                    resolution,
                    intervalKey,
                    executedAt: new Date(),
                    status: metadata.status,
                    signalType: metadata.signalType,
                    subscribersCount: metadata.subscribersCount,
                    tradesGenerated: metadata.tradesGenerated,
                    duration: metadata.duration / 1000,
                    workerId: metadata.workerId,
                    error: metadata.error,
                },
            });
        }
        catch (error) {
            console.error(`Failed to log execution:`, error);
        }
    }
    async executeCandleStrategies(symbol, resolution, closeTime) {
        console.log(`\nCandle closed: ${symbol} ${resolution} at ${closeTime.toISOString()}`);
        const strategies = await strategy_registry_1.strategyRegistry.getStrategiesForCandle(symbol, resolution);
        if (strategies.length === 0) {
            console.log(`No strategies registered for ${symbol} ${resolution}`);
            return;
        }
        console.log(`Found ${strategies.length} strategies for ${symbol} ${resolution}`);
        const executionPromises = strategies.map((strategyId) => this.executeStrategy(strategyId, closeTime));
        await Promise.all(executionPromises);
    }
    async getExecutionStats(strategyId) {
        try {
            const executions = await prisma.strategyExecution.findMany({
                where: { strategyId },
                orderBy: { executedAt: 'desc' },
                take: 100,
            });
            const totalExecutions = executions.length;
            const successfulExecutions = executions.filter((e) => e.status === 'SUCCESS').length;
            const failedExecutions = executions.filter((e) => e.status === 'FAILED').length;
            const totalTrades = executions.reduce((sum, e) => sum + e.tradesGenerated, 0);
            const avgDuration = executions.reduce((sum, e) => sum + e.duration, 0) / totalExecutions;
            return {
                totalExecutions,
                successfulExecutions,
                failedExecutions,
                totalTrades,
                avgDuration,
                lastExecution: executions[0]?.executedAt || null,
            };
        }
        catch (error) {
            console.error(`Failed to get execution stats:`, error);
            return {
                totalExecutions: 0,
                successfulExecutions: 0,
                failedExecutions: 0,
                totalTrades: 0,
                avgDuration: 0,
                lastExecution: null,
            };
        }
    }
}
exports.executionCoordinator = new ExecutionCoordinator();
//# sourceMappingURL=execution-coordinator.js.map