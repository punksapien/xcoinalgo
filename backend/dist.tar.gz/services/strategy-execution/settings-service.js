"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsService = void 0;
const redis_client_1 = require("../../lib/redis-client");
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
class SettingsService {
    async initializeStrategy(strategyId, config, version = 1) {
        try {
            const key = `strategy:${strategyId}:settings`;
            const settings = {
                version: version.toString(),
                updated_at: new Date().toISOString(),
                ...this.serializeSettings(config),
            };
            await redis_client_1.redis.hset(key, settings);
            console.log(`Initialized strategy ${strategyId} settings: version=${version}`);
            return true;
        }
        catch (error) {
            console.error(`Failed to initialize strategy ${strategyId}:`, error);
            return false;
        }
    }
    async getStrategySettings(strategyId, fallbackToDb = true) {
        try {
            const key = `strategy:${strategyId}:settings`;
            const settings = await redis_client_1.redis.hgetall(key);
            if (settings && Object.keys(settings).length > 0) {
                return this.deserializeSettings(settings);
            }
            if (fallbackToDb) {
                console.log(`Cache miss for strategy ${strategyId}, loading from DB`);
                const dbSettings = await this.loadFromDatabase(strategyId);
                if (dbSettings) {
                    await this.initializeStrategy(strategyId, dbSettings, parseInt(dbSettings.version?.toString() || '1', 10));
                    return dbSettings;
                }
            }
            console.warn(`Strategy ${strategyId} settings not found`);
            return null;
        }
        catch (error) {
            console.error(`Failed to get strategy ${strategyId} settings:`, error);
            return null;
        }
    }
    async updateStrategySettings(strategyId, updates, publishUpdate = true) {
        try {
            const key = `strategy:${strategyId}:settings`;
            const currentVersion = await redis_client_1.redis.hget(key, 'version');
            const newVersion = parseInt(currentVersion || '0', 10) + 1;
            const updateData = {
                version: newVersion.toString(),
                updated_at: new Date().toISOString(),
                ...this.serializeSettings(updates),
            };
            await redis_client_1.redis.hset(key, updateData);
            console.log(`Updated strategy ${strategyId} settings: ` +
                `version=${newVersion}, fields=${Object.keys(updates).join(', ')}`);
            if (publishUpdate) {
                await this.publishSettingsUpdate(strategyId, newVersion, Object.keys(updates));
            }
            return true;
        }
        catch (error) {
            console.error(`Failed to update strategy ${strategyId} settings:`, error);
            return false;
        }
    }
    async initializeSubscription(userId, strategyId, settings) {
        try {
            const key = `subscription:${userId}:${strategyId}:settings`;
            const subscriptionData = this.serializeSettings(settings);
            await redis_client_1.redis.hset(key, subscriptionData);
            await redis_client_1.redis.expire(key, 86400);
            console.log(`Initialized subscription for user ${userId} on strategy ${strategyId}`);
            return true;
        }
        catch (error) {
            console.error(`Failed to initialize subscription for user ${userId}:`, error);
            return false;
        }
    }
    async getSubscriptionSettings(userId, strategyId) {
        try {
            const key = `subscription:${userId}:${strategyId}:settings`;
            const settings = await redis_client_1.redis.hgetall(key);
            if (settings && Object.keys(settings).length > 0) {
                await redis_client_1.redis.expire(key, 86400);
                return this.deserializeSettings(settings);
            }
            return null;
        }
        catch (error) {
            console.error(`Failed to get subscription settings for user ${userId}, strategy ${strategyId}:`, error);
            return null;
        }
    }
    async updateSubscriptionSettings(userId, strategyId, updates) {
        try {
            const key = `subscription:${userId}:${strategyId}:settings`;
            const updateData = this.serializeSettings(updates);
            await redis_client_1.redis.hset(key, updateData);
            await redis_client_1.redis.expire(key, 86400);
            console.log(`Updated subscription for user ${userId} on strategy ${strategyId}: ` +
                `${Object.keys(updates).join(', ')}`);
            return true;
        }
        catch (error) {
            console.error(`Failed to update subscription settings:`, error);
            return false;
        }
    }
    async acquireExecutionLock(strategyId, intervalKey, ttlSeconds, workerId = process.env.WORKER_ID || 'worker-default') {
        try {
            const lockKey = `lock:strategy:${strategyId}:run:${intervalKey}`;
            const acquired = await redis_client_1.redis.set(lockKey, workerId, 'EX', ttlSeconds, 'NX');
            if (acquired === 'OK') {
                console.log(`Acquired lock for strategy ${strategyId} at ${intervalKey} ` +
                    `(worker=${workerId}, ttl=${ttlSeconds}s)`);
                return true;
            }
            else {
                const holder = await redis_client_1.redis.get(lockKey);
                console.log(`Lock already held for strategy ${strategyId} at ${intervalKey} ` +
                    `by worker ${holder}`);
                return false;
            }
        }
        catch (error) {
            console.error(`Failed to acquire lock for strategy ${strategyId}:`, error);
            return false;
        }
    }
    async releaseExecutionLock(strategyId, intervalKey) {
        try {
            const lockKey = `lock:strategy:${strategyId}:run:${intervalKey}`;
            await redis_client_1.redis.del(lockKey);
            console.log(`Released lock for strategy ${strategyId} at ${intervalKey}`);
            return true;
        }
        catch (error) {
            console.error(`Failed to release lock for strategy ${strategyId}:`, error);
            return false;
        }
    }
    async updateExecutionStatus(strategyId, status) {
        try {
            const key = `strategy:${strategyId}:execution:status`;
            const statusData = this.serializeSettings(status);
            await redis_client_1.redis.hset(key, statusData);
            await redis_client_1.redis.expire(key, 604800);
            return true;
        }
        catch (error) {
            console.error(`Failed to update execution status for strategy ${strategyId}:`, error);
            return false;
        }
    }
    async getExecutionStatus(strategyId) {
        try {
            const key = `strategy:${strategyId}:execution:status`;
            const status = await redis_client_1.redis.hgetall(key);
            if (status && Object.keys(status).length > 0) {
                return this.deserializeSettings(status);
            }
            return null;
        }
        catch (error) {
            console.error(`Failed to get execution status for strategy ${strategyId}:`, error);
            return null;
        }
    }
    async publishSettingsUpdate(strategyId, version, changedFields) {
        try {
            const channel = `channel:strategy:${strategyId}:settings:updated`;
            const message = JSON.stringify({
                version,
                updated_at: new Date().toISOString(),
                changed_fields: changedFields,
            });
            await redis_client_1.redis.publish(channel, message);
            console.log(`Published settings update for strategy ${strategyId}: ` +
                `version=${version}, fields=${changedFields.join(', ')}`);
        }
        catch (error) {
            console.error(`Failed to publish settings update:`, error);
        }
    }
    serializeSettings(settings) {
        const serialized = {};
        for (const [key, value] of Object.entries(settings)) {
            if (value === null || value === undefined) {
                continue;
            }
            serialized[key] = String(value);
        }
        return serialized;
    }
    deserializeSettings(redisData) {
        const result = {};
        for (const [key, value] of Object.entries(redisData)) {
            if (key === 'version' ||
                key === 'leverage' ||
                key === 'max_positions' ||
                key === 'lookback_period' ||
                key === 'execution_count' ||
                key === 'subscribers' ||
                key === 'st_period' ||
                key === 'ema_fast_len' ||
                key === 'ema_slow_len' ||
                key === 'bb_len' ||
                key === 'rsi_len' ||
                key === 'rsi_oversold' ||
                key === 'rsi_overbought' ||
                key === 'atr_len' ||
                key === 'vol_ma_len' ||
                key === 'bbw_zscore_len' ||
                key === 'hold_trend' ||
                key === 'hold_reversion') {
                result[key] = parseInt(value, 10);
            }
            else if (key === 'capital' ||
                key === 'risk_per_trade' ||
                key === 'max_daily_loss' ||
                key === 'sl_atr_multiplier' ||
                key === 'tp_atr_multiplier' ||
                key === 'duration' ||
                key === 'st_multiplier' ||
                key === 'bb_std' ||
                key === 'zscore_thresh' ||
                key === 'sl_atr_trend' ||
                key === 'tp_atr_trend' ||
                key === 'sl_atr_reversion' ||
                key === 'tp_atr_reversion') {
                result[key] = parseFloat(value);
            }
            else if (key === 'is_active') {
                result[key] = value.toLowerCase() === 'true';
            }
            else {
                result[key] = value;
            }
        }
        return result;
    }
    async loadFromDatabase(strategyId) {
        try {
            const strategy = await prisma.strategy.findUnique({
                where: { id: strategyId },
                select: {
                    executionConfig: true,
                },
            });
            if (!strategy || !strategy.executionConfig) {
                return null;
            }
            const config = strategy.executionConfig;
            return {
                version: 1,
                updated_at: new Date().toISOString(),
                strategy_id: strategyId,
                symbol: config.symbol,
                resolution: config.resolution,
                lookback_period: config.lookbackPeriod || 200,
                ...config,
            };
        }
        catch (error) {
            console.error(`Failed to load strategy ${strategyId} from database:`, error);
            return null;
        }
    }
}
exports.settingsService = new SettingsService();
//# sourceMappingURL=settings-service.js.map