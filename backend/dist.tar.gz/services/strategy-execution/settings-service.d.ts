interface StrategySettings {
    version: number;
    updated_at: string;
    symbol: string;
    resolution: string;
    lookback_period: number;
    [key: string]: any;
}
interface SubscriptionSettings {
    capital: number;
    risk_per_trade: number;
    leverage: number;
    max_positions: number;
    max_daily_loss: number;
    sl_atr_multiplier?: number;
    tp_atr_multiplier?: number;
    broker_credential_id: string;
    is_active: boolean;
    [key: string]: any;
}
interface ExecutionStatus {
    last_run: string;
    subscribers: number;
    duration: number;
    last_signal?: string;
    worker_id: string;
    execution_count: number;
}
declare class SettingsService {
    initializeStrategy(strategyId: string, config: Partial<StrategySettings>, version?: number): Promise<boolean>;
    getStrategySettings(strategyId: string, fallbackToDb?: boolean): Promise<StrategySettings | null>;
    updateStrategySettings(strategyId: string, updates: Partial<StrategySettings>, publishUpdate?: boolean): Promise<boolean>;
    initializeSubscription(userId: string, strategyId: string, settings: Partial<SubscriptionSettings>): Promise<boolean>;
    getSubscriptionSettings(userId: string, strategyId: string): Promise<SubscriptionSettings | null>;
    updateSubscriptionSettings(userId: string, strategyId: string, updates: Partial<SubscriptionSettings>): Promise<boolean>;
    acquireExecutionLock(strategyId: string, intervalKey: string, ttlSeconds: number, workerId?: string): Promise<boolean>;
    releaseExecutionLock(strategyId: string, intervalKey: string): Promise<boolean>;
    updateExecutionStatus(strategyId: string, status: Partial<ExecutionStatus>): Promise<boolean>;
    getExecutionStatus(strategyId: string): Promise<ExecutionStatus | null>;
    private publishSettingsUpdate;
    private serializeSettings;
    private deserializeSettings;
    private loadFromDatabase;
}
export declare const settingsService: SettingsService;
export {};
//# sourceMappingURL=settings-service.d.ts.map