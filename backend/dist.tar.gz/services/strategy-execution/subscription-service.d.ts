import { StrategySubscription } from '@prisma/client';
interface CreateSubscriptionParams {
    userId: string;
    strategyId: string;
    capital: number;
    riskPerTrade: number;
    leverage?: number;
    maxPositions?: number;
    maxDailyLoss?: number;
    slAtrMultiplier?: number;
    tpAtrMultiplier?: number;
    brokerCredentialId: string;
    tradingType?: 'spot' | 'futures';
    marginCurrency?: string;
}
interface SubscriptionWithStrategy extends StrategySubscription {
    strategy?: {
        id: string;
        name: string;
        executionConfig: any;
    };
    brokerCredential?: {
        id: string;
        apiKey: string;
        apiSecret: string;
    };
}
declare class SubscriptionService {
    createSubscription(params: CreateSubscriptionParams): Promise<{
        subscriptionId: string;
        isFirstSubscriber: boolean;
    }>;
    cancelSubscription(subscriptionId: string): Promise<boolean>;
    pauseSubscription(subscriptionId: string): Promise<boolean>;
    resumeSubscription(subscriptionId: string): Promise<boolean>;
    getActiveSubscribers(strategyId: string): Promise<SubscriptionWithStrategy[]>;
    getUserSubscriptions(userId: string): Promise<SubscriptionWithStrategy[]>;
    getSubscriptionById(subscriptionId: string): Promise<SubscriptionWithStrategy | null>;
    updateSettings(subscriptionId: string, updates: Partial<{
        capital: number;
        riskPerTrade: number;
        leverage: number;
        maxPositions: number;
        maxDailyLoss: number;
        slAtrMultiplier: number;
        tpAtrMultiplier: number;
    }>): Promise<boolean>;
    getStats(subscriptionId: string): Promise<{
        totalTrades: number;
        winningTrades: number;
        losingTrades: number;
        winRate: number;
        totalPnl: number;
    } | null>;
}
export declare const subscriptionService: SubscriptionService;
export {};
//# sourceMappingURL=subscription-service.d.ts.map