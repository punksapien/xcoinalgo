interface CandleKey {
    symbol: string;
    resolution: string;
}
declare class StrategyRegistry {
    private cache;
    private initialized;
    initialize(): Promise<void>;
    registerStrategy(strategyId: string, symbol: string, resolution: string): Promise<void>;
    unregisterStrategy(strategyId: string, symbol: string, resolution: string): Promise<void>;
    getStrategiesForCandle(symbol: string, resolution: string): Promise<string[]>;
    getActiveCandles(): Promise<CandleKey[]>;
    updateStrategyRegistration(strategyId: string, oldSymbol: string, oldResolution: string, newSymbol: string, newResolution: string): Promise<void>;
    refreshCache(): Promise<void>;
    getStats(): Promise<{
        totalCandles: number;
        totalStrategies: number;
        candleBreakdown: Array<{
            candle: string;
            strategies: number;
        }>;
    }>;
    clear(): Promise<void>;
    private getCandleKey;
}
export declare const strategyRegistry: StrategyRegistry;
export {};
//# sourceMappingURL=strategy-registry.d.ts.map