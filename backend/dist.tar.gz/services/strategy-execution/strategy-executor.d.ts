export interface StrategySettings {
    strategy_id: string;
    pair: string;
    capital: number;
    leverage: number;
    risk_per_trade: number;
    resolution?: string;
    commission_rate?: number;
    gst_rate?: number;
    sl_rate?: number;
    tp_rate?: number;
    start_date?: string;
    end_date?: string;
    [key: string]: any;
}
export interface Subscriber {
    user_id: string;
    api_key: string;
    api_secret: string;
    capital: number;
    leverage: number;
    risk_per_trade: number;
}
export interface BacktestResult {
    success: boolean;
    mode: 'backtest';
    metrics?: any;
    trades?: any[];
    total_trades?: number;
    error?: string;
    traceback?: string;
}
export interface LiveExecutionResult {
    success: boolean;
    mode: 'live';
    result?: any;
    subscribers_count?: number;
    error?: string;
    traceback?: string;
}
export type ExecutionResult = BacktestResult | LiveExecutionResult;
export declare class StrategyExecutor {
    private getStrategyFilePath;
    executeBacktest(strategyId: string, settings: StrategySettings): Promise<BacktestResult>;
    executeBacktestAsync(strategyId: string, settings: StrategySettings): Promise<void>;
    private fetchActiveSubscribers;
    executeLive(strategyId: string, settings: StrategySettings): Promise<LiveExecutionResult>;
    private executePythonScript;
    private executePythonScriptWithProgress;
    private updateTradeStatistics;
    getStrategyResolution(strategyId: string): Promise<string>;
    private calculateEquityCurve;
    private calculateMonthlyReturns;
}
export declare const strategyExecutor: StrategyExecutor;
//# sourceMappingURL=strategy-executor.d.ts.map