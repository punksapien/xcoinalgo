"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.strategyExecutor = exports.StrategyExecutor = void 0;
const child_process_1 = require("child_process");
const path = __importStar(require("path"));
const fs = __importStar(require("fs/promises"));
const logger_1 = require("../../utils/logger");
const strategy_environment_manager_1 = require("../strategy-environment-manager");
const encryption_1 = require("../../utils/encryption");
const database_1 = __importDefault(require("../../utils/database"));
const backtest_progress_tracker_1 = require("../backtest-progress-tracker");
class StrategyExecutor {
    async getStrategyFilePath(strategyId) {
        const strategiesDir = path.join(__dirname, '../../../strategies');
        const strategyDir = path.join(strategiesDir, strategyId);
        const files = await fs.readdir(strategyDir);
        const pyFile = files.find(f => f.endsWith('.py'));
        if (!pyFile) {
            throw new Error(`No Python file found in strategy directory: ${strategyDir}`);
        }
        return path.join(strategyDir, pyFile);
    }
    async executeBacktest(strategyId, settings) {
        logger_1.logger.info(`Executing backtest for strategy ${strategyId}`);
        try {
            const envExists = await strategy_environment_manager_1.strategyEnvironmentManager.environmentExists(strategyId);
            if (!envExists) {
                logger_1.logger.info(`Environment not found for strategy ${strategyId}, creating...`);
                await strategy_environment_manager_1.strategyEnvironmentManager.createEnvironment(strategyId);
            }
            const envInfo = await strategy_environment_manager_1.strategyEnvironmentManager.getEnvironmentInfo(strategyId);
            if (envInfo.status !== 'ready') {
                throw new Error(`Environment is not ready for strategy ${strategyId}: ${envInfo.status}`);
            }
            const strategyFilePath = await this.getStrategyFilePath(strategyId);
            const input = {
                mode: 'backtest',
                strategy_file: strategyFilePath,
                settings: {
                    ...settings,
                    strategy_id: strategyId,
                },
            };
            const result = await this.executePythonScript(envInfo.pythonPath, path.join(__dirname, '../../../python/strategy_executor.py'), input);
            const stdoutLines = result.stdout.trim().split('\n');
            const lastJsonLine = stdoutLines[stdoutLines.length - 1];
            const parsedResult = JSON.parse(lastJsonLine);
            if (parsedResult.success) {
                logger_1.logger.info(`Backtest completed successfully for strategy ${strategyId}`);
                logger_1.logger.info(`Total trades: ${parsedResult.total_trades}`);
            }
            else {
                logger_1.logger.error(`Backtest failed for strategy ${strategyId}: ${parsedResult.error}`);
            }
            return parsedResult;
        }
        catch (error) {
            logger_1.logger.error(`Failed to execute backtest for strategy ${strategyId}:`, error);
            return {
                success: false,
                mode: 'backtest',
                error: error instanceof Error ? error.message : 'Unknown error',
            };
        }
    }
    async executeBacktestAsync(strategyId, settings) {
        logger_1.logger.info(`Starting async backtest for strategy ${strategyId}`);
        try {
            backtest_progress_tracker_1.backtestProgressTracker.updateProgress(strategyId, {
                stage: 'fetching_data',
                progress: 0.05,
                message: 'Initializing backtest...'
            });
            const envExists = await strategy_environment_manager_1.strategyEnvironmentManager.environmentExists(strategyId);
            if (!envExists) {
                logger_1.logger.info(`Environment not found for strategy ${strategyId}, creating...`);
                await strategy_environment_manager_1.strategyEnvironmentManager.createEnvironment(strategyId);
            }
            const envInfo = await strategy_environment_manager_1.strategyEnvironmentManager.getEnvironmentInfo(strategyId);
            if (envInfo.status !== 'ready') {
                throw new Error(`Environment is not ready for strategy ${strategyId}: ${envInfo.status}`);
            }
            const strategyFilePath = await this.getStrategyFilePath(strategyId);
            const input = {
                mode: 'backtest',
                strategy_file: strategyFilePath,
                settings: {
                    ...settings,
                    strategy_id: strategyId,
                },
            };
            logger_1.logger.info(`Python input settings keys (${Object.keys(input.settings).length}): ${Object.keys(input.settings).join(', ')}`);
            const result = await this.executePythonScriptWithProgress(strategyId, envInfo.pythonPath, path.join(__dirname, '../../../python/strategy_executor.py'), input);
            const stdoutLines = result.stdout.trim().split('\n');
            const lastJsonLine = stdoutLines[stdoutLines.length - 1];
            const parsedResult = JSON.parse(lastJsonLine);
            if (parsedResult.success) {
                logger_1.logger.info(`Async backtest completed successfully for strategy ${strategyId}`);
                logger_1.logger.info(`Total trades: ${parsedResult.total_trades}`);
                backtest_progress_tracker_1.backtestProgressTracker.markComplete(strategyId, {
                    metrics: parsedResult.metrics,
                    trades: parsedResult.trades,
                    totalTrades: parsedResult.total_trades
                });
                const executionConfig = {
                    symbol: settings.pair,
                    resolution: settings.resolution?.replace('m', '') || '5',
                };
                const equityCurve = this.calculateEquityCurve(parsedResult.trades || [], settings.capital || 10000);
                const monthlyReturns = this.calculateMonthlyReturns(parsedResult.trades || []);
                const backtestResult = await database_1.default.backtestResult.create({
                    data: {
                        strategyId,
                        version: '1.0.0',
                        startDate: new Date(settings.start_date || new Date()),
                        endDate: new Date(settings.end_date || new Date()),
                        initialBalance: settings.capital || 10000,
                        timeframe: settings.resolution || '5m',
                        finalBalance: equityCurve.finalBalance,
                        totalReturn: equityCurve.totalReturn,
                        totalReturnPct: parsedResult.metrics?.roi || 0,
                        maxDrawdown: parsedResult.metrics?.maxDrawdown || 0,
                        sharpeRatio: parsedResult.metrics?.sharpeRatio || 0,
                        winRate: parsedResult.metrics?.winRate || 0,
                        profitFactor: parsedResult.metrics?.profitFactor || 0,
                        totalTrades: parsedResult.total_trades || 0,
                        avgTrade: parsedResult.metrics?.expectancy || 0,
                        equityCurve: equityCurve.data,
                        tradeHistory: parsedResult.trades || [],
                        monthlyReturns: monthlyReturns,
                        backtestDuration: parsedResult.stats?.total_duration || 0,
                        dataQuality: 'good'
                    }
                });
                logger_1.logger.info(`Saved complete backtest results to database (ID: ${backtestResult.id})`);
                await database_1.default.strategy.update({
                    where: { id: strategyId },
                    data: {
                        winRate: parsedResult.metrics?.winRate || 0,
                        roi: parsedResult.metrics?.roi || 0,
                        maxDrawdown: parsedResult.metrics?.maxDrawdown || 0,
                        profitFactor: parsedResult.metrics?.profitFactor || 0,
                        totalTrades: parsedResult.total_trades || 0,
                        executionConfig: executionConfig,
                        isActive: true,
                        isApproved: true,
                        isMarketplace: true
                    }
                });
                logger_1.logger.info(`Strategy ${strategyId} updated with backtest results and published to marketplace`);
            }
            else {
                logger_1.logger.error(`Async backtest failed for strategy ${strategyId}: ${parsedResult.error}`);
                backtest_progress_tracker_1.backtestProgressTracker.markError(strategyId, parsedResult.error || 'Unknown error');
            }
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : 'Unknown error';
            logger_1.logger.error(`Failed to execute async backtest for strategy ${strategyId}:`, error);
            backtest_progress_tracker_1.backtestProgressTracker.markError(strategyId, errorMsg);
        }
    }
    async fetchActiveSubscribers(strategyId) {
        logger_1.logger.info(`Fetching active subscribers for strategy ${strategyId}`);
        try {
            const subscriptions = await database_1.default.strategySubscription.findMany({
                where: {
                    strategyId,
                    isActive: true,
                    isPaused: false,
                },
                include: {
                    brokerCredential: {
                        select: {
                            apiKey: true,
                            apiSecret: true,
                        },
                    },
                },
            });
            const subscribers = subscriptions.map((sub) => ({
                user_id: sub.userId,
                api_key: (0, encryption_1.decrypt)(sub.brokerCredential.apiKey),
                api_secret: (0, encryption_1.decrypt)(sub.brokerCredential.apiSecret),
                capital: sub.capital,
                leverage: sub.leverage,
                risk_per_trade: sub.riskPerTrade,
            }));
            logger_1.logger.info(`Found ${subscribers.length} active subscribers for strategy ${strategyId}`);
            return subscribers;
        }
        catch (error) {
            logger_1.logger.error(`Failed to fetch subscribers for strategy ${strategyId}:`, error);
            throw error;
        }
    }
    async executeLive(strategyId, settings) {
        logger_1.logger.info(`Executing live trading for strategy ${strategyId}`);
        try {
            const subscribers = await this.fetchActiveSubscribers(strategyId);
            if (subscribers.length === 0) {
                logger_1.logger.warn(`No active subscribers found for strategy ${strategyId}`);
                return {
                    success: false,
                    mode: 'live',
                    error: 'No active subscribers found',
                };
            }
            const envExists = await strategy_environment_manager_1.strategyEnvironmentManager.environmentExists(strategyId);
            if (!envExists) {
                throw new Error(`Environment not found for strategy ${strategyId}. Strategy must be validated first.`);
            }
            const envInfo = await strategy_environment_manager_1.strategyEnvironmentManager.getEnvironmentInfo(strategyId);
            if (envInfo.status !== 'ready') {
                throw new Error(`Environment is not ready for strategy ${strategyId}: ${envInfo.status}`);
            }
            const strategyFilePath = await this.getStrategyFilePath(strategyId);
            const input = {
                mode: 'live',
                strategy_file: strategyFilePath,
                settings: {
                    ...settings,
                    strategy_id: strategyId,
                },
                subscribers,
            };
            const result = await this.executePythonScript(envInfo.pythonPath, path.join(__dirname, '../../../python/strategy_executor.py'), input);
            const stdoutLines = result.stdout.trim().split('\n');
            const lastJsonLine = stdoutLines[stdoutLines.length - 1];
            const parsedResult = JSON.parse(lastJsonLine);
            if (parsedResult.success) {
                logger_1.logger.info(`Live execution completed successfully for strategy ${strategyId}`);
                logger_1.logger.info(`Executed for ${parsedResult.subscribers_count} subscribers`);
            }
            else {
                logger_1.logger.error(`Live execution failed for strategy ${strategyId}: ${parsedResult.error}`);
            }
            if (parsedResult.success) {
                await this.updateTradeStatistics(strategyId, subscribers.length);
            }
            return parsedResult;
        }
        catch (error) {
            logger_1.logger.error(`Failed to execute live trading for strategy ${strategyId}:`, error);
            return {
                success: false,
                mode: 'live',
                error: error instanceof Error ? error.message : 'Unknown error',
            };
        }
    }
    executePythonScript(pythonPath, scriptPath, input) {
        return new Promise((resolve, reject) => {
            const strategyDir = input.strategy_file ? path.dirname(input.strategy_file) : process.cwd();
            const childProcess = (0, child_process_1.spawn)(pythonPath, [scriptPath], {
                stdio: ['pipe', 'pipe', 'pipe'],
                cwd: strategyDir,
            });
            let stdout = '';
            let stderr = '';
            childProcess.stdin.write(JSON.stringify(input));
            childProcess.stdin.end();
            childProcess.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            childProcess.stderr.on('data', (data) => {
                stderr += data.toString();
            });
            childProcess.on('close', (code) => {
                if (code === 0) {
                    resolve({ stdout, stderr });
                }
                else {
                    reject(new Error(`Process exited with code ${code}\nStderr: ${stderr}\nStdout: ${stdout}`));
                }
            });
            childProcess.on('error', (error) => {
                reject(error);
            });
        });
    }
    executePythonScriptWithProgress(strategyId, pythonPath, scriptPath, input) {
        return new Promise((resolve, reject) => {
            const strategyDir = input.strategy_file ? path.dirname(input.strategy_file) : process.cwd();
            const childProcess = (0, child_process_1.spawn)(pythonPath, [scriptPath], {
                stdio: ['pipe', 'pipe', 'pipe'],
                cwd: strategyDir,
            });
            let stdout = '';
            let stderr = '';
            let stderrBuffer = '';
            childProcess.stdin.write(JSON.stringify(input));
            childProcess.stdin.end();
            childProcess.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            childProcess.stderr.on('data', (data) => {
                const chunk = data.toString();
                stderr += chunk;
                stderrBuffer += chunk;
                const lines = stderrBuffer.split('\n');
                stderrBuffer = lines.pop() || '';
                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed)
                        continue;
                    try {
                        const progressMsg = JSON.parse(trimmed);
                        if (progressMsg.type === 'progress' && progressMsg.stage) {
                            backtest_progress_tracker_1.backtestProgressTracker.updateProgress(strategyId, {
                                stage: progressMsg.stage,
                                progress: progressMsg.progress || 0,
                                message: progressMsg.message || '',
                                totalCandles: progressMsg.total_candles,
                                fetchDuration: progressMsg.fetch_duration,
                                backtestDuration: progressMsg.backtest_duration,
                                totalDuration: progressMsg.total_duration
                            });
                        }
                        else if (progressMsg.type === 'error') {
                            logger_1.logger.error(`Python process error: ${progressMsg.message}`);
                        }
                    }
                    catch (parseError) {
                        logger_1.logger.debug(`Non-JSON stderr line: ${trimmed}`);
                    }
                }
            });
            childProcess.on('close', (code) => {
                if (code === 0) {
                    resolve({ stdout, stderr });
                }
                else {
                    reject(new Error(`Process exited with code ${code}\nStderr: ${stderr}\nStdout: ${stdout}`));
                }
            });
            childProcess.on('error', (error) => {
                reject(error);
            });
        });
    }
    async updateTradeStatistics(strategyId, subscriberCount) {
        try {
            await database_1.default.strategy.update({
                where: { id: strategyId },
                data: {
                    lastDeployedAt: new Date(),
                },
            });
            logger_1.logger.info(`Updated trade statistics for strategy ${strategyId}`);
        }
        catch (error) {
            logger_1.logger.error(`Failed to update trade statistics for strategy ${strategyId}:`, error);
        }
    }
    async getStrategyResolution(strategyId) {
        try {
            const strategyFilePath = await this.getStrategyFilePath(strategyId);
            const content = await fs.readFile(strategyFilePath, 'utf-8');
            const resolutionMatch = content.match(/STRATEGY_CONFIG\s*=\s*{[^}]*['"]resolution['"]\s*:\s*['"](\w+)['"]/);
            if (resolutionMatch && resolutionMatch[1]) {
                const resolution = resolutionMatch[1];
                logger_1.logger.info(`Found resolution '${resolution}' for strategy ${strategyId}`);
                return resolution;
            }
            logger_1.logger.warn(`No resolution found in STRATEGY_CONFIG for strategy ${strategyId}, defaulting to '5m'`);
            return '5m';
        }
        catch (error) {
            logger_1.logger.error(`Failed to get resolution for strategy ${strategyId}:`, error);
            return '5m';
        }
    }
    calculateEquityCurve(trades, initialCapital) {
        if (!trades || trades.length === 0) {
            return {
                data: { timestamps: [], values: [] },
                finalBalance: initialCapital,
                totalReturn: 0
            };
        }
        const timestamps = [];
        const values = [];
        let currentCapital = initialCapital;
        timestamps.push(trades[0].entry_time);
        values.push(initialCapital);
        for (const trade of trades) {
            currentCapital = trade.capital_after_trade || currentCapital;
            timestamps.push(trade.exit_time);
            values.push(currentCapital);
        }
        const finalBalance = currentCapital;
        const totalReturn = finalBalance - initialCapital;
        return {
            data: { timestamps, values },
            finalBalance,
            totalReturn
        };
    }
    calculateMonthlyReturns(trades) {
        if (!trades || trades.length === 0) {
            return {};
        }
        const monthlyData = {};
        for (const trade of trades) {
            const exitDate = new Date(trade.exit_time);
            const monthKey = `${exitDate.getFullYear()}-${String(exitDate.getMonth() + 1).padStart(2, '0')}`;
            if (!monthlyData[monthKey]) {
                monthlyData[monthKey] = { pnl: 0, trades: 0 };
            }
            monthlyData[monthKey].pnl += trade.net_pnl || 0;
            monthlyData[monthKey].trades += 1;
        }
        return monthlyData;
    }
}
exports.StrategyExecutor = StrategyExecutor;
exports.strategyExecutor = new StrategyExecutor();
//# sourceMappingURL=strategy-executor.js.map