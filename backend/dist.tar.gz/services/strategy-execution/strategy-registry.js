"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.strategyRegistry = void 0;
const redis_client_1 = require("../../lib/redis-client");
const client_1 = require("@prisma/client");
const prisma = new client_1.PrismaClient();
class StrategyRegistry {
    constructor() {
        this.cache = new Map();
        this.initialized = false;
    }
    async initialize() {
        if (this.initialized) {
            console.log('Strategy registry already initialized');
            return;
        }
        console.log('Initializing strategy registry from database...');
        try {
            const strategies = await prisma.strategy.findMany({
                where: {
                    isActive: true,
                    subscriberCount: { gt: 0 },
                },
                select: {
                    id: true,
                    executionConfig: true,
                },
            });
            console.log(`Found ${strategies.length} active strategies`);
            for (const strategy of strategies) {
                const config = strategy.executionConfig;
                if (config?.symbol && config?.resolution) {
                    await this.registerStrategy(strategy.id, config.symbol, config.resolution);
                }
            }
            this.initialized = true;
            console.log('Strategy registry initialized successfully');
        }
        catch (error) {
            console.error('Failed to initialize strategy registry:', error);
            throw error;
        }
    }
    async registerStrategy(strategyId, symbol, resolution) {
        const candleKey = this.getCandleKey(symbol, resolution);
        try {
            await redis_client_1.redis.sadd(candleKey, strategyId);
            if (!this.cache.has(candleKey)) {
                this.cache.set(candleKey, new Set());
            }
            this.cache.get(candleKey).add(strategyId);
            await redis_client_1.redis.hset(`strategy:${strategyId}:config`, {
                symbol,
                resolution,
            });
            console.log(`Registered strategy ${strategyId} for ${symbol} ${resolution}`);
        }
        catch (error) {
            console.error(`Failed to register strategy ${strategyId}:`, error);
            throw error;
        }
    }
    async unregisterStrategy(strategyId, symbol, resolution) {
        const candleKey = this.getCandleKey(symbol, resolution);
        try {
            await redis_client_1.redis.srem(candleKey, strategyId);
            this.cache.get(candleKey)?.delete(strategyId);
            const count = await redis_client_1.redis.scard(candleKey);
            if (count === 0) {
                await redis_client_1.redis.del(candleKey);
                this.cache.delete(candleKey);
            }
            await redis_client_1.redis.del(`strategy:${strategyId}:config`);
            console.log(`Unregistered strategy ${strategyId} from ${symbol} ${resolution}`);
        }
        catch (error) {
            console.error(`Failed to unregister strategy ${strategyId}:`, error);
            throw error;
        }
    }
    async getStrategiesForCandle(symbol, resolution) {
        const candleKey = this.getCandleKey(symbol, resolution);
        if (this.cache.has(candleKey)) {
            return Array.from(this.cache.get(candleKey));
        }
        try {
            const strategies = await redis_client_1.redis.smembers(candleKey);
            this.cache.set(candleKey, new Set(strategies));
            return strategies;
        }
        catch (error) {
            console.error(`Failed to get strategies for ${candleKey}:`, error);
            return [];
        }
    }
    async getActiveCandles() {
        try {
            const keys = await redis_client_1.redis.keys('candle:*');
            const candles = keys.map((key) => {
                const parts = key.split(':');
                return {
                    symbol: parts[1],
                    resolution: parts[2]?.replace('m', ''),
                };
            }).filter(c => c.symbol && c.resolution);
            return candles;
        }
        catch (error) {
            console.error('Failed to get active candles:', error);
            return [];
        }
    }
    async updateStrategyRegistration(strategyId, oldSymbol, oldResolution, newSymbol, newResolution) {
        await this.unregisterStrategy(strategyId, oldSymbol, oldResolution);
        await this.registerStrategy(strategyId, newSymbol, newResolution);
        console.log(`Updated strategy ${strategyId} registration: ` +
            `${oldSymbol}/${oldResolution} → ${newSymbol}/${newResolution}`);
    }
    async refreshCache() {
        console.log('Refreshing strategy registry cache from Redis...');
        this.cache.clear();
        const candles = await this.getActiveCandles();
        for (const candle of candles) {
            const strategies = await redis_client_1.redis.smembers(this.getCandleKey(candle.symbol, candle.resolution));
            this.cache.set(this.getCandleKey(candle.symbol, candle.resolution), new Set(strategies));
        }
        console.log(`Refreshed ${this.cache.size} candle mappings`);
    }
    async getStats() {
        const candles = await this.getActiveCandles();
        const totalCandles = candles.length;
        let totalStrategies = 0;
        const candleBreakdown = [];
        for (const candle of candles) {
            const strategies = await this.getStrategiesForCandle(candle.symbol, candle.resolution);
            totalStrategies += strategies.length;
            candleBreakdown.push({
                candle: `${candle.symbol}:${candle.resolution}`,
                strategies: strategies.length,
            });
        }
        return {
            totalCandles,
            totalStrategies,
            candleBreakdown,
        };
    }
    async clear() {
        console.log('Clearing strategy registry...');
        const keys = await redis_client_1.redis.keys('candle:*');
        if (keys.length > 0) {
            await redis_client_1.redis.del(...keys);
        }
        const configKeys = await redis_client_1.redis.keys('strategy:*:config');
        if (configKeys.length > 0) {
            await redis_client_1.redis.del(...configKeys);
        }
        this.cache.clear();
        this.initialized = false;
        console.log('Strategy registry cleared');
    }
    getCandleKey(symbol, resolution) {
        return `candle:${symbol}:${resolution}m`;
    }
}
exports.strategyRegistry = new StrategyRegistry();
if (process.env.NODE_ENV !== 'test') {
    exports.strategyRegistry.initialize().catch(console.error);
}
//# sourceMappingURL=strategy-registry.js.map