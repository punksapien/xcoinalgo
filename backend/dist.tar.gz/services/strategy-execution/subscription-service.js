"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.subscriptionService = void 0;
const client_1 = require("@prisma/client");
const strategy_registry_1 = require("./strategy-registry");
const settings_service_1 = require("./settings-service");
const event_bus_1 = require("../../lib/event-bus");
const prisma = new client_1.PrismaClient();
class SubscriptionService {
    async createSubscription(params) {
        const { userId, strategyId, capital, riskPerTrade, leverage = 1, maxPositions = 1, maxDailyLoss = 0.05, slAtrMultiplier, tpAtrMultiplier, brokerCredentialId, tradingType, marginCurrency, } = params;
        try {
            const existing = await prisma.strategySubscription.findUnique({
                where: {
                    userId_strategyId: {
                        userId,
                        strategyId,
                    },
                },
            });
            if (existing) {
                throw new Error(`User ${userId} is already subscribed to strategy ${strategyId}`);
            }
            const strategy = await prisma.strategy.findUnique({
                where: { id: strategyId },
                select: {
                    id: true,
                    subscriberCount: true,
                    executionConfig: true,
                },
            });
            if (!strategy) {
                throw new Error(`Strategy ${strategyId} not found`);
            }
            const isFirstSubscriber = strategy.subscriberCount === 0;
            const execCfg = strategy?.executionConfig || {};
            const inferredTradingType = tradingType
                ? tradingType
                : (execCfg.symbol?.startsWith('B-') || !!execCfg.supportsFutures)
                    ? 'futures' : 'spot';
            const subscription = await prisma.strategySubscription.create({
                data: {
                    userId,
                    strategyId,
                    capital,
                    riskPerTrade,
                    leverage,
                    maxPositions,
                    maxDailyLoss,
                    slAtrMultiplier,
                    tpAtrMultiplier,
                    brokerCredentialId,
                    tradingType: inferredTradingType,
                    marginCurrency: marginCurrency || 'USDT',
                    isActive: true,
                    isPaused: false,
                },
            });
            await prisma.strategy.update({
                where: { id: strategyId },
                data: {
                    subscriberCount: { increment: 1 },
                },
            });
            await settings_service_1.settingsService.initializeSubscription(userId, strategyId, {
                capital,
                risk_per_trade: riskPerTrade,
                leverage,
                max_positions: maxPositions,
                max_daily_loss: maxDailyLoss,
                sl_atr_multiplier: slAtrMultiplier,
                tp_atr_multiplier: tpAtrMultiplier,
                broker_credential_id: brokerCredentialId,
                is_active: true,
            });
            if (isFirstSubscriber && strategy.executionConfig) {
                const config = strategy.executionConfig;
                if (config.symbol && config.resolution) {
                    await strategy_registry_1.strategyRegistry.registerStrategy(strategyId, config.symbol, config.resolution);
                    console.log(`Registered strategy ${strategyId} for ${config.symbol}/${config.resolution} ` +
                        `(first subscriber)`);
                }
            }
            event_bus_1.eventBus.emit('subscription.created', {
                subscriptionId: subscription.id,
                strategyId,
                userId,
            });
            console.log(`Created subscription ${subscription.id} for user ${userId} ` +
                `on strategy ${strategyId}`);
            return {
                subscriptionId: subscription.id,
                isFirstSubscriber,
            };
        }
        catch (error) {
            console.error('Failed to create subscription:', error);
            throw error;
        }
    }
    async cancelSubscription(subscriptionId) {
        try {
            const subscription = await prisma.strategySubscription.findUnique({
                where: { id: subscriptionId },
                include: {
                    strategy: {
                        select: {
                            id: true,
                            subscriberCount: true,
                            executionConfig: true,
                        },
                    },
                },
            });
            if (!subscription) {
                console.warn(`Subscription ${subscriptionId} not found`);
                return false;
            }
            await prisma.strategySubscription.update({
                where: { id: subscriptionId },
                data: {
                    isActive: false,
                    unsubscribedAt: new Date(),
                },
            });
            await prisma.strategy.update({
                where: { id: subscription.strategyId },
                data: {
                    subscriberCount: { decrement: 1 },
                },
            });
            await settings_service_1.settingsService.updateSubscriptionSettings(subscription.userId, subscription.strategyId, { is_active: false });
            const isLastSubscriber = subscription.strategy.subscriberCount <= 1;
            if (isLastSubscriber && subscription.strategy.executionConfig) {
                const config = subscription.strategy.executionConfig;
                if (config.symbol && config.resolution) {
                    await strategy_registry_1.strategyRegistry.unregisterStrategy(subscription.strategyId, config.symbol, config.resolution);
                    console.log(`Unregistered strategy ${subscription.strategyId} from ` +
                        `${config.symbol}/${config.resolution} (last subscriber)`);
                }
            }
            event_bus_1.eventBus.emit('subscription.cancelled', {
                subscriptionId,
                strategyId: subscription.strategyId,
                userId: subscription.userId,
            });
            console.log(`Cancelled subscription ${subscriptionId}`);
            return true;
        }
        catch (error) {
            console.error(`Failed to cancel subscription ${subscriptionId}:`, error);
            throw error;
        }
    }
    async pauseSubscription(subscriptionId) {
        try {
            const subscription = await prisma.strategySubscription.update({
                where: { id: subscriptionId },
                data: {
                    isPaused: true,
                    pausedAt: new Date(),
                },
            });
            console.log(`Paused subscription ${subscriptionId}`);
            return true;
        }
        catch (error) {
            console.error(`Failed to pause subscription ${subscriptionId}:`, error);
            return false;
        }
    }
    async resumeSubscription(subscriptionId) {
        try {
            await prisma.strategySubscription.update({
                where: { id: subscriptionId },
                data: {
                    isPaused: false,
                    pausedAt: null,
                },
            });
            console.log(`Resumed subscription ${subscriptionId}`);
            return true;
        }
        catch (error) {
            console.error(`Failed to resume subscription ${subscriptionId}:`, error);
            return false;
        }
    }
    async getActiveSubscribers(strategyId) {
        try {
            const subscriptions = await prisma.strategySubscription.findMany({
                where: {
                    strategyId,
                    isActive: true,
                    isPaused: false,
                },
                include: {
                    brokerCredential: {
                        select: {
                            id: true,
                            apiKey: true,
                            apiSecret: true,
                        },
                    },
                },
            });
            return subscriptions;
        }
        catch (error) {
            console.error(`Failed to get active subscribers for strategy ${strategyId}:`, error);
            return [];
        }
    }
    async getUserSubscriptions(userId) {
        try {
            const subscriptions = await prisma.strategySubscription.findMany({
                where: { userId },
                include: {
                    strategy: {
                        select: {
                            id: true,
                            name: true,
                            executionConfig: true,
                        },
                    },
                },
                orderBy: {
                    subscribedAt: 'desc',
                },
            });
            return subscriptions;
        }
        catch (error) {
            console.error(`Failed to get subscriptions for user ${userId}:`, error);
            return [];
        }
    }
    async getSubscriptionById(subscriptionId) {
        try {
            const subscription = await prisma.strategySubscription.findUnique({
                where: { id: subscriptionId },
                include: {
                    strategy: {
                        select: {
                            id: true,
                            name: true,
                            executionConfig: true,
                        },
                    },
                    brokerCredential: {
                        select: {
                            id: true,
                            apiKey: true,
                            apiSecret: true,
                        },
                    },
                },
            });
            return subscription;
        }
        catch (error) {
            console.error(`Failed to get subscription ${subscriptionId}:`, error);
            return null;
        }
    }
    async updateSettings(subscriptionId, updates) {
        try {
            const subscription = await prisma.strategySubscription.update({
                where: { id: subscriptionId },
                data: updates,
            });
            const redisUpdates = {};
            if (updates.capital !== undefined)
                redisUpdates.capital = updates.capital;
            if (updates.riskPerTrade !== undefined)
                redisUpdates.risk_per_trade = updates.riskPerTrade;
            if (updates.leverage !== undefined)
                redisUpdates.leverage = updates.leverage;
            if (updates.maxPositions !== undefined)
                redisUpdates.max_positions = updates.maxPositions;
            if (updates.maxDailyLoss !== undefined)
                redisUpdates.max_daily_loss = updates.maxDailyLoss;
            if (updates.slAtrMultiplier !== undefined)
                redisUpdates.sl_atr_multiplier = updates.slAtrMultiplier;
            if (updates.tpAtrMultiplier !== undefined)
                redisUpdates.tp_atr_multiplier = updates.tpAtrMultiplier;
            await settings_service_1.settingsService.updateSubscriptionSettings(subscription.userId, subscription.strategyId, redisUpdates);
            console.log(`Updated subscription ${subscriptionId} settings: ${Object.keys(updates).join(', ')}`);
            return true;
        }
        catch (error) {
            console.error(`Failed to update subscription ${subscriptionId}:`, error);
            return false;
        }
    }
    async getStats(subscriptionId) {
        try {
            const subscription = await prisma.strategySubscription.findUnique({
                where: { id: subscriptionId },
                select: {
                    totalTrades: true,
                    winningTrades: true,
                    losingTrades: true,
                    totalPnl: true,
                },
            });
            if (!subscription) {
                return null;
            }
            const winRate = subscription.totalTrades > 0
                ? subscription.winningTrades / subscription.totalTrades
                : 0;
            return {
                totalTrades: subscription.totalTrades,
                winningTrades: subscription.winningTrades,
                losingTrades: subscription.losingTrades,
                winRate,
                totalPnl: subscription.totalPnl,
            };
        }
        catch (error) {
            console.error(`Failed to get stats for subscription ${subscriptionId}:`, error);
            return null;
        }
    }
}
exports.subscriptionService = new SubscriptionService();
//# sourceMappingURL=subscription-service.js.map