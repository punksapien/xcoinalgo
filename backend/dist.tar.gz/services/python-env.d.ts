export declare class UvEnvManager {
    private cacheRoot;
    constructor(cacheRoot?: string);
    extractPythonVersion(requirements: string): string | null;
    computeRequirementsHash(requirements: string, pythonVersion?: string): string;
    ensureDir(dir: string): void;
    hasUv(): boolean;
    ensureEnv(requirements: string): {
        pythonPath: string;
        created: boolean;
    };
}
export declare const uvEnvManager: UvEnvManager;
//# sourceMappingURL=python-env.d.ts.map