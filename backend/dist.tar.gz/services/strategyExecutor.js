"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.strategyExecutor = exports.StrategyExecutorClient = void 0;
exports.startHealthCheckMonitoring = startHealthCheckMonitoring;
const axios_1 = __importDefault(require("axios"));
const client_1 = require("@prisma/client");
const database_1 = __importDefault(require("../utils/database"));
const encryption_1 = require("../utils/encryption");
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('StrategyExecutor');
class StrategyExecutorClient {
    constructor(baseUrl = process.env.STRATEGY_EXECUTOR_URL || 'http://localhost:8003') {
        this.baseUrl = baseUrl;
        this.client = axios_1.default.create({
            baseURL: baseUrl,
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
            },
        });
        this.client.interceptors.request.use((config) => {
            logger.info(`Strategy executor request: ${config.method?.toUpperCase()} ${config.url}`);
            return config;
        }, (error) => {
            logger.error('Request interceptor error:', error);
            return Promise.reject(error);
        });
        this.client.interceptors.response.use((response) => response, (error) => {
            logger.error('Strategy executor request failed:', {
                url: error.config?.url,
                status: error.response?.status,
                message: error.response?.data?.message || error.message,
            });
            return Promise.reject(error);
        });
    }
    async healthCheck() {
        try {
            const response = await this.client.get('/health');
            return response.status === 200 && response.data.status === 'healthy';
        }
        catch (error) {
            logger.error('Strategy executor health check failed:', error);
            return false;
        }
    }
    async deployStrategy(deploymentId) {
        try {
            const deployment = await database_1.default.botDeployment.findUnique({
                where: { id: deploymentId },
                include: {
                    user: {
                        include: {
                            brokerCredentials: {
                                where: {
                                    brokerName: 'coindcx',
                                    isActive: true
                                }
                            }
                        }
                    },
                    strategy: true
                }
            });
            if (!deployment) {
                throw new Error('Deployment not found');
            }
            if (!deployment.user.brokerCredentials.length) {
                throw new Error('No active broker credentials found');
            }
            const credentials = deployment.user.brokerCredentials[0];
            const apiKey = (0, encryption_1.decrypt)(credentials.apiKey);
            const apiSecret = (0, encryption_1.decrypt)(credentials.apiSecret);
            const config = {
                name: deployment.strategy.name,
                code: deployment.strategy.code,
                author: deployment.strategy.author,
                description: deployment.strategy.description || undefined,
                leverage: deployment.leverage,
                risk_per_trade: deployment.riskPerTrade,
                pair: deployment.strategy.instrument,
                margin_currency: deployment.marginCurrency,
                resolution: '5',
                lookback_period: 200,
                sl_atr_multiplier: 2.0,
                tp_atr_multiplier: 3.0,
                max_positions: 1,
                max_daily_loss: 0.05,
            };
            const strategyId = `strategy-${deployment.userId}-${deployment.strategyId}`;
            const request = {
                strategy_id: strategyId,
                user_id: deployment.userId,
                deployment_id: deploymentId,
                strategy_code: deployment.strategy.code,
                config,
                execution_interval: deployment.executionInterval,
                api_key: apiKey,
                api_secret: apiSecret,
                auto_start: true
            };
            const response = await this.client.post('/strategies/deploy', request);
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.ACTIVE,
                    startedAt: new Date(),
                    nextExecutionAt: new Date(Date.now() + deployment.executionInterval * 1000),
                    lastHeartbeat: new Date()
                }
            });
            logger.info(`Strategy deployed successfully: ${strategyId}`);
            return {
                success: true,
                strategy_id: strategyId,
                message: response.data.message
            };
        }
        catch (error) {
            logger.error('Failed to deploy strategy:', error);
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.ERROR,
                    errorMessage: error.response?.data?.detail || error.message
                }
            });
            throw new Error(`Strategy deployment failed: ${error.response?.data?.detail || error.message}`);
        }
    }
    async stopStrategy(deploymentId) {
        try {
            const deployment = await database_1.default.botDeployment.findUnique({
                where: { id: deploymentId }
            });
            if (!deployment) {
                throw new Error('Deployment not found');
            }
            const strategyId = `strategy-${deployment.userId}-${deployment.strategyId}`;
            await this.client.post(`/strategies/${strategyId}/stop`);
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.STOPPED,
                    stoppedAt: new Date()
                }
            });
            logger.info(`Strategy stopped: ${strategyId}`);
        }
        catch (error) {
            logger.error('Failed to stop strategy:', error);
            throw new Error(`Failed to stop strategy: ${error.response?.data?.detail || error.message}`);
        }
    }
    async deleteStrategy(deploymentId) {
        try {
            const deployment = await database_1.default.botDeployment.findUnique({
                where: { id: deploymentId }
            });
            if (!deployment) {
                throw new Error('Deployment not found');
            }
            const strategyId = `strategy-${deployment.userId}-${deployment.strategyId}`;
            await this.client.delete(`/strategies/${strategyId}`);
            logger.info(`Strategy deleted: ${strategyId}`);
        }
        catch (error) {
            if (error.response?.status !== 404) {
                logger.error('Failed to delete strategy:', error);
                throw new Error(`Failed to delete strategy: ${error.response?.data?.detail || error.message}`);
            }
        }
    }
    async getStrategyStatus(deploymentId) {
        try {
            const deployment = await database_1.default.botDeployment.findUnique({
                where: { id: deploymentId }
            });
            if (!deployment) {
                return null;
            }
            const strategyId = `strategy-${deployment.userId}-${deployment.strategyId}`;
            const response = await this.client.get(`/strategies/${strategyId}/status`);
            return {
                status: response.data.status,
                stats: response.data.stats
            };
        }
        catch (error) {
            if (error.response?.status === 404) {
                return null;
            }
            logger.error('Failed to get strategy status:', error);
            return null;
        }
    }
    async syncDeploymentStatus(deploymentId) {
        try {
            const statusData = await this.getStrategyStatus(deploymentId);
            if (!statusData) {
                await database_1.default.botDeployment.update({
                    where: { id: deploymentId },
                    data: {
                        status: client_1.BotStatus.CRASHED
                    }
                });
                return;
            }
            let botStatus = client_1.BotStatus.ACTIVE;
            if (statusData.status === 'stopped') {
                botStatus = client_1.BotStatus.STOPPED;
            }
            else if (statusData.status === 'error') {
                botStatus = client_1.BotStatus.ERROR;
            }
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: botStatus,
                    executionCount: statusData.stats.total_executions,
                    successfulExecutions: statusData.stats.successful_executions,
                    failedExecutions: statusData.stats.failed_executions,
                    avgExecutionTime: statusData.stats.avg_execution_time,
                    errorMessage: statusData.stats.last_error || null,
                    lastHeartbeat: new Date()
                }
            });
        }
        catch (error) {
            logger.error('Failed to sync deployment status:', error);
        }
    }
    async healthCheckDeployments() {
        try {
            const activeDeployments = await database_1.default.botDeployment.findMany({
                where: {
                    status: {
                        in: [client_1.BotStatus.ACTIVE, client_1.BotStatus.STARTING]
                    }
                }
            });
            for (const deployment of activeDeployments) {
                await this.syncDeploymentStatus(deployment.id);
            }
            logger.info(`Health check completed for ${activeDeployments.length} deployments`);
        }
        catch (error) {
            logger.error('Health check failed:', error);
        }
    }
}
exports.StrategyExecutorClient = StrategyExecutorClient;
exports.strategyExecutor = new StrategyExecutorClient();
function startHealthCheckMonitoring() {
    setInterval(async () => {
        try {
            await exports.strategyExecutor.healthCheckDeployments();
        }
        catch (error) {
            logger.error('Health check monitoring error:', error);
        }
    }, 30000);
    logger.info('Strategy executor health check monitoring started');
}
//# sourceMappingURL=strategyExecutor.js.map