"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.strategyEnvironmentManager = exports.StrategyEnvironmentManager = void 0;
const child_process_1 = require("child_process");
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const util_1 = require("util");
const child_process_2 = require("child_process");
const logger_1 = require("../utils/logger");
const exec = (0, util_1.promisify)(child_process_2.exec);
const ENVIRONMENTS_BASE_DIR = process.env.STRATEGY_ENVIRONMENTS_DIR ||
    path.join(process.cwd(), 'strategy_environments');
const REQUIREMENTS_FILE = path.join(__dirname, '../../python/strategy_requirements.txt');
const REQUIRED_PYTHON_VERSION = '3.12.12';
const UV_PATHS = [
    process.env.UV_PATH,
    '/home/ubuntu/.local/bin/uv',
    path.join(process.env.HOME || '', '.local', 'bin', 'uv'),
    'uv',
].filter(Boolean);
class StrategyEnvironmentManager {
    constructor() {
        this.environmentCache = new Map();
        this.uvPath = null;
        this.initializeBaseDirectory();
        this.findUvBinary();
    }
    async findUvBinary() {
        for (const uvPath of UV_PATHS) {
            try {
                const { stdout } = await exec(`${uvPath} --version`);
                logger_1.logger.info(`Found uv at: ${uvPath} (${stdout.trim()})`);
                this.uvPath = uvPath;
                return;
            }
            catch (error) {
                continue;
            }
        }
        logger_1.logger.warn('uv binary not found in common locations. Environment creation will fail.');
    }
    async initializeBaseDirectory() {
        try {
            await fs.mkdir(ENVIRONMENTS_BASE_DIR, { recursive: true });
            logger_1.logger.info(`Strategy environments directory initialized at: ${ENVIRONMENTS_BASE_DIR}`);
        }
        catch (error) {
            logger_1.logger.error('Failed to initialize environments directory:', error);
            throw error;
        }
    }
    getEnvironmentPath(strategyId) {
        return path.join(ENVIRONMENTS_BASE_DIR, `strategy-${strategyId}`);
    }
    getPythonPath(strategyId) {
        const envPath = this.getEnvironmentPath(strategyId);
        return path.join(envPath, '.venv', 'bin', 'python3');
    }
    async checkUvInstalled() {
        if (!this.uvPath) {
            await this.findUvBinary();
        }
        if (this.uvPath) {
            return true;
        }
        logger_1.logger.error('uv is not installed. Install it with: curl -LsSf https://astral.sh/uv/install.sh | sh');
        return false;
    }
    async environmentExists(strategyId) {
        const envPath = this.getEnvironmentPath(strategyId);
        const pythonPath = this.getPythonPath(strategyId);
        try {
            await fs.access(pythonPath);
            return true;
        }
        catch {
            return false;
        }
    }
    async createEnvironment(strategyId) {
        const envPath = this.getEnvironmentPath(strategyId);
        const pythonPath = this.getPythonPath(strategyId);
        logger_1.logger.info(`Creating environment for strategy ${strategyId} at ${envPath}`);
        const uvInstalled = await this.checkUvInstalled();
        if (!uvInstalled) {
            throw new Error('uv is not installed. Please install uv first.');
        }
        if (await this.environmentExists(strategyId)) {
            logger_1.logger.info(`Environment already exists for strategy ${strategyId}`);
            return this.getEnvironmentInfo(strategyId);
        }
        const envInfo = {
            strategyId,
            environmentPath: envPath,
            pythonPath,
            createdAt: new Date(),
            status: 'creating',
        };
        this.environmentCache.set(strategyId, envInfo);
        try {
            await fs.mkdir(envPath, { recursive: true });
            logger_1.logger.info(`Creating uv venv with Python ${REQUIRED_PYTHON_VERSION}...`);
            await this.runCommand('uv', ['venv', '--python', REQUIRED_PYTHON_VERSION, '.venv'], envPath);
            logger_1.logger.info('Installing dependencies...');
            await this.runCommand('uv', ['pip', 'install', '-r', REQUIREMENTS_FILE], envPath);
            logger_1.logger.info('Verifying Python installation...');
            const { stdout } = await exec(`${pythonPath} --version`);
            logger_1.logger.info(`Python version: ${stdout.trim()}`);
            envInfo.status = 'ready';
            this.environmentCache.set(strategyId, envInfo);
            logger_1.logger.info(`Environment created successfully for strategy ${strategyId}`);
            return envInfo;
        }
        catch (error) {
            envInfo.status = 'error';
            this.environmentCache.set(strategyId, envInfo);
            logger_1.logger.error(`Failed to create environment for strategy ${strategyId}:`, error);
            try {
                await this.deleteEnvironment(strategyId);
            }
            catch (cleanupError) {
                logger_1.logger.error('Failed to cleanup failed environment:', cleanupError);
            }
            throw new Error(`Failed to create environment: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    async getEnvironmentInfo(strategyId) {
        if (this.environmentCache.has(strategyId)) {
            return this.environmentCache.get(strategyId);
        }
        if (await this.environmentExists(strategyId)) {
            const envInfo = {
                strategyId,
                environmentPath: this.getEnvironmentPath(strategyId),
                pythonPath: this.getPythonPath(strategyId),
                createdAt: new Date(),
                status: 'ready',
            };
            this.environmentCache.set(strategyId, envInfo);
            return envInfo;
        }
        throw new Error(`Environment does not exist for strategy ${strategyId}`);
    }
    async deleteEnvironment(strategyId) {
        const envPath = this.getEnvironmentPath(strategyId);
        logger_1.logger.info(`Deleting environment for strategy ${strategyId}`);
        try {
            await fs.rm(envPath, { recursive: true, force: true });
            this.environmentCache.delete(strategyId);
            logger_1.logger.info(`Environment deleted for strategy ${strategyId}`);
        }
        catch (error) {
            logger_1.logger.error(`Failed to delete environment for strategy ${strategyId}:`, error);
            throw error;
        }
    }
    async executeInEnvironment(strategyId, scriptPath, args = [], env = {}) {
        const envInfo = await this.getEnvironmentInfo(strategyId);
        if (envInfo.status !== 'ready') {
            throw new Error(`Environment is not ready for strategy ${strategyId}`);
        }
        const pythonPath = envInfo.pythonPath;
        logger_1.logger.info(`Executing script ${scriptPath} in environment for strategy ${strategyId}`);
        return new Promise((resolve, reject) => {
            const childProcess = (0, child_process_1.spawn)(pythonPath, [scriptPath, ...args], {
                env: { ...process.env, ...env },
                cwd: path.dirname(scriptPath),
            });
            let stdout = '';
            let stderr = '';
            childProcess.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            childProcess.stderr.on('data', (data) => {
                stderr += data.toString();
            });
            childProcess.on('close', (code) => {
                if (code === 0) {
                    resolve({ stdout, stderr });
                }
                else {
                    reject(new Error(`Process exited with code ${code}\nStderr: ${stderr}`));
                }
            });
            childProcess.on('error', (error) => {
                reject(error);
            });
        });
    }
    async listEnvironments() {
        try {
            const entries = await fs.readdir(ENVIRONMENTS_BASE_DIR);
            return entries
                .filter(entry => entry.startsWith('strategy-'))
                .map(entry => entry.replace('strategy-', ''));
        }
        catch (error) {
            logger_1.logger.error('Failed to list environments:', error);
            return [];
        }
    }
    async cleanupAllEnvironments() {
        logger_1.logger.warn('Cleaning up all strategy environments...');
        const strategyIds = await this.listEnvironments();
        for (const strategyId of strategyIds) {
            await this.deleteEnvironment(strategyId);
        }
        this.environmentCache.clear();
        logger_1.logger.info('All environments cleaned up');
    }
    runCommand(command, args, cwd) {
        return new Promise((resolve, reject) => {
            const actualCommand = command === 'uv' && this.uvPath ? this.uvPath : command;
            const childProcess = (0, child_process_1.spawn)(actualCommand, args, { cwd });
            let stderr = '';
            childProcess.stdout.on('data', (data) => {
                logger_1.logger.debug(data.toString());
            });
            childProcess.stderr.on('data', (data) => {
                stderr += data.toString();
                logger_1.logger.debug(data.toString());
            });
            childProcess.on('close', (code) => {
                if (code === 0) {
                    resolve();
                }
                else {
                    reject(new Error(`Command failed with code ${code}\nStderr: ${stderr}`));
                }
            });
            childProcess.on('error', (error) => {
                reject(error);
            });
        });
    }
}
exports.StrategyEnvironmentManager = StrategyEnvironmentManager;
exports.strategyEnvironmentManager = new StrategyEnvironmentManager();
//# sourceMappingURL=strategy-environment-manager.js.map