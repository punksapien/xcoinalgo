import { ProcessInfo } from '../types';
export interface ContainerInfo {
    containerId: string;
    strategyId: string;
    status: 'running' | 'stopped' | 'error' | 'starting';
    deploymentId: string;
    resourceUsage?: {
        memory: number;
        cpu: number;
    };
}
export declare class DockerProcessManager {
    private static instance;
    private strategyService;
    constructor();
    static getInstance(): DockerProcessManager;
    startBot(deploymentId: string): Promise<ProcessInfo>;
    stopBot(deploymentId: string): Promise<void>;
    getProcessInfo(strategyId: string): Promise<ProcessInfo | null>;
    healthCheck(): Promise<void>;
    listStrategies(): Promise<ContainerInfo[]>;
    getStrategyMetrics(strategyId: string): Promise<any>;
    getStrategySignals(strategyId: string, limit?: number): Promise<any[]>;
    validateStrategy(strategyCode: string, config: any): Promise<any>;
    broadcastMarketData(marketData: any): Promise<void>;
    shutdown(): Promise<void>;
}
export declare function startDockerHealthCheckMonitoring(): void;
//# sourceMappingURL=dockerProcessManager.d.ts.map