interface SpotMarket {
    symbol: string;
    pair: string;
    coindcx_name: string;
    base_currency_short_name: string;
    target_currency_short_name: string;
    status: string;
}
interface FuturesInstrument {
    pair: string;
    base_currency_short_name: string;
    target_currency_short_name: string;
    margin_currency_short_name: string;
    status: string;
}
interface ValidationResult {
    isValid: boolean;
    normalized: string;
    type: 'spot' | 'futures' | 'unknown';
    suggestions: string[];
    market?: SpotMarket | FuturesInstrument;
}
declare class SymbolValidator {
    private spotMarkets;
    private futuresMarkets;
    private lastUpdate;
    private isLoading;
    private loadPromise;
    loadMarkets(force?: boolean): Promise<void>;
    private _loadMarketsInternal;
    validateSymbol(symbol: string): Promise<ValidationResult>;
    private findSuggestions;
    private calculateSimilarity;
    private levenshteinDistance;
    search(query: string, limit?: number): Promise<Array<{
        symbol: string;
        type: 'spot' | 'futures';
        base: string;
        target: string;
    }>>;
    isInitialized(): boolean;
    getAllSymbols(): {
        spot: string[];
        futures: string[];
    };
}
export declare const symbolValidator: SymbolValidator;
export default symbolValidator;
//# sourceMappingURL=symbol-validator.d.ts.map