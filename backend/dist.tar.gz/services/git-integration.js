"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.gitIntegrationService = exports.GitIntegrationService = void 0;
const child_process_1 = require("child_process");
const util_1 = require("util");
const path_1 = __importDefault(require("path"));
const promises_1 = __importDefault(require("fs/promises"));
const database_1 = __importDefault(require("../utils/database"));
const logger_1 = require("../utils/logger");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
class GitIntegrationService {
    constructor() {
        this.workspaceDir = process.env.GIT_WORKSPACE_DIR || '/tmp/strategy-workspace';
        this.ensureWorkspaceDir();
    }
    async ensureWorkspaceDir() {
        try {
            await promises_1.default.mkdir(this.workspaceDir, { recursive: true });
        }
        catch (error) {
            logger_1.logger.error('Failed to create workspace directory:', error);
            throw error;
        }
    }
    async syncRepository(repo) {
        const repoName = this.getRepositoryName(repo.url);
        const localPath = path_1.default.join(this.workspaceDir, repoName);
        try {
            const exists = await this.pathExists(localPath);
            if (exists) {
                await this.pullRepository(localPath, repo.branch);
            }
            else {
                await this.cloneRepository(repo, localPath);
            }
            return localPath;
        }
        catch (error) {
            logger_1.logger.error(`Failed to sync repository ${repo.url}:`, error);
            throw new Error(`Git sync failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    async extractStrategyFiles(repositoryPath, strategyPath) {
        try {
            const basePath = strategyPath ? path_1.default.join(repositoryPath, strategyPath) : repositoryPath;
            const strategyFile = await this.findFile(basePath, ['strategy.py', 'main.py', 'bot.py']);
            const configFile = await this.findFile(basePath, ['config.yaml', 'config.yml', 'config.json']);
            const requirementsFile = await this.findFile(basePath, ['requirements.txt']);
            const readmeFile = await this.findFile(basePath, ['README.md', 'readme.md']);
            if (!strategyFile) {
                throw new Error('No strategy file found (expected strategy.py, main.py, or bot.py)');
            }
            const strategyCode = await promises_1.default.readFile(strategyFile, 'utf-8');
            const requirements = requirementsFile ? await promises_1.default.readFile(requirementsFile, 'utf-8') : '';
            const readme = readmeFile ? await promises_1.default.readFile(readmeFile, 'utf-8') : undefined;
            let configData = {};
            if (configFile) {
                const configContent = await promises_1.default.readFile(configFile, 'utf-8');
                if (configFile.endsWith('.json')) {
                    configData = JSON.parse(configContent);
                }
                else {
                    const yaml = require('yaml');
                    configData = yaml.parse(configContent);
                }
            }
            return {
                strategyCode,
                configData,
                requirements,
                readme
            };
        }
        catch (error) {
            logger_1.logger.error('Failed to extract strategy files:', error);
            throw error;
        }
    }
    async getLatestCommitHash(repositoryPath) {
        try {
            const { stdout } = await execAsync('git rev-parse HEAD', { cwd: repositoryPath });
            return stdout.trim();
        }
        catch (error) {
            logger_1.logger.error('Failed to get commit hash:', error);
            throw error;
        }
    }
    async validateStrategy(strategyCode, configData, requirements) {
        const tempDir = path_1.default.join(this.workspaceDir, 'validation', Date.now().toString());
        try {
            await promises_1.default.mkdir(tempDir, { recursive: true });
            await promises_1.default.writeFile(path_1.default.join(tempDir, 'strategy.py'), strategyCode);
            await promises_1.default.writeFile(path_1.default.join(tempDir, 'config.json'), JSON.stringify(configData, null, 2));
            await promises_1.default.writeFile(path_1.default.join(tempDir, 'requirements.txt'), requirements);
            const validationResult = await this.runPythonValidation(tempDir);
            return validationResult;
        }
        catch (error) {
            logger_1.logger.error('Strategy validation failed:', error);
            return {
                isValid: false,
                errors: [error instanceof Error ? error.message : 'Validation failed'],
                warnings: []
            };
        }
        finally {
            try {
                await promises_1.default.rm(tempDir, { recursive: true, force: true });
            }
            catch (cleanupError) {
                logger_1.logger.warn('Failed to cleanup validation directory:', cleanupError);
            }
        }
    }
    async processWebhook(payload, provider) {
        try {
            const repoUrl = this.extractRepositoryUrl(payload, provider);
            const branch = this.extractBranch(payload, provider);
            const commitHash = this.extractCommitHash(payload, provider);
            const strategy = await database_1.default.strategy.findFirst({
                where: {
                    gitRepository: repoUrl,
                    gitBranch: branch
                }
            });
            if (!strategy) {
                logger_1.logger.warn(`No strategy found for repository ${repoUrl}, branch ${branch}`);
                return;
            }
            await this.syncAndValidateStrategy(strategy.id, {
                url: repoUrl,
                branch: branch
            }, commitHash);
        }
        catch (error) {
            logger_1.logger.error('Webhook processing failed:', error);
            throw error;
        }
    }
    async syncAndValidateStrategy(strategyId, repo, commitHash) {
        try {
            await database_1.default.strategy.update({
                where: { id: strategyId },
                data: {
                    validationStatus: 'VALIDATING',
                    gitCommitHash: commitHash
                }
            });
            const localPath = await this.syncRepository(repo);
            const strategyFiles = await this.extractStrategyFiles(localPath);
            const validationResult = await this.validateStrategy(strategyFiles.strategyCode, strategyFiles.configData, strategyFiles.requirements);
            const updateData = {
                validationStatus: validationResult.isValid ? 'VALID' : 'INVALID',
                validationErrors: validationResult.errors.length > 0 ? JSON.stringify({
                    errors: validationResult.errors,
                    warnings: validationResult.warnings
                }) : null,
                lastValidatedAt: new Date(),
                gitCommitHash: commitHash || await this.getLatestCommitHash(localPath)
            };
            if (validationResult.isValid) {
                updateData.isActive = true;
            }
            await database_1.default.strategy.update({
                where: { id: strategyId },
                data: updateData
            });
            if (validationResult.isValid) {
                const strategy = await database_1.default.strategy.findUnique({ where: { id: strategyId } });
                if (strategy) {
                    await database_1.default.strategyVersion.create({
                        data: {
                            strategyId: strategyId,
                            version: strategy.version,
                            strategyCode: strategyFiles.strategyCode,
                            configData: strategyFiles.configData,
                            requirements: strategyFiles.requirements,
                            gitCommitHash: updateData.gitCommitHash,
                            isValidated: true
                        }
                    });
                }
            }
            logger_1.logger.info(`Strategy ${strategyId} validation completed: ${validationResult.isValid ? 'PASSED' : 'FAILED'}`);
        }
        catch (error) {
            await database_1.default.strategy.update({
                where: { id: strategyId },
                data: {
                    validationStatus: 'INVALID',
                    validationErrors: JSON.stringify({
                        errors: [error instanceof Error ? error.message : 'Validation pipeline failed'],
                        warnings: []
                    }),
                    lastValidatedAt: new Date()
                }
            });
            throw error;
        }
    }
    async pathExists(path) {
        try {
            await promises_1.default.access(path);
            return true;
        }
        catch {
            return false;
        }
    }
    async cloneRepository(repo, localPath) {
        const authUrl = repo.accessToken
            ? repo.url.replace('https://', `https://${repo.accessToken}@`)
            : repo.url;
        await execAsync(`git clone -b ${repo.branch} ${authUrl} ${localPath}`);
    }
    async pullRepository(localPath, branch) {
        await execAsync(`git checkout ${branch}`, { cwd: localPath });
        await execAsync('git pull origin', { cwd: localPath });
    }
    getRepositoryName(url) {
        return url.split('/').pop()?.replace('.git', '') || 'unknown-repo';
    }
    async findFile(basePath, fileNames) {
        for (const fileName of fileNames) {
            const filePath = path_1.default.join(basePath, fileName);
            if (await this.pathExists(filePath)) {
                return filePath;
            }
        }
        return null;
    }
    async runPythonValidation(strategyDir) {
        try {
            const sdkPath = process.env.PYTHON_SDK_PATH || '/Users/macintosh/Developer/coindcx_client/coindcx-trading-platform/python-sdk';
            const validationScript = path_1.default.join(sdkPath, 'coindcx_sdk', 'validation.py');
            const { stdout, stderr } = await execAsync(`python3 ${validationScript} ${strategyDir}`);
            const result = JSON.parse(stdout);
            return {
                isValid: result.is_valid,
                errors: result.errors || [],
                warnings: result.warnings || []
            };
        }
        catch (error) {
            logger_1.logger.warn('Python validation script failed, falling back to basic checks:', error);
            try {
                const { stdout, stderr } = await execAsync(`python3 -m py_compile strategy.py`, { cwd: strategyDir });
                return {
                    isValid: true,
                    errors: [],
                    warnings: ['Advanced validation unavailable, basic syntax check passed']
                };
            }
            catch (syntaxError) {
                return {
                    isValid: false,
                    errors: [syntaxError.stderr || syntaxError.message || 'Python compilation failed'],
                    warnings: []
                };
            }
        }
    }
    extractRepositoryUrl(payload, provider) {
        if (provider === 'github') {
            return payload.repository?.clone_url || payload.repository?.html_url;
        }
        else if (provider === 'gitlab') {
            return payload.project?.http_url_to_repo || payload.project?.web_url;
        }
        throw new Error('Unsupported Git provider');
    }
    extractBranch(payload, provider) {
        if (provider === 'github') {
            return payload.ref?.replace('refs/heads/', '') || 'main';
        }
        else if (provider === 'gitlab') {
            return payload.ref?.replace('refs/heads/', '') || 'main';
        }
        return 'main';
    }
    extractCommitHash(payload, provider) {
        if (provider === 'github') {
            return payload.head_commit?.id || payload.after;
        }
        else if (provider === 'gitlab') {
            return payload.checkout_sha || payload.after;
        }
        throw new Error('Could not extract commit hash');
    }
}
exports.GitIntegrationService = GitIntegrationService;
exports.gitIntegrationService = new GitIntegrationService();
//# sourceMappingURL=git-integration.js.map