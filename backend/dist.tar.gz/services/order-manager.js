"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.orderManager = void 0;
const client_1 = require("@prisma/client");
const coindcx_client_1 = __importDefault(require("./coindcx-client"));
const logger_1 = require("../utils/logger");
const prisma = new client_1.PrismaClient();
const logger = new logger_1.Logger('OrderManager');
class OrderManager {
    async monitorTradeOrders(tradeId) {
        try {
            const trade = await prisma.trade.findUnique({
                where: { id: tradeId },
                include: {
                    subscription: {
                        include: {
                            brokerCredential: true,
                        },
                    },
                },
            });
            if (!trade || !trade.subscription.brokerCredential) {
                logger.warn(`Trade ${tradeId} not found or missing broker credentials`);
                return;
            }
            const metadata = trade.metadata;
            if (!metadata || !metadata.allOrderIds) {
                logger.warn(`Trade ${tradeId} missing order metadata`);
                return;
            }
            const { apiKey, apiSecret } = trade.subscription.brokerCredential;
            const orderStatuses = await Promise.all(metadata.allOrderIds.map(async (orderId) => {
                try {
                    const order = await coindcx_client_1.default.getOrderStatus(apiKey, apiSecret, orderId);
                    const orderType = orderId === metadata.stopLossOrderId ? 'STOP_LOSS' :
                        orderId === metadata.takeProfitOrderId ? 'TAKE_PROFIT' :
                            'ENTRY';
                    return {
                        orderId,
                        status: order.status,
                        filled: order.status === 'filled',
                        orderType,
                    };
                }
                catch (error) {
                    logger.error(`Failed to check order ${orderId}:`, error);
                    return null;
                }
            }));
            const validStatuses = orderStatuses.filter(s => s !== null);
            const stopLossFilled = validStatuses.find(s => s.orderType === 'STOP_LOSS' && s.filled);
            const takeProfitFilled = validStatuses.find(s => s.orderType === 'TAKE_PROFIT' && s.filled);
            if (stopLossFilled) {
                logger.info(`Stop loss triggered for trade ${tradeId}`);
                await this.handleOrderFilled(trade, 'STOP_LOSS', metadata.stopLoss || trade.stopLoss, apiKey, apiSecret);
            }
            else if (takeProfitFilled) {
                logger.info(`Take profit triggered for trade ${tradeId}`);
                await this.handleOrderFilled(trade, 'TAKE_PROFIT', metadata.takeProfit || trade.takeProfit, apiKey, apiSecret);
            }
            const timeExitTriggered = await this.checkTimeBasedExit(trade);
            if (timeExitTriggered)
                return;
            const oppositeSignalTriggered = await this.checkOppositeSignalExit(trade);
            if (oppositeSignalTriggered)
                return;
        }
        catch (error) {
            logger.error(`Failed to monitor trade ${tradeId}:`, error);
        }
    }
    async checkTimeBasedExit(trade) {
        const hoursOpen = (Date.now() - trade.createdAt.getTime()) / 3600000;
        const metadata = trade.metadata;
        const holdPeriod = metadata?.hold_period_hrs || 24;
        if (hoursOpen >= holdPeriod) {
            logger.info(`Trade ${trade.id} hit time exit (${hoursOpen.toFixed(1)}h >= ${holdPeriod}h)`);
            await this.closeTradeManually(trade, 'time_exit');
            return true;
        }
        return false;
    }
    async checkOppositeSignalExit(trade) {
        try {
            const metadata = trade.metadata;
            const entrySignal = metadata?.entrySignal;
            if (!entrySignal) {
                logger.warn(`Trade ${trade.id} missing entrySignal in metadata`);
                return false;
            }
            const latestExecution = await prisma.strategyExecution.findFirst({
                where: {
                    strategyId: metadata?.strategyId || trade.subscription.strategyId,
                    status: 'SUCCESS',
                    executedAt: {
                        gt: trade.createdAt
                    }
                },
                orderBy: { executedAt: 'desc' },
                take: 1
            });
            if (!latestExecution || !latestExecution.signalType) {
                return false;
            }
            const latestSignal = latestExecution.signalType;
            const isOppositeSignal = (entrySignal === 'LONG' && latestSignal === 'SHORT') ||
                (entrySignal === 'SHORT' && latestSignal === 'LONG');
            if (isOppositeSignal) {
                logger.info(`Trade ${trade.id} closing on opposite signal ` +
                    `(entry: ${entrySignal}, latest: ${latestSignal})`);
                await this.closeTradeManually(trade, 'opposite_signal');
                return true;
            }
            return false;
        }
        catch (error) {
            logger.error('Failed to check opposite signal exit:', error);
            return false;
        }
    }
    async closeTradeManually(trade, exitReason) {
        try {
            const { apiKey, apiSecret } = trade.subscription.brokerCredential;
            if (!apiKey || !apiSecret) {
                logger.error(`Missing credentials for trade ${trade.id}`);
                return;
            }
            logger.info(`Closing trade ${trade.id} manually (${exitReason})`);
            const closeOrder = await coindcx_client_1.default.placeMarketOrder(apiKey, apiSecret, {
                market: coindcx_client_1.default.normalizeMarket(trade.symbol),
                side: trade.side === 'LONG' ? 'sell' : 'buy',
                total_quantity: trade.quantity,
                client_order_id: `xcoin_close_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
            });
            await this.cancelTradeOrders(trade.id, apiKey, apiSecret);
            const exitPrice = closeOrder.avg_price || trade.entryPrice;
            const pnl = this.calculatePnl(trade.side, trade.entryPrice, exitPrice, trade.quantity);
            await prisma.trade.update({
                where: { id: trade.id },
                data: {
                    status: 'CLOSED',
                    exitPrice,
                    exitedAt: new Date(),
                    exitReason,
                    pnl,
                    pnlPct: (pnl / (trade.entryPrice * trade.quantity)) * 100,
                    metadata: {
                        ...trade.metadata,
                        exitType: 'MANUAL',
                        exitReason,
                        closeOrderId: closeOrder.id
                    }
                }
            });
            logger.info(`Trade ${trade.id} closed: P&L ${pnl.toFixed(2)} (${exitReason})`);
        }
        catch (error) {
            logger.error(`Failed to close trade ${trade.id} manually:`, error);
            throw error;
        }
    }
    async handleOrderFilled(trade, exitType, exitPrice, apiKey, apiSecret) {
        try {
            const metadata = trade.metadata;
            if (exitType === 'STOP_LOSS' && metadata.takeProfitOrderId) {
                try {
                    await coindcx_client_1.default.cancelOrder(apiKey, apiSecret, metadata.takeProfitOrderId);
                    logger.info(`Cancelled take profit order ${metadata.takeProfitOrderId}`);
                }
                catch (error) {
                    logger.error('Failed to cancel take profit order:', error);
                }
            }
            else if (exitType === 'TAKE_PROFIT' && metadata.stopLossOrderId) {
                try {
                    await coindcx_client_1.default.cancelOrder(apiKey, apiSecret, metadata.stopLossOrderId);
                    logger.info(`Cancelled stop loss order ${metadata.stopLossOrderId}`);
                }
                catch (error) {
                    logger.error('Failed to cancel stop loss order:', error);
                }
            }
            const pnl = this.calculatePnl(trade.side, trade.entryPrice, exitPrice, trade.quantity);
            await prisma.trade.update({
                where: { id: trade.id },
                data: {
                    status: 'CLOSED',
                    exitPrice,
                    exitedAt: new Date(),
                    pnl,
                    pnlPct: (pnl / (trade.entryPrice * trade.quantity)) * 100,
                    metadata: {
                        ...metadata,
                        exitType,
                        closedBy: exitType === 'STOP_LOSS' ? 'stop_loss' : 'take_profit',
                        exitOrderId: exitType === 'STOP_LOSS' ? metadata.stopLossOrderId : metadata.takeProfitOrderId,
                    },
                },
            });
            logger.info(`Trade ${trade.id} closed via ${exitType}: ` +
                `P&L ${pnl.toFixed(2)} (${((pnl / (trade.entryPrice * trade.quantity)) * 100).toFixed(2)}%)`);
        }
        catch (error) {
            logger.error('Failed to handle order filled:', error);
        }
    }
    calculatePnl(side, entryPrice, exitPrice, quantity) {
        if (side === 'LONG') {
            return (exitPrice - entryPrice) * quantity;
        }
        else {
            return (entryPrice - exitPrice) * quantity;
        }
    }
    async monitorAllOpenTrades() {
        try {
            const openTrades = await prisma.trade.findMany({
                where: {
                    status: 'OPEN',
                },
            });
            logger.info(`Monitoring ${openTrades.length} open trades`);
            await Promise.all(openTrades.map(trade => this.monitorTradeOrders(trade.id)));
        }
        catch (error) {
            logger.error('Failed to monitor open trades:', error);
        }
    }
    async cancelTradeOrders(tradeId, apiKey, apiSecret) {
        try {
            const trade = await prisma.trade.findUnique({
                where: { id: tradeId },
            });
            if (!trade) {
                throw new Error(`Trade ${tradeId} not found`);
            }
            const metadata = trade.metadata;
            if (!metadata || !metadata.allOrderIds) {
                return;
            }
            await Promise.all(metadata.allOrderIds.map(async (orderId) => {
                try {
                    await coindcx_client_1.default.cancelOrder(apiKey, apiSecret, orderId);
                    logger.info(`Cancelled order ${orderId} for trade ${tradeId}`);
                }
                catch (error) {
                    logger.error(`Failed to cancel order ${orderId}:`, error);
                }
            }));
        }
        catch (error) {
            logger.error(`Failed to cancel trade orders for ${tradeId}:`, error);
            throw error;
        }
    }
    async getTradeOrderStatus(tradeId) {
        const trade = await prisma.trade.findUnique({
            where: { id: tradeId },
            include: {
                subscription: {
                    include: {
                        brokerCredential: true,
                    },
                },
            },
        });
        if (!trade || !trade.subscription.brokerCredential) {
            throw new Error('Trade not found or missing credentials');
        }
        const { apiKey, apiSecret } = trade.subscription.brokerCredential;
        const metadata = trade.metadata;
        const [entryOrder, stopLossOrder, takeProfitOrder] = await Promise.all([
            metadata.orderId ? coindcx_client_1.default.getOrderStatus(apiKey, apiSecret, metadata.orderId) : null,
            metadata.stopLossOrderId ? coindcx_client_1.default.getOrderStatus(apiKey, apiSecret, metadata.stopLossOrderId) : null,
            metadata.takeProfitOrderId ? coindcx_client_1.default.getOrderStatus(apiKey, apiSecret, metadata.takeProfitOrderId) : null,
        ]);
        return {
            entryOrder,
            stopLossOrder,
            takeProfitOrder,
        };
    }
}
exports.orderManager = new OrderManager();
exports.default = exports.orderManager;
//# sourceMappingURL=order-manager.js.map