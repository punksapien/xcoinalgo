"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.strategyService = exports.StrategyService = void 0;
const axios_1 = __importDefault(require("axios"));
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('StrategyService');
class StrategyService {
    constructor(baseUrl = process.env.STRATEGY_RUNNER_URL || 'http://localhost:8002') {
        this.baseUrl = baseUrl;
        this.client = axios_1.default.create({
            baseURL: baseUrl,
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
            },
        });
        this.client.interceptors.request.use((config) => {
            logger.info(`Making request to strategy service: ${config.method?.toUpperCase()} ${config.url}`);
            return config;
        }, (error) => {
            logger.error('Request interceptor error:', error);
            return Promise.reject(error);
        });
        this.client.interceptors.response.use((response) => response, (error) => {
            logger.error('Strategy service request failed:', {
                url: error.config?.url,
                status: error.response?.status,
                message: error.response?.data?.message || error.message,
            });
            return Promise.reject(error);
        });
    }
    async healthCheck() {
        try {
            const response = await this.client.get('/health');
            return response.status === 200 && response.data.status === 'healthy';
        }
        catch (error) {
            logger.error('Strategy service health check failed:', error);
            return false;
        }
    }
    async deployStrategy(request) {
        try {
            const response = await this.client.post('/strategies/deploy', request);
            logger.info(`Strategy deployed: ${response.data.strategy_id}`);
            return response.data;
        }
        catch (error) {
            logger.error('Failed to deploy strategy:', error);
            throw new Error(`Strategy deployment failed: ${error.response?.data?.message || error.message}`);
        }
    }
    async getStrategyStatus(strategyId) {
        try {
            const response = await this.client.get(`/strategies/${strategyId}/status`);
            return response.data;
        }
        catch (error) {
            if (error.response?.status === 404) {
                throw new Error(`Strategy ${strategyId} not found`);
            }
            logger.error(`Failed to get strategy status for ${strategyId}:`, error);
            throw new Error(`Failed to get strategy status: ${error.response?.data?.message || error.message}`);
        }
    }
    async stopStrategy(strategyId) {
        try {
            const response = await this.client.post(`/strategies/${strategyId}/stop`);
            logger.info(`Strategy ${strategyId} stopped`);
            return response.data.success;
        }
        catch (error) {
            if (error.response?.status === 404) {
                throw new Error(`Strategy ${strategyId} not found`);
            }
            logger.error(`Failed to stop strategy ${strategyId}:`, error);
            throw new Error(`Failed to stop strategy: ${error.response?.data?.message || error.message}`);
        }
    }
    async listStrategies() {
        try {
            const response = await this.client.get('/strategies');
            return response.data.strategies;
        }
        catch (error) {
            logger.error('Failed to list strategies:', error);
            throw new Error(`Failed to list strategies: ${error.response?.data?.message || error.message}`);
        }
    }
    async sendMarketData(marketData) {
        try {
            const response = await this.client.post('/market-data/feed', marketData);
            return response.data.success;
        }
        catch (error) {
            logger.error('Failed to send market data:', error);
            throw new Error(`Failed to send market data: ${error.response?.data?.message || error.message}`);
        }
    }
    async getStrategySignals(strategyId, limit = 10) {
        try {
            const response = await this.client.get(`/signals/${strategyId}`, {
                params: { limit }
            });
            return response.data.signals;
        }
        catch (error) {
            logger.error(`Failed to get signals for strategy ${strategyId}:`, error);
            throw new Error(`Failed to get strategy signals: ${error.response?.data?.message || error.message}`);
        }
    }
    async validateStrategy(strategyCode, config) {
        try {
            const response = await this.client.post('/strategies/validate', {
                strategy_code: strategyCode,
                config: config
            });
            return response.data;
        }
        catch (error) {
            logger.error('Failed to validate strategy:', error);
            throw new Error(`Strategy validation failed: ${error.response?.data?.message || error.message}`);
        }
    }
    async getServiceMetrics() {
        try {
            const response = await this.client.get('/health');
            return response.data;
        }
        catch (error) {
            logger.error('Failed to get service metrics:', error);
            throw new Error(`Failed to get service metrics: ${error.response?.data?.message || error.message}`);
        }
    }
    async getMultipleStrategyStatus(strategyIds) {
        const results = {};
        const batchSize = 5;
        for (let i = 0; i < strategyIds.length; i += batchSize) {
            const batch = strategyIds.slice(i, i + batchSize);
            const promises = batch.map(async (strategyId) => {
                try {
                    const status = await this.getStrategyStatus(strategyId);
                    return { strategyId, status };
                }
                catch (error) {
                    logger.error(`Failed to get status for strategy ${strategyId}:`, error);
                    return {
                        strategyId,
                        status: {
                            success: false,
                            message: error instanceof Error ? error.message : 'Unknown error',
                            strategy_id: strategyId,
                            status: 'error'
                        }
                    };
                }
            });
            const batchResults = await Promise.all(promises);
            batchResults.forEach(({ strategyId, status }) => {
                results[strategyId] = status;
            });
        }
        return results;
    }
}
exports.StrategyService = StrategyService;
exports.strategyService = new StrategyService();
//# sourceMappingURL=strategy-service.js.map