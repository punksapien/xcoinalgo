"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessManager = void 0;
exports.startHealthCheckMonitoring = startHealthCheckMonitoring;
const pm2_1 = __importDefault(require("pm2"));
const util_1 = require("util");
const path_1 = __importDefault(require("path"));
const client_1 = require("@prisma/client");
const database_1 = __importDefault(require("../utils/database"));
const encryption_1 = require("../utils/encryption");
const pm2Connect = (0, util_1.promisify)(pm2_1.default.connect.bind(pm2_1.default));
const pm2Start = (0, util_1.promisify)(pm2_1.default.start.bind(pm2_1.default));
const pm2Stop = (0, util_1.promisify)(pm2_1.default.stop.bind(pm2_1.default));
const pm2Delete = (0, util_1.promisify)(pm2_1.default.delete.bind(pm2_1.default));
const pm2List = (0, util_1.promisify)(pm2_1.default.list.bind(pm2_1.default));
const pm2Disconnect = (0, util_1.promisify)(pm2_1.default.disconnect.bind(pm2_1.default));
class ProcessManager {
    constructor() {
        this.isConnected = false;
    }
    static getInstance() {
        if (!ProcessManager.instance) {
            ProcessManager.instance = new ProcessManager();
        }
        return ProcessManager.instance;
    }
    async ensureConnection() {
        if (!this.isConnected) {
            await pm2Connect();
            this.isConnected = true;
        }
    }
    async startBot(deploymentId) {
        await this.ensureConnection();
        try {
            const deployment = await database_1.default.botDeployment.findUnique({
                where: { id: deploymentId },
                include: {
                    user: {
                        include: {
                            brokerCredentials: {
                                where: {
                                    brokerName: 'coindcx',
                                    isActive: true
                                }
                            }
                        }
                    },
                    strategy: true
                }
            });
            if (!deployment) {
                throw new Error('Bot deployment not found');
            }
            if (!deployment.user.brokerCredentials.length) {
                throw new Error('No active broker credentials found');
            }
            const credentials = deployment.user.brokerCredentials[0];
            const apiKey = (0, encryption_1.decrypt)(credentials.apiKey);
            const apiSecret = (0, encryption_1.decrypt)(credentials.apiSecret);
            const processName = `bot-${deployment.userId}-${deployment.strategyId}`;
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.STARTING,
                    pm2ProcessName: processName,
                    startedAt: new Date()
                }
            });
            const pm2Config = {
                name: processName,
                script: path_1.default.resolve(deployment.strategy.strategyPath || 'strategy.py'),
                args: [
                    `--api-key=${apiKey}`,
                    `--api-secret=${apiSecret}`,
                    `--deployment-id=${deploymentId}`,
                    `--leverage=${deployment.leverage}`,
                    `--risk-per-trade=${deployment.riskPerTrade}`,
                    `--margin-currency=${deployment.marginCurrency}`
                ],
                instances: 1,
                autorestart: true,
                max_restarts: 10,
                restart_delay: 5000,
                env: {
                    NODE_ENV: process.env.NODE_ENV || 'production',
                    DEPLOYMENT_ID: deploymentId
                },
                output: `./logs/${processName}-out.log`,
                error: `./logs/${processName}-error.log`,
                log: `./logs/${processName}-combined.log`,
                time: true
            };
            const proc = await pm2Start(pm2Config);
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    processId: proc[0].process.pid.toString(),
                    status: client_1.BotStatus.ACTIVE,
                    lastHeartbeat: new Date()
                }
            });
            return {
                pid: proc[0].process.pid,
                pm2Id: proc[0].pm_id,
                name: processName,
                status: client_1.BotStatus.ACTIVE
            };
        }
        catch (error) {
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.ERROR,
                    errorMessage: error instanceof Error ? error.message : 'Unknown error'
                }
            });
            throw error;
        }
    }
    async stopBot(deploymentId) {
        await this.ensureConnection();
        try {
            const deployment = await database_1.default.botDeployment.findUnique({
                where: { id: deploymentId }
            });
            if (!deployment || !deployment.pm2ProcessName) {
                throw new Error('Bot deployment not found or not running');
            }
            await pm2Stop(deployment.pm2ProcessName);
            setTimeout(async () => {
                try {
                    await pm2Delete(deployment.pm2ProcessName);
                }
                catch (error) {
                    console.error('Error deleting PM2 process:', error);
                }
            }, 2000);
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.STOPPED,
                    stoppedAt: new Date(),
                    processId: null,
                    pm2ProcessName: null
                }
            });
        }
        catch (error) {
            console.error('Error stopping bot:', error);
            throw error;
        }
    }
    async getProcessInfo(processName) {
        await this.ensureConnection();
        try {
            const list = await pm2List();
            const process = list.find(proc => proc.name === processName);
            if (!process) {
                return null;
            }
            let status = client_1.BotStatus.STOPPED;
            if (process.pm2_env.status === 'online') {
                status = client_1.BotStatus.ACTIVE;
            }
            else if (process.pm2_env.status === 'stopping') {
                status = client_1.BotStatus.STOPPED;
            }
            else if (process.pm2_env.status === 'errored') {
                status = client_1.BotStatus.ERROR;
            }
            else if (process.pm2_env.status === 'launching') {
                status = client_1.BotStatus.STARTING;
            }
            return {
                pid: process.pid,
                pm2Id: process.pm_id,
                name: process.name,
                status,
                uptime: process.pm2_env.pm_uptime,
                memory: process.monit?.memory,
                cpu: process.monit?.cpu
            };
        }
        catch (error) {
            console.error('Error getting process info:', error);
            return null;
        }
    }
    async healthCheck() {
        await this.ensureConnection();
        try {
            const activeDeployments = await database_1.default.botDeployment.findMany({
                where: {
                    status: {
                        in: [client_1.BotStatus.ACTIVE, client_1.BotStatus.STARTING, client_1.BotStatus.UNHEALTHY]
                    },
                    pm2ProcessName: {
                        not: null
                    }
                }
            });
            for (const deployment of activeDeployments) {
                if (!deployment.pm2ProcessName)
                    continue;
                const processInfo = await this.getProcessInfo(deployment.pm2ProcessName);
                if (!processInfo) {
                    await database_1.default.botDeployment.update({
                        where: { id: deployment.id },
                        data: {
                            status: client_1.BotStatus.CRASHED,
                            restartCount: { increment: 1 }
                        }
                    });
                    continue;
                }
                if (processInfo.status !== deployment.status) {
                    await database_1.default.botDeployment.update({
                        where: { id: deployment.id },
                        data: {
                            status: processInfo.status,
                            lastHeartbeat: new Date()
                        }
                    });
                }
                const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
                if (deployment.lastHeartbeat && deployment.lastHeartbeat < fiveMinutesAgo) {
                    await database_1.default.botDeployment.update({
                        where: { id: deployment.id },
                        data: {
                            status: client_1.BotStatus.UNHEALTHY
                        }
                    });
                }
            }
        }
        catch (error) {
            console.error('Health check error:', error);
        }
    }
    async shutdown() {
        if (this.isConnected) {
            await pm2Disconnect();
            this.isConnected = false;
        }
    }
}
exports.ProcessManager = ProcessManager;
function startHealthCheckMonitoring() {
    const processManager = ProcessManager.getInstance();
    setInterval(() => {
        processManager.healthCheck().catch(console.error);
    }, 30000);
    process.on('SIGINT', async () => {
        console.log('Shutting down process manager...');
        await processManager.shutdown();
        process.exit(0);
    });
}
//# sourceMappingURL=processManager.js.map