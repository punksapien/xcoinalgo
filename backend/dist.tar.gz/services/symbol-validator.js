"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.symbolValidator = void 0;
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('SymbolValidator');
const COINDCX_API_BASE = 'https://api.coindcx.com';
class SymbolValidator {
    constructor() {
        this.spotMarkets = new Map();
        this.futuresMarkets = new Map();
        this.lastUpdate = null;
        this.isLoading = false;
        this.loadPromise = null;
    }
    async loadMarkets(force = false) {
        if (this.isLoading && this.loadPromise) {
            return this.loadPromise;
        }
        if (!force && this.lastUpdate) {
            const cacheAge = Date.now() - this.lastUpdate.getTime();
            const CACHE_DURATION = 24 * 60 * 60 * 1000;
            if (cacheAge < CACHE_DURATION) {
                logger.debug(`Using cached markets (age: ${Math.floor(cacheAge / 1000 / 60)} minutes)`);
                return;
            }
        }
        this.isLoading = true;
        this.loadPromise = this._loadMarketsInternal(force);
        try {
            await this.loadPromise;
        }
        finally {
            this.isLoading = false;
            this.loadPromise = null;
        }
    }
    async _loadMarketsInternal(force) {
        try {
            logger.info('Loading markets from CoinDCX...');
            const spotResponse = await fetch(`${COINDCX_API_BASE}/exchange/v1/markets_details`);
            if (!spotResponse.ok) {
                throw new Error(`Failed to fetch spot markets: ${spotResponse.statusText}`);
            }
            const spotMarketsData = await spotResponse.json();
            const spotMarkets = Array.isArray(spotMarketsData) ? spotMarketsData : [];
            this.spotMarkets.clear();
            for (const market of spotMarkets) {
                if (market.status === 'active') {
                    if (typeof market.symbol === 'string' && market.symbol)
                        this.spotMarkets.set(market.symbol, market);
                    if (typeof market.pair === 'string' && market.pair)
                        this.spotMarkets.set(market.pair, market);
                    if (typeof market.coindcx_name === 'string' && market.coindcx_name)
                        this.spotMarkets.set(market.coindcx_name, market);
                }
            }
            logger.info(`Loaded ${this.spotMarkets.size} spot markets`);
            try {
                const buildActiveUrl = (margins) => {
                    const params = new URLSearchParams();
                    for (const m of margins)
                        params.append('margin_currency_short_name[]', m);
                    return `${COINDCX_API_BASE}/exchange/v1/derivatives/futures/data/active_instruments?${params.toString()}`;
                };
                let futuresInstruments = [];
                const activeUsdt = await fetch(buildActiveUrl(['USDT']));
                if (activeUsdt.ok) {
                    const data = await activeUsdt.json();
                    futuresInstruments = Array.isArray(data) ? data : (data.instruments || []);
                }
                if (futuresInstruments.length < 10) {
                    const activeBoth = await fetch(buildActiveUrl(['USDT', 'INR']));
                    if (activeBoth.ok) {
                        const data = await activeBoth.json();
                        futuresInstruments = Array.isArray(data) ? data : (data.instruments || futuresInstruments);
                    }
                }
                if (futuresInstruments.length === 0) {
                    const fallback = await fetch(`${COINDCX_API_BASE}/exchange/v1/derivatives/futures/data/instruments`);
                    if (fallback.ok) {
                        const data = await fallback.json();
                        futuresInstruments = Array.isArray(data) ? data : data?.instruments || [];
                    }
                }
                this.futuresMarkets.clear();
                for (const instrument of futuresInstruments) {
                    if (instrument && (instrument.status === 'active' || !instrument.status)) {
                        if (typeof instrument.pair === 'string' && instrument.pair) {
                            this.futuresMarkets.set(instrument.pair, instrument);
                        }
                    }
                }
                logger.info(`Loaded ${this.futuresMarkets.size} futures markets`);
            }
            catch (error) {
                logger.warn('Error loading futures markets (continuing with spot only):', error);
            }
            this.lastUpdate = new Date();
            logger.info('Markets loaded successfully');
        }
        catch (error) {
            logger.error('Failed to load markets from CoinDCX:', error);
            throw error;
        }
    }
    async validateSymbol(symbol) {
        await this.loadMarkets();
        const normalizedInput = symbol.trim();
        if (this.spotMarkets.has(normalizedInput)) {
            return {
                isValid: true,
                normalized: normalizedInput,
                type: 'spot',
                suggestions: [],
                market: this.spotMarkets.get(normalizedInput),
            };
        }
        if (this.futuresMarkets.has(normalizedInput)) {
            return {
                isValid: true,
                normalized: normalizedInput,
                type: 'futures',
                suggestions: [],
                market: this.futuresMarkets.get(normalizedInput),
            };
        }
        await this.loadMarkets(true);
        if (this.spotMarkets.has(normalizedInput)) {
            return {
                isValid: true,
                normalized: normalizedInput,
                type: 'spot',
                suggestions: [],
                market: this.spotMarkets.get(normalizedInput),
            };
        }
        if (this.futuresMarkets.has(normalizedInput)) {
            return {
                isValid: true,
                normalized: normalizedInput,
                type: 'futures',
                suggestions: [],
                market: this.futuresMarkets.get(normalizedInput),
            };
        }
        const binanceFuturesPattern = /^B-[A-Z0-9]+_USDT$/;
        if (binanceFuturesPattern.test(normalizedInput)) {
            logger.warn(`Heuristic accepting futures symbol ${normalizedInput} (not found in cache)`);
            return {
                isValid: true,
                normalized: normalizedInput,
                type: 'futures',
                suggestions: [],
            };
        }
        const suggestions = this.findSuggestions(normalizedInput);
        return {
            isValid: false,
            normalized: normalizedInput,
            type: 'unknown',
            suggestions,
        };
    }
    findSuggestions(input) {
        const normalizedInput = input.toLowerCase().replace(/[-_/]/g, '');
        const suggestions = [];
        for (const [key, market] of this.spotMarkets.entries()) {
            if (typeof key !== 'string')
                continue;
            const normalizedKey = key.toLowerCase().replace(/[-_/]/g, '');
            if (normalizedKey.includes(normalizedInput) || normalizedInput.includes(normalizedKey)) {
                const score = this.calculateSimilarity(normalizedInput, normalizedKey);
                suggestions.push({ symbol: market.pair || market.symbol, score });
            }
        }
        for (const [key, instrument] of this.futuresMarkets.entries()) {
            if (typeof key !== 'string')
                continue;
            const normalizedKey = key.toLowerCase().replace(/[-_/]/g, '');
            if (normalizedKey.includes(normalizedInput) || normalizedInput.includes(normalizedKey)) {
                const score = this.calculateSimilarity(normalizedInput, normalizedKey);
                suggestions.push({ symbol: instrument.pair, score });
            }
        }
        return suggestions
            .sort((a, b) => b.score - a.score)
            .slice(0, 5)
            .map(s => s.symbol);
    }
    calculateSimilarity(a, b) {
        if (a === b)
            return 100;
        if (b.startsWith(a) || a.startsWith(b))
            return 90;
        if (b.includes(a) || a.includes(b))
            return 80;
        const distance = this.levenshteinDistance(a, b);
        const maxLen = Math.max(a.length, b.length);
        return Math.max(0, 100 - (distance / maxLen) * 100);
    }
    levenshteinDistance(a, b) {
        const matrix = [];
        for (let i = 0; i <= b.length; i++) {
            matrix[i] = [i];
        }
        for (let j = 0; j <= a.length; j++) {
            matrix[0][j] = j;
        }
        for (let i = 1; i <= b.length; i++) {
            for (let j = 1; j <= a.length; j++) {
                if (b.charAt(i - 1) === a.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                }
                else {
                    matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
                }
            }
        }
        return matrix[b.length][a.length];
    }
    async search(query, limit = 10) {
        await this.loadMarkets();
        const normalizedQuery = query.toLowerCase().replace(/[-_/]/g, '');
        const results = [];
        for (const market of this.spotMarkets.values()) {
            const symbolNorm = (market.pair || market.symbol).toLowerCase().replace(/[-_/]/g, '');
            if (symbolNorm.includes(normalizedQuery)) {
                results.push({
                    symbol: market.pair || market.symbol,
                    type: 'spot',
                    base: market.base_currency_short_name,
                    target: market.target_currency_short_name,
                    score: this.calculateSimilarity(normalizedQuery, symbolNorm),
                });
            }
        }
        for (const instrument of this.futuresMarkets.values()) {
            const symbolNorm = instrument.pair.toLowerCase().replace(/[-_/]/g, '');
            if (symbolNorm.includes(normalizedQuery)) {
                results.push({
                    symbol: instrument.pair,
                    type: 'futures',
                    base: instrument.margin_currency_short_name || instrument.base_currency_short_name,
                    target: instrument.target_currency_short_name,
                    score: this.calculateSimilarity(normalizedQuery, symbolNorm),
                });
            }
        }
        return results
            .sort((a, b) => b.score - a.score)
            .slice(0, limit)
            .map(({ symbol, type, base, target }) => ({ symbol, type, base, target }));
    }
    isInitialized() {
        return this.lastUpdate !== null && (this.spotMarkets.size > 0 || this.futuresMarkets.size > 0);
    }
    getAllSymbols() {
        return {
            spot: Array.from(new Set(Array.from(this.spotMarkets.values()).map(m => m.pair || m.symbol))),
            futures: Array.from(this.futuresMarkets.keys()),
        };
    }
}
exports.symbolValidator = new SymbolValidator();
exports.symbolValidator.loadMarkets().catch(err => {
    logger.error('Failed to initialize symbol validator:', err);
});
exports.default = exports.symbolValidator;
//# sourceMappingURL=symbol-validator.js.map