export interface GitRepository {
    url: string;
    branch: string;
    accessToken?: string;
}
export interface StrategyFiles {
    strategyCode: string;
    configData: any;
    requirements: string;
    readme?: string;
}
export declare class GitIntegrationService {
    private readonly workspaceDir;
    constructor();
    private ensureWorkspaceDir;
    syncRepository(repo: GitRepository): Promise<string>;
    extractStrategyFiles(repositoryPath: string, strategyPath?: string): Promise<StrategyFiles>;
    getLatestCommitHash(repositoryPath: string): Promise<string>;
    validateStrategy(strategyCode: string, configData: any, requirements: string): Promise<{
        isValid: boolean;
        errors: string[];
        warnings: string[];
    }>;
    processWebhook(payload: any, provider: 'github' | 'gitlab'): Promise<void>;
    syncAndValidateStrategy(strategyId: string, repo: GitRepository, commitHash?: string): Promise<void>;
    private pathExists;
    private cloneRepository;
    private pullRepository;
    private getRepositoryName;
    private findFile;
    private runPythonValidation;
    private extractRepositoryUrl;
    private extractBranch;
    private extractCommitHash;
}
export declare const gitIntegrationService: GitIntegrationService;
//# sourceMappingURL=git-integration.d.ts.map