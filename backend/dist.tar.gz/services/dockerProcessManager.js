"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DockerProcessManager = void 0;
exports.startDockerHealthCheckMonitoring = startDockerHealthCheckMonitoring;
const axios_1 = __importDefault(require("axios"));
const client_1 = require("@prisma/client");
const database_1 = __importDefault(require("../utils/database"));
const encryption_1 = require("../utils/encryption");
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('DockerProcessManager');
class DockerProcessManager {
    constructor() {
        this.strategyService = axios_1.default.create({
            baseURL: process.env.STRATEGY_RUNNER_URL || 'http://localhost:8002',
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
            },
        });
        this.strategyService.interceptors.request.use((config) => {
            logger.info(`Making request to strategy service: ${config.method?.toUpperCase()} ${config.url}`);
            return config;
        }, (error) => {
            logger.error('Request interceptor error:', error);
            return Promise.reject(error);
        });
        this.strategyService.interceptors.response.use((response) => response, (error) => {
            logger.error('Strategy service request failed:', {
                url: error.config?.url,
                status: error.response?.status,
                message: error.response?.data?.message || error.message,
            });
            return Promise.reject(error);
        });
    }
    static getInstance() {
        if (!DockerProcessManager.instance) {
            DockerProcessManager.instance = new DockerProcessManager();
        }
        return DockerProcessManager.instance;
    }
    async startBot(deploymentId) {
        try {
            const deployment = await database_1.default.botDeployment.findUnique({
                where: { id: deploymentId },
                include: {
                    user: {
                        include: {
                            brokerCredentials: {
                                where: {
                                    brokerName: 'coindcx',
                                    isActive: true
                                }
                            }
                        }
                    },
                    strategy: true
                }
            });
            if (!deployment) {
                throw new Error('Bot deployment not found');
            }
            if (!deployment.user.brokerCredentials.length) {
                throw new Error('No active broker credentials found');
            }
            const credentials = deployment.user.brokerCredentials[0];
            const apiKey = (0, encryption_1.decrypt)(credentials.apiKey);
            const apiSecret = (0, encryption_1.decrypt)(credentials.apiSecret);
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.STARTING,
                    startedAt: new Date()
                }
            });
            const strategyDeploymentRequest = {
                user_id: deployment.userId,
                strategy_code: deployment.strategy.strategyPath || `
# Default strategy code if not provided
from base_strategy import SimpleMovingAverageStrategy

if __name__ == "__main__":
    strategy = SimpleMovingAverageStrategy()
    strategy.start()
        `,
                config: {
                    name: deployment.strategy.name,
                    code: deployment.strategy.code,
                    author: deployment.strategy.author,
                    description: deployment.strategy.description || '',
                    leverage: deployment.leverage,
                    risk_per_trade: deployment.riskPerTrade,
                    pair: deployment.strategy.instrument,
                    margin_currency: deployment.marginCurrency,
                    resolution: '5m',
                    lookback_period: 200,
                    sl_atr_multiplier: 2.0,
                    tp_atr_multiplier: 2.5,
                    max_positions: 1,
                    max_daily_loss: 0.05,
                    custom_params: {}
                },
                auto_start: true,
                environment: 'production',
                resource_limits: {
                    memory: '512m',
                    cpu: '0.5'
                }
            };
            const response = await this.strategyService.post('/strategies/deploy', strategyDeploymentRequest);
            const deploymentResult = response.data;
            if (!deploymentResult.success) {
                throw new Error(deploymentResult.message || 'Strategy deployment failed');
            }
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    pm2ProcessName: deploymentResult.strategy_id,
                    status: client_1.BotStatus.ACTIVE,
                    lastHeartbeat: new Date()
                }
            });
            logger.info(`Strategy deployed successfully: ${deploymentResult.strategy_id}`);
            return {
                pid: 0,
                pm2Id: 0,
                name: deploymentResult.strategy_id,
                status: client_1.BotStatus.ACTIVE,
                containerId: deploymentResult.strategy_id
            };
        }
        catch (error) {
            logger.error(`Failed to start bot ${deploymentId}:`, error);
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.ERROR,
                    errorMessage: error instanceof Error ? error.message : 'Unknown error'
                }
            });
            throw error;
        }
    }
    async stopBot(deploymentId) {
        try {
            const deployment = await database_1.default.botDeployment.findUnique({
                where: { id: deploymentId }
            });
            if (!deployment || !deployment.pm2ProcessName) {
                throw new Error('Bot deployment not found or not running');
            }
            await this.strategyService.post(`/strategies/${deployment.pm2ProcessName}/stop`);
            await database_1.default.botDeployment.update({
                where: { id: deploymentId },
                data: {
                    status: client_1.BotStatus.STOPPED,
                    stoppedAt: new Date(),
                    pm2ProcessName: null
                }
            });
            logger.info(`Strategy stopped successfully: ${deployment.pm2ProcessName}`);
        }
        catch (error) {
            logger.error(`Failed to stop bot ${deploymentId}:`, error);
            throw error;
        }
    }
    async getProcessInfo(strategyId) {
        try {
            const response = await this.strategyService.get(`/strategies/${strategyId}/status`);
            const strategyStatus = response.data;
            if (!strategyStatus.success) {
                return null;
            }
            let status = client_1.BotStatus.STOPPED;
            switch (strategyStatus.status) {
                case 'running':
                    status = client_1.BotStatus.ACTIVE;
                    break;
                case 'starting':
                    status = client_1.BotStatus.STARTING;
                    break;
                case 'stopped':
                    status = client_1.BotStatus.STOPPED;
                    break;
                case 'error':
                    status = client_1.BotStatus.ERROR;
                    break;
            }
            return {
                pid: 0,
                pm2Id: 0,
                name: strategyId,
                status,
                containerId: strategyId,
                uptime: strategyStatus.metrics?.uptime,
                memory: strategyStatus.metrics?.memory,
                cpu: strategyStatus.metrics?.cpu
            };
        }
        catch (error) {
            logger.error(`Failed to get process info for ${strategyId}:`, error);
            return null;
        }
    }
    async healthCheck() {
        try {
            const healthResponse = await this.strategyService.get('/health');
            if (healthResponse.status !== 200) {
                logger.error('Strategy service health check failed');
                return;
            }
            const activeDeployments = await database_1.default.botDeployment.findMany({
                where: {
                    status: {
                        in: [client_1.BotStatus.ACTIVE, client_1.BotStatus.STARTING, client_1.BotStatus.UNHEALTHY]
                    },
                    pm2ProcessName: {
                        not: null
                    }
                }
            });
            for (const deployment of activeDeployments) {
                if (!deployment.pm2ProcessName)
                    continue;
                try {
                    const processInfo = await this.getProcessInfo(deployment.pm2ProcessName);
                    if (!processInfo) {
                        await database_1.default.botDeployment.update({
                            where: { id: deployment.id },
                            data: {
                                status: client_1.BotStatus.CRASHED,
                                restartCount: { increment: 1 }
                            }
                        });
                        continue;
                    }
                    if (processInfo.status !== deployment.status) {
                        await database_1.default.botDeployment.update({
                            where: { id: deployment.id },
                            data: {
                                status: processInfo.status,
                                lastHeartbeat: new Date()
                            }
                        });
                    }
                    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
                    if (deployment.lastHeartbeat && deployment.lastHeartbeat < fiveMinutesAgo) {
                        await database_1.default.botDeployment.update({
                            where: { id: deployment.id },
                            data: {
                                status: client_1.BotStatus.UNHEALTHY
                            }
                        });
                    }
                }
                catch (error) {
                    logger.error(`Failed to check strategy ${deployment.pm2ProcessName}:`, error);
                }
            }
        }
        catch (error) {
            logger.error('Health check error:', error);
        }
    }
    async listStrategies() {
        try {
            const response = await this.strategyService.get('/strategies');
            const strategies = response.data.strategies || [];
            return strategies.map((strategy) => ({
                containerId: strategy.container_id,
                strategyId: strategy.strategy_id,
                status: strategy.status,
                deploymentId: strategy.strategy_id,
                resourceUsage: strategy.resource_usage
            }));
        }
        catch (error) {
            logger.error('Failed to list strategies:', error);
            return [];
        }
    }
    async getStrategyMetrics(strategyId) {
        try {
            const response = await this.strategyService.get(`/strategies/${strategyId}/status`);
            return response.data.metrics || {};
        }
        catch (error) {
            logger.error(`Failed to get metrics for strategy ${strategyId}:`, error);
            return {};
        }
    }
    async getStrategySignals(strategyId, limit = 10) {
        try {
            const response = await this.strategyService.get(`/signals/${strategyId}`, {
                params: { limit }
            });
            return response.data.signals || [];
        }
        catch (error) {
            logger.error(`Failed to get signals for strategy ${strategyId}:`, error);
            return [];
        }
    }
    async validateStrategy(strategyCode, config) {
        try {
            const response = await this.strategyService.post('/strategies/validate', {
                strategy_code: strategyCode,
                config: config
            });
            return response.data;
        }
        catch (error) {
            logger.error('Failed to validate strategy:', error);
            throw new Error(`Strategy validation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    async broadcastMarketData(marketData) {
        try {
            await this.strategyService.post('/market-data/feed', marketData);
        }
        catch (error) {
            logger.error('Failed to broadcast market data:', error);
        }
    }
    async shutdown() {
        logger.info('Shutting down Docker Process Manager...');
        try {
            const activeDeployments = await database_1.default.botDeployment.findMany({
                where: {
                    status: {
                        in: [client_1.BotStatus.ACTIVE, client_1.BotStatus.STARTING]
                    },
                    pm2ProcessName: {
                        not: null
                    }
                }
            });
            for (const deployment of activeDeployments) {
                try {
                    await this.stopBot(deployment.id);
                }
                catch (error) {
                    logger.error(`Failed to stop deployment ${deployment.id} during shutdown:`, error);
                }
            }
        }
        catch (error) {
            logger.error('Error during shutdown:', error);
        }
    }
}
exports.DockerProcessManager = DockerProcessManager;
function startDockerHealthCheckMonitoring() {
    const processManager = DockerProcessManager.getInstance();
    setInterval(() => {
        processManager.healthCheck().catch((error) => {
            logger.error('Health check failed:', error);
        });
    }, 30000);
    process.on('SIGINT', async () => {
        logger.info('Shutting down Docker process manager...');
        await processManager.shutdown();
        process.exit(0);
    });
    process.on('SIGTERM', async () => {
        logger.info('Shutting down Docker process manager...');
        await processManager.shutdown();
        process.exit(0);
    });
}
//# sourceMappingURL=dockerProcessManager.js.map