declare const app: import("express-serve-static-core").Express;
export default app;
//# sourceMappingURL=simple-server.d.ts.map