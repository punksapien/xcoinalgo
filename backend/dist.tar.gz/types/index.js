"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotStatus = void 0;
const client_1 = require("@prisma/client");
Object.defineProperty(exports, "BotStatus", { enumerable: true, get: function () { return client_1.BotStatus; } });
//# sourceMappingURL=index.js.map