"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const express_session_1 = __importDefault(require("express-session"));
const passport_1 = __importDefault(require("passport"));
const passport_google_oauth20_1 = require("passport-google-oauth20");
const database_1 = __importDefault(require("./utils/database"));
const resend_email_1 = require("./utils/resend-email");
const app = (0, express_1.default)();
const PORT = 3001;
app.use((0, express_session_1.default)({
    secret: process.env.SESSION_SECRET || 'xcoinalgo-session-secret-key-2024',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));
passport_1.default.use(new passport_google_oauth20_1.Strategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: '/api/auth/google/callback'
}, async (accessToken, refreshToken, profile, done) => {
    try {
        let user = await database_1.default.user.findUnique({
            where: { email: profile.emails?.[0]?.value }
        });
        if (!user) {
            user = await database_1.default.user.create({
                data: {
                    email: profile.emails?.[0]?.value || '',
                    password: 'google-oauth',
                }
            });
            try {
                const welcomeEmailTemplate = resend_email_1.emailTemplates.welcome(user.email);
                await (0, resend_email_1.sendEmail)(welcomeEmailTemplate);
                console.log(`✅ Welcome email sent to ${user.email}`);
            }
            catch (emailError) {
                console.error(`❌ Failed to send welcome email to ${user.email}:`, emailError);
            }
        }
        return done(null, user);
    }
    catch (error) {
        return done(error, null);
    }
}));
passport_1.default.serializeUser((user, done) => {
    done(null, user.id.toString());
});
passport_1.default.deserializeUser(async (id, done) => {
    try {
        console.log('🔍 Deserializing user ID:', id, typeof id);
        if (!id || typeof id !== 'string') {
            console.log('❌ No valid ID provided for deserialization');
            return done(null, false);
        }
        console.log('✅ Using string user ID:', id);
        const user = await database_1.default.user.findUnique({
            where: { id: id },
            select: { id: true, email: true, createdAt: true }
        });
        if (!user) {
            console.log('❌ User not found for ID:', id);
            return done(null, false);
        }
        console.log('✅ User deserialized successfully:', user.email);
        done(null, user);
    }
    catch (error) {
        console.error('❌ Error in deserializeUser:', error);
        done(error, null);
    }
});
app.use((0, cors_1.default)({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true
}));
app.use(express_1.default.json());
app.use(passport_1.default.initialize());
app.use(passport_1.default.session());
app.get('/health', (req, res) => {
    res.json({ status: 'ok', message: 'Backend is running!' });
});
app.get('/api/strategies', async (req, res) => {
    try {
        const strategies = await database_1.default.strategy.findMany({
            select: {
                id: true,
                name: true,
                code: true,
                description: true,
                author: true,
                instrument: true,
                tags: true,
                winRate: true,
                riskReward: true,
                maxDrawdown: true,
                roi: true,
                marginRequired: true,
                deploymentCount: true,
                createdAt: true
            }
        });
        const formattedStrategies = strategies.map(strategy => ({
            ...strategy,
            tags: strategy.tags ? strategy.tags.split(',') : []
        }));
        res.json({
            strategies: formattedStrategies,
            pagination: {
                page: 1,
                limit: 20,
                total: strategies.length,
                totalPages: 1
            }
        });
    }
    catch (error) {
        console.error('Error fetching strategies:', error);
        res.status(500).json({ error: 'Failed to fetch strategies' });
    }
});
app.get('/api/auth/google', passport_1.default.authenticate('google', { scope: ['profile', 'email'] }));
app.get('/api/auth/google/callback', passport_1.default.authenticate('google', { failureRedirect: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/login` }), (req, res) => {
    res.redirect(`${process.env.FRONTEND_URL || 'http://localhost:3000'}/dashboard`);
});
app.get('/api/auth/me', (req, res) => {
    if (req.isAuthenticated()) {
        res.json({
            user: req.user,
            token: 'google-oauth-token-' + req.user.id
        });
    }
    else {
        res.status(401).json({ error: 'Not authenticated' });
    }
});
app.post('/api/auth/logout', (req, res) => {
    req.logout((err) => {
        if (err) {
            return res.status(500).json({ error: 'Logout failed' });
        }
        res.json({ message: 'Logged out successfully' });
    });
});
app.get('/api/strategies/meta/tags', async (req, res) => {
    try {
        const strategies = await database_1.default.strategy.findMany({
            select: { tags: true }
        });
        const allTags = strategies
            .map(strategy => strategy.tags ? strategy.tags.split(',') : [])
            .flat()
            .filter(tag => tag.trim())
            .map(tag => tag.trim());
        const uniqueTags = [...new Set(allTags)];
        res.json({ tags: uniqueTags });
    }
    catch (error) {
        console.error('Error fetching tags:', error);
        res.status(500).json({ error: 'Failed to fetch tags' });
    }
});
app.get('/api/strategies/meta/authors', async (req, res) => {
    try {
        const strategies = await database_1.default.strategy.findMany({
            select: { author: true }
        });
        const uniqueAuthors = [...new Set(strategies.map(s => s.author).filter(Boolean))];
        res.json({ authors: uniqueAuthors });
    }
    catch (error) {
        console.error('Error fetching authors:', error);
        res.status(500).json({ error: 'Failed to fetch authors' });
    }
});
app.post('/api/auth/forgot-password', async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(400).json({ error: 'Email is required' });
        }
        const user = await database_1.default.user.findUnique({
            where: { email },
            select: { id: true, email: true }
        });
        if (!user) {
            return res.json({
                message: 'If an account with that email exists, we have sent a password reset link.'
            });
        }
        const resetToken = 'reset-' + user.id + '-' + Date.now();
        try {
            const resetEmailTemplate = resend_email_1.emailTemplates.passwordReset(user.email, resetToken);
            await (0, resend_email_1.sendEmail)(resetEmailTemplate);
            console.log(`✅ Password reset email sent to ${user.email}`);
        }
        catch (emailError) {
            console.error(`❌ Failed to send reset email to ${user.email}:`, emailError);
            return res.status(500).json({ error: 'Failed to send reset email' });
        }
        res.json({
            message: 'If an account with that email exists, we have sent a password reset link.'
        });
    }
    catch (error) {
        console.error('Password reset error:', error);
        res.status(500).json({ error: 'Password reset failed' });
    }
});
app.post('/api/broker/keys', (req, res) => {
    res.json({ message: 'API keys stored successfully' });
});
app.get('/api/broker/status', (req, res) => {
    res.json({
        connected: true,
        balance: { INR: 50000 },
        status: 'Connected to CoinDCX'
    });
});
app.delete('/api/broker/keys', (req, res) => {
    res.json({ message: 'API keys deleted successfully' });
});
app.post('/api/bot/start', (req, res) => {
    res.json({
        deploymentId: 'demo-deployment-' + Date.now(),
        message: 'Bot started successfully'
    });
});
app.post('/api/bot/stop', (req, res) => {
    res.json({ message: 'Bot stopped successfully' });
});
app.get('/api/bot/deployments', (req, res) => {
    res.json({ deployments: [], pagination: { page: 1, limit: 10, total: 0 } });
});
app.get('/api/bot/deployments/:id', (req, res) => {
    res.json({
        deployment: {
            id: req.params.id,
            status: 'stopped',
            strategy: 'Demo Strategy',
            pnl: 0
        }
    });
});
app.delete('/api/bot/deployments/:id', (req, res) => {
    res.json({ message: 'Deployment deleted successfully' });
});
app.post('/api/test-email', async (req, res) => {
    try {
        const { to } = req.body;
        if (!to) {
            return res.status(400).json({ error: 'Recipient email is required' });
        }
        await (0, resend_email_1.sendEmail)({
            to,
            subject: 'Test Email from XcoinAlgo Platform 🚀',
            html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #2563eb;">XcoinAlgo Platform</h1>
          <h2>Email Service Test</h2>
          <p>This is a test email to verify that your email service is working correctly!</p>
          <p>✅ If you're reading this, your email configuration is working perfectly.</p>
          <p>Time sent: ${new Date().toISOString()}</p>
        </div>
      `
        });
        console.log(`✅ Test email sent to ${to}`);
        res.json({ message: 'Test email sent successfully!' });
    }
    catch (error) {
        console.error('Test email error:', error);
        res.status(500).json({ error: 'Failed to send test email' });
    }
});
app.listen(PORT, async () => {
    console.log(`🚀 Simple backend running on http://localhost:${PORT}`);
    console.log(`📊 Health check: http://localhost:${PORT}/health`);
    console.log(`📋 Strategies: http://localhost:${PORT}/api/strategies`);
    console.log(`🔐 Google OAuth: http://localhost:${PORT}/api/auth/google`);
    console.log(`👤 Current user: GET http://localhost:${PORT}/api/auth/me`);
    console.log(`📧 Test email: POST http://localhost:${PORT}/api/test-email`);
    const emailReady = await (0, resend_email_1.testEmailConnection)();
    if (emailReady) {
        console.log(`📧 Email service configured and ready!`);
    }
    else {
        console.log(`⚠️  Email service not configured. Update .env file with email settings.`);
    }
    if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
        console.log(`⚠️  Google OAuth not configured. Update .env file with Google credentials.`);
    }
    else {
        console.log(`✅ Google OAuth configured and ready!`);
    }
});
exports.default = app;
//# sourceMappingURL=simple-server.js.map