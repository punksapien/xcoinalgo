export interface EmailOptions {
    to: string;
    subject: string;
    html?: string;
    text?: string;
}
export declare const sendEmail: (options: EmailOptions) => Promise<void>;
export declare const emailTemplates: {
    welcome: (userEmail: string) => {
        to: string;
        subject: string;
        html: string;
    };
    passwordReset: (userEmail: string, resetToken: string) => {
        to: string;
        subject: string;
        html: string;
    };
};
export declare const testEmailConnection: () => Promise<boolean>;
//# sourceMappingURL=resend-email.d.ts.map