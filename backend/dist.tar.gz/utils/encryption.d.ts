export declare function encrypt(text: string): string;
export declare function decrypt(encryptedData: string): string;
//# sourceMappingURL=encryption.d.ts.map