import { PrismaClient } from '@prisma/client';
declare global {
    var __prisma: PrismaClient | undefined;
}
declare let prisma: PrismaClient;
export default prisma;
//# sourceMappingURL=database.d.ts.map