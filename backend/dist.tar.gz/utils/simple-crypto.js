"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encrypt = encrypt;
exports.decrypt = decrypt;
function encrypt(text) {
    return Buffer.from(text).toString('base64');
}
function decrypt(encryptedData) {
    return Buffer.from(encryptedData, 'base64').toString('utf8');
}
//# sourceMappingURL=simple-crypto.js.map