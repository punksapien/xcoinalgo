export declare function encrypt(text: string): string;
export declare function decrypt(encryptedData: string): string;
//# sourceMappingURL=simple-crypto.d.ts.map