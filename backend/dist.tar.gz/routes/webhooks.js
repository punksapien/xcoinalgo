"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.webhookRoutes = void 0;
const express_1 = require("express");
const crypto_1 = __importDefault(require("crypto"));
const database_1 = __importDefault(require("../utils/database"));
const git_integration_1 = require("../services/git-integration");
const logger_1 = require("../utils/logger");
const router = (0, express_1.Router)();
exports.webhookRoutes = router;
function verifyGitHubSignature(payload, signature, secret) {
    const expectedSignature = 'sha256=' + crypto_1.default
        .createHmac('sha256', secret)
        .update(payload)
        .digest('hex');
    return crypto_1.default.timingSafeEqual(Buffer.from(expectedSignature), Buffer.from(signature));
}
function verifyGitLabToken(providedToken, expectedToken) {
    return crypto_1.default.timingSafeEqual(Buffer.from(providedToken), Buffer.from(expectedToken));
}
router.post('/github', async (req, res) => {
    try {
        const signature = req.headers['x-hub-signature-256'];
        const event = req.headers['x-github-event'];
        const payload = JSON.stringify(req.body);
        const secret = process.env.GITHUB_WEBHOOK_SECRET;
        if (secret && signature) {
            if (!verifyGitHubSignature(payload, signature, secret)) {
                return res.status(401).json({ error: 'Invalid signature' });
            }
        }
        if (event === 'push') {
            const branch = req.body.ref?.replace('refs/heads/', '');
            const allowedBranches = ['main', 'master', 'develop'];
            if (allowedBranches.includes(branch)) {
                logger_1.logger.info(`Processing GitHub push event for branch: ${branch}`);
                git_integration_1.gitIntegrationService.processWebhook(req.body, 'github')
                    .catch(error => {
                    logger_1.logger.error('GitHub webhook processing failed:', error);
                });
                res.status(200).json({ message: 'Webhook received and queued for processing' });
            }
            else {
                logger_1.logger.info(`Ignoring push to branch: ${branch}`);
                res.status(200).json({ message: 'Branch ignored' });
            }
        }
        else {
            logger_1.logger.info(`Ignoring GitHub event: ${event}`);
            res.status(200).json({ message: 'Event type ignored' });
        }
    }
    catch (error) {
        logger_1.logger.error('GitHub webhook handler error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
router.post('/gitlab', async (req, res) => {
    try {
        const token = req.headers['x-gitlab-token'];
        const event = req.headers['x-gitlab-event'];
        const expectedToken = process.env.GITLAB_WEBHOOK_TOKEN;
        if (expectedToken && token) {
            if (!verifyGitLabToken(token, expectedToken)) {
                return res.status(401).json({ error: 'Invalid token' });
            }
        }
        if (event === 'Push Hook') {
            const branch = req.body.ref?.replace('refs/heads/', '');
            const allowedBranches = ['main', 'master', 'develop'];
            if (allowedBranches.includes(branch)) {
                logger_1.logger.info(`Processing GitLab push event for branch: ${branch}`);
                git_integration_1.gitIntegrationService.processWebhook(req.body, 'gitlab')
                    .catch(error => {
                    logger_1.logger.error('GitLab webhook processing failed:', error);
                });
                res.status(200).json({ message: 'Webhook received and queued for processing' });
            }
            else {
                logger_1.logger.info(`Ignoring push to branch: ${branch}`);
                res.status(200).json({ message: 'Branch ignored' });
            }
        }
        else {
            logger_1.logger.info(`Ignoring GitLab event: ${event}`);
            res.status(200).json({ message: 'Event type ignored' });
        }
    }
    catch (error) {
        logger_1.logger.error('GitLab webhook handler error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
router.post('/validate/:strategyId', async (req, res) => {
    try {
        const { strategyId } = req.params;
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId }
        });
        if (!strategy) {
            return res.status(404).json({ error: 'Strategy not found' });
        }
        if (!strategy.gitRepository) {
            return res.status(400).json({ error: 'Strategy does not have a Git repository configured' });
        }
        git_integration_1.gitIntegrationService.syncAndValidateStrategy(strategyId, {
            url: strategy.gitRepository,
            branch: strategy.gitBranch || 'main'
        }).catch(error => {
            logger_1.logger.error('Manual validation failed:', error);
        });
        res.json({ message: 'Validation triggered' });
    }
    catch (error) {
        logger_1.logger.error('Manual validation trigger error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
router.get('/validation-status/:strategyId', async (req, res) => {
    try {
        const { strategyId } = req.params;
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId },
            select: {
                validationStatus: true,
                validationErrors: true,
                lastValidatedAt: true,
                gitCommitHash: true
            }
        });
        if (!strategy) {
            return res.status(404).json({ error: 'Strategy not found' });
        }
        const validationErrors = strategy.validationErrors
            ? JSON.parse(strategy.validationErrors)
            : null;
        res.json({
            status: strategy.validationStatus,
            errors: validationErrors?.errors || [],
            warnings: validationErrors?.warnings || [],
            lastValidatedAt: strategy.lastValidatedAt,
            commitHash: strategy.gitCommitHash
        });
    }
    catch (error) {
        logger_1.logger.error('Validation status error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
//# sourceMappingURL=webhooks.js.map