declare const router: import("express-serve-static-core").Router;
export { router as strategyExecutionRoutes };
//# sourceMappingURL=strategy-execution.d.ts.map