"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.marketDataRoutes = void 0;
const express_1 = require("express");
const symbol_validator_1 = require("../services/symbol-validator");
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('MarketData');
const router = (0, express_1.Router)();
exports.marketDataRoutes = router;
router.get('/symbols', async (req, res, next) => {
    try {
        const { search, limit } = req.query;
        if (!search || typeof search !== 'string') {
            return res.status(400).json({
                error: 'Search query is required',
            });
        }
        const maxLimit = Math.min(parseInt(limit) || 10, 50);
        const results = await symbol_validator_1.symbolValidator.search(search, maxLimit);
        res.json({
            query: search,
            count: results.length,
            symbols: results,
        });
    }
    catch (error) {
        logger.error('Symbol search failed:', error);
        next(error);
    }
});
router.get('/validate/:symbol', async (req, res, next) => {
    try {
        const { symbol } = req.params;
        if (!symbol) {
            return res.status(400).json({
                error: 'Symbol is required',
            });
        }
        const validation = await symbol_validator_1.symbolValidator.validateSymbol(symbol);
        res.json(validation);
    }
    catch (error) {
        logger.error('Symbol validation failed:', error);
        next(error);
    }
});
router.get('/all-symbols', async (req, res, next) => {
    try {
        const symbols = symbol_validator_1.symbolValidator.getAllSymbols();
        res.json({
            spot: symbols.spot.length,
            futures: symbols.futures.length,
            symbols,
        });
    }
    catch (error) {
        logger.error('Failed to get all symbols:', error);
        next(error);
    }
});
router.post('/refresh', async (req, res, next) => {
    try {
        logger.info('Refreshing symbols cache...');
        await symbol_validator_1.symbolValidator.loadMarkets(true);
        const symbols = symbol_validator_1.symbolValidator.getAllSymbols();
        res.json({
            success: true,
            message: 'Symbols cache refreshed',
            spot: symbols.spot.length,
            futures: symbols.futures.length,
        });
    }
    catch (error) {
        logger.error('Failed to refresh symbols:', error);
        next(error);
    }
});
//# sourceMappingURL=market-data.js.map