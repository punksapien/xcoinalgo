declare const router: import("express-serve-static-core").Router;
export { router as marketDataRoutes };
//# sourceMappingURL=market-data.d.ts.map