"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.executionAuditRoutes = void 0;
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = __importDefault(require("../utils/database"));
const router = (0, express_1.Router)();
exports.executionAuditRoutes = router;
router.get('/', auth_1.authenticate, async (req, res, next) => {
    try {
        const { strategyId, limit = 50 } = req.query;
        if (!strategyId)
            return res.status(400).json({ error: 'strategyId is required' });
        const rows = await database_1.default.trade.findMany({
            where: { subscription: { strategyId: String(strategyId) } },
            orderBy: { createdAt: 'desc' },
            take: Math.min(Number(limit) || 50, 200)
        });
        const executions = await database_1.default.strategyExecution.findMany({
            where: { strategyId: String(strategyId) },
            orderBy: { executedAt: 'desc' },
            take: 100
        });
        res.json({ trades: rows, executions });
    }
    catch (e) {
        next(e);
    }
});
//# sourceMappingURL=execution-audit.js.map