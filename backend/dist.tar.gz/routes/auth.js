"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRoutes = void 0;
const express_1 = require("express");
const bcrypt_1 = __importDefault(require("bcrypt"));
const passport_1 = __importDefault(require("passport"));
const simple_jwt_1 = require("../utils/simple-jwt");
const database_1 = __importDefault(require("../utils/database"));
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
exports.authRoutes = router;
router.post('/register', async (req, res, next) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({
                error: 'Email and password are required'
            });
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                error: 'Invalid email format'
            });
        }
        if (password.length < 8) {
            return res.status(400).json({
                error: 'Password must be at least 8 characters long'
            });
        }
        const existingUser = await database_1.default.user.findUnique({
            where: { email }
        });
        if (existingUser) {
            return res.status(400).json({
                error: 'User with this email already exists'
            });
        }
        const saltRounds = 12;
        const hashedPassword = await bcrypt_1.default.hash(password, saltRounds);
        const user = await database_1.default.user.create({
            data: {
                email,
                password: hashedPassword
            },
            select: {
                id: true,
                email: true,
                createdAt: true
            }
        });
        const token = (0, simple_jwt_1.generateToken)({
            userId: user.id,
            email: user.email
        });
        res.status(201).json({
            message: 'User registered successfully',
            user,
            token
        });
    }
    catch (error) {
        next(error);
    }
});
router.post('/login', async (req, res, next) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({
                error: 'Email and password are required'
            });
        }
        const user = await database_1.default.user.findUnique({
            where: { email }
        });
        if (!user) {
            return res.status(401).json({
                error: 'Invalid email or password'
            });
        }
        const isPasswordValid = await bcrypt_1.default.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({
                error: 'Invalid email or password'
            });
        }
        const token = (0, simple_jwt_1.generateToken)({
            userId: user.id,
            email: user.email
        });
        res.json({
            message: 'Login successful',
            user: {
                id: user.id,
                email: user.email,
                createdAt: user.createdAt
            },
            token
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/me', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const user = await database_1.default.user.findUnique({
            where: { id: userId },
            select: {
                id: true,
                email: true,
                createdAt: true,
                updatedAt: true
            }
        });
        if (!user) {
            return res.status(404).json({
                error: 'User not found'
            });
        }
        res.json({
            user
        });
    }
    catch (error) {
        next(error);
    }
});
router.post('/logout', (req, res) => {
    try {
        if (req.session) {
            req.session.destroy((err) => {
                if (err) {
                    console.error('Session destruction error:', err);
                }
            });
        }
        res.json({
            message: 'Logged out successfully'
        });
    }
    catch (error) {
        console.error('Logout error:', error);
        res.status(500).json({
            error: 'Logout failed'
        });
    }
});
router.post('/google-auth', async (req, res, next) => {
    try {
        const { email, name, googleId, image } = req.body;
        if (!email || !googleId) {
            return res.status(400).json({
                error: 'Email and Google ID are required'
            });
        }
        let user = await database_1.default.user.findUnique({
            where: { email },
            select: {
                id: true,
                email: true,
                createdAt: true
            }
        });
        if (!user) {
            user = await database_1.default.user.create({
                data: {
                    email,
                    password: await bcrypt_1.default.hash(Math.random().toString(36), 12),
                },
                select: {
                    id: true,
                    email: true,
                    createdAt: true
                }
            });
        }
        const token = (0, simple_jwt_1.generateToken)({
            userId: user.id,
            email: user.email
        });
        res.json({
            message: 'Google authentication successful',
            user: {
                id: user.id,
                email: user.email,
                createdAt: user.createdAt
            },
            token
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/google', passport_1.default.authenticate('google', { scope: ['profile', 'email'] }));
router.get('/google/callback', passport_1.default.authenticate('google', { failureRedirect: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/login?error=oauth_failed` }), (req, res) => {
    const user = req.user;
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
    if (user && user.token) {
        res.redirect(`${frontendUrl}/dashboard?token=${user.token}&email=${user.email}`);
    }
    else {
        res.redirect(`${frontendUrl}/login?error=oauth_failed`);
    }
});
//# sourceMappingURL=auth.js.map