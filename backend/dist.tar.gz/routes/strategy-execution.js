"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.strategyExecutionRoutes = void 0;
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const CoinDCXClient = __importStar(require("../services/coindcx-client"));
const database_1 = __importDefault(require("../utils/database"));
const subscription_service_1 = require("../services/strategy-execution/subscription-service");
const settings_service_1 = require("../services/strategy-execution/settings-service");
const execution_coordinator_1 = require("../services/strategy-execution/execution-coordinator");
const router = (0, express_1.Router)();
exports.strategyExecutionRoutes = router;
router.post('/deploy', auth_1.authenticate, async (req, res, next) => {
    try {
        const { strategyId } = req.body;
        const userId = req.userId;
        if (!strategyId) {
            return res.status(400).json({
                error: 'Strategy ID is required'
            });
        }
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId },
            select: {
                id: true,
                name: true,
                isActive: true,
                executionConfig: true
            }
        });
        if (!strategy || !strategy.isActive) {
            return res.status(404).json({
                error: 'Strategy not found or not active'
            });
        }
        const executionConfig = strategy.executionConfig;
        if (!executionConfig || !executionConfig.symbol || !executionConfig.resolution) {
            return res.status(400).json({
                error: 'Strategy execution config is invalid. Must contain symbol and resolution.'
            });
        }
        const initialized = await settings_service_1.settingsService.initializeStrategy(strategyId, {
            symbol: executionConfig.symbol,
            resolution: executionConfig.resolution,
            lookback_period: executionConfig.lookbackPeriod || 200,
            ...executionConfig
        }, 1);
        if (!initialized) {
            return res.status(500).json({
                error: 'Failed to initialize strategy settings'
            });
        }
        res.json({
            message: 'Strategy deployed successfully',
            strategy: {
                id: strategy.id,
                name: strategy.name,
                symbol: executionConfig.symbol,
                resolution: executionConfig.resolution
            }
        });
    }
    catch (error) {
        next(error);
    }
});
router.post('/:id/subscribe', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: strategyId } = req.params;
        const userId = req.userId;
        const { capital, riskPerTrade, leverage = 1, maxPositions = 1, maxDailyLoss = 0.05, slAtrMultiplier, tpAtrMultiplier, brokerCredentialId, tradingType, marginCurrency } = req.body;
        if (!capital || !riskPerTrade || !brokerCredentialId) {
            return res.status(400).json({
                error: 'Missing required fields: capital, riskPerTrade, brokerCredentialId'
            });
        }
        const brokerCredential = await database_1.default.brokerCredential.findFirst({
            where: {
                id: brokerCredentialId,
                userId,
                isActive: true
            }
        });
        if (!brokerCredential) {
            return res.status(404).json({
                error: 'Broker credentials not found or inactive'
            });
        }
        try {
            const strategy = await database_1.default.strategy.findUnique({
                where: { id: strategyId },
                select: { executionConfig: true }
            });
            const execCfg = strategy?.executionConfig || {};
            const symbol = execCfg.executionConfig?.symbol || execCfg.pair;
            try {
                const wallets = await CoinDCXClient.getFuturesWallets(brokerCredential.apiKey, brokerCredential.apiSecret);
                const calculateAvailable = (wallet) => {
                    const balance = Number(wallet.balance || 0);
                    const locked = Number(wallet.locked_balance || 0);
                    const crossOrder = Number(wallet.cross_order_margin || 0);
                    const crossUser = Number(wallet.cross_user_margin || 0);
                    return balance - (locked + crossOrder + crossUser);
                };
                const usdtWallet = wallets.find(w => w.currency_short_name === 'USDT');
                const inrWallet = wallets.find(w => w.currency_short_name === 'INR');
                const primaryWallet = usdtWallet || inrWallet;
                if (!primaryWallet) {
                    return res.status(400).json({
                        error: 'No futures wallet found. Please ensure you have a USDT or INR futures wallet on CoinDCX.'
                    });
                }
                const currency = primaryWallet.currency_short_name;
                const symbol = currency === 'INR' ? '₹' : '$';
                const available = calculateAvailable(primaryWallet);
                if (!isFinite(available) || available < Number(capital)) {
                    return res.status(400).json({
                        error: `Insufficient ${currency} futures wallet balance. Required: ${symbol}${capital}, Available: ${symbol}${available.toFixed(2)}. Please deposit ${currency} to your CoinDCX futures wallet.`
                    });
                }
            }
            catch (walletErr) {
                const errorMsg = walletErr.message || String(walletErr);
                if (errorMsg.includes('not_found') || errorMsg.includes('404')) {
                    return res.status(400).json({
                        error: 'Unable to access CoinDCX futures wallet. Please ensure your API key has futures trading permissions enabled.',
                        details: 'Go to CoinDCX → Settings → API Management → Edit your API key → Enable "Futures Trading" permission'
                    });
                }
                if (errorMsg.includes('401') || errorMsg.includes('Authentication')) {
                    return res.status(400).json({
                        error: 'Invalid API credentials. Please reconnect your broker account.',
                        details: errorMsg
                    });
                }
                return res.status(400).json({
                    error: 'Failed to validate futures wallet balance',
                    details: errorMsg
                });
            }
        }
        catch (balanceErr) {
            return res.status(400).json({
                error: 'Failed to validate broker balance',
                details: String(balanceErr)
            });
        }
        const result = await subscription_service_1.subscriptionService.createSubscription({
            userId,
            strategyId,
            capital,
            riskPerTrade,
            leverage,
            maxPositions,
            maxDailyLoss,
            slAtrMultiplier,
            tpAtrMultiplier,
            brokerCredentialId,
            tradingType,
            marginCurrency
        });
        res.json({
            message: 'Successfully subscribed to strategy',
            subscription: {
                id: result.subscriptionId,
                strategyId,
                isFirstSubscriber: result.isFirstSubscriber,
                capital,
                riskPerTrade,
                leverage
            }
        });
    }
    catch (error) {
        next(error);
    }
});
router.put('/:id/settings', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: strategyId } = req.params;
        const userId = req.userId;
        const updates = req.body;
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId },
            select: { isActive: true }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        if (!strategy.isActive) {
            return res.status(400).json({
                error: 'Cannot update inactive strategy'
            });
        }
        const updated = await settings_service_1.settingsService.updateStrategySettings(strategyId, updates, true);
        if (!updated) {
            return res.status(500).json({
                error: 'Failed to update strategy settings'
            });
        }
        const newSettings = await settings_service_1.settingsService.getStrategySettings(strategyId, false);
        res.json({
            message: 'Strategy settings updated successfully',
            settings: newSettings
        });
    }
    catch (error) {
        next(error);
    }
});
router.put('/subscriptions/:id', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: subscriptionId } = req.params;
        const userId = req.userId;
        const { capital, riskPerTrade, leverage, maxPositions, maxDailyLoss, slAtrMultiplier, tpAtrMultiplier } = req.body;
        const subscription = await database_1.default.strategySubscription.findFirst({
            where: {
                id: subscriptionId,
                userId
            }
        });
        if (!subscription) {
            return res.status(404).json({
                error: 'Subscription not found'
            });
        }
        const updates = {};
        if (capital !== undefined)
            updates.capital = capital;
        if (riskPerTrade !== undefined)
            updates.riskPerTrade = riskPerTrade;
        if (leverage !== undefined)
            updates.leverage = leverage;
        if (maxPositions !== undefined)
            updates.maxPositions = maxPositions;
        if (maxDailyLoss !== undefined)
            updates.maxDailyLoss = maxDailyLoss;
        if (slAtrMultiplier !== undefined)
            updates.slAtrMultiplier = slAtrMultiplier;
        if (tpAtrMultiplier !== undefined)
            updates.tpAtrMultiplier = tpAtrMultiplier;
        if (Object.keys(updates).length === 0) {
            return res.status(400).json({
                error: 'No updates provided'
            });
        }
        const updated = await subscription_service_1.subscriptionService.updateSettings(subscriptionId, updates);
        if (!updated) {
            return res.status(500).json({
                error: 'Failed to update subscription settings'
            });
        }
        const updatedSubscription = await subscription_service_1.subscriptionService.getSubscriptionById(subscriptionId);
        res.json({
            message: 'Subscription settings updated successfully',
            subscription: updatedSubscription
        });
    }
    catch (error) {
        next(error);
    }
});
router.post('/subscriptions/:id/pause', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: subscriptionId } = req.params;
        const userId = req.userId;
        const subscription = await database_1.default.strategySubscription.findFirst({
            where: {
                id: subscriptionId,
                userId
            }
        });
        if (!subscription) {
            return res.status(404).json({
                error: 'Subscription not found'
            });
        }
        const paused = await subscription_service_1.subscriptionService.pauseSubscription(subscriptionId);
        if (!paused) {
            return res.status(500).json({
                error: 'Failed to pause subscription'
            });
        }
        res.json({
            message: 'Subscription paused successfully'
        });
    }
    catch (error) {
        next(error);
    }
});
router.post('/subscriptions/:id/resume', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: subscriptionId } = req.params;
        const userId = req.userId;
        const subscription = await database_1.default.strategySubscription.findFirst({
            where: {
                id: subscriptionId,
                userId
            }
        });
        if (!subscription) {
            return res.status(404).json({
                error: 'Subscription not found'
            });
        }
        const resumed = await subscription_service_1.subscriptionService.resumeSubscription(subscriptionId);
        if (!resumed) {
            return res.status(500).json({
                error: 'Failed to resume subscription'
            });
        }
        res.json({
            message: 'Subscription resumed successfully'
        });
    }
    catch (error) {
        next(error);
    }
});
router.delete('/subscriptions/:id', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: subscriptionId } = req.params;
        const userId = req.userId;
        const subscription = await database_1.default.strategySubscription.findFirst({
            where: {
                id: subscriptionId,
                userId
            }
        });
        if (!subscription) {
            return res.status(404).json({
                error: 'Subscription not found'
            });
        }
        const cancelled = await subscription_service_1.subscriptionService.cancelSubscription(subscriptionId);
        if (!cancelled) {
            return res.status(500).json({
                error: 'Failed to cancel subscription'
            });
        }
        res.json({
            message: 'Subscription cancelled successfully'
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/subscriptions/:id/stats', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: subscriptionId } = req.params;
        const userId = req.userId;
        const subscription = await database_1.default.strategySubscription.findFirst({
            where: {
                id: subscriptionId,
                userId
            }
        });
        if (!subscription) {
            return res.status(404).json({
                error: 'Subscription not found'
            });
        }
        const stats = await subscription_service_1.subscriptionService.getStats(subscriptionId);
        res.json({
            subscription: {
                id: subscriptionId,
                strategyId: subscription.strategyId
            },
            stats
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/subscriptions', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const subscriptions = await subscription_service_1.subscriptionService.getUserSubscriptions(userId);
        const subscriptionsWithStats = await Promise.all(subscriptions.map(async (sub) => {
            const trades = await database_1.default.trade.findMany({
                where: { subscriptionId: sub.id },
                select: {
                    pnl: true,
                    status: true,
                    createdAt: true,
                }
            });
            const totalTrades = trades.length;
            const openPositions = trades.filter(t => t.status === 'OPEN').length;
            const closedTrades = trades.filter(t => t.status === 'CLOSED');
            const totalPnl = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
            const winningTrades = closedTrades.filter(t => (t.pnl || 0) > 0).length;
            const winRate = closedTrades.length > 0 ? (winningTrades / closedTrades.length) * 100 : 0;
            return {
                ...sub,
                liveStats: {
                    totalTrades,
                    openPositions,
                    totalPnl,
                    winRate,
                    closedTrades: closedTrades.length,
                }
            };
        }));
        res.json({
            subscriptions: subscriptionsWithStats
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/:id/stats', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: strategyId } = req.params;
        const stats = await execution_coordinator_1.executionCoordinator.getExecutionStats(strategyId);
        res.json({
            strategyId,
            stats
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/subscription/:id/verify-live', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id: subscriptionId } = req.params;
        const userId = req.userId;
        const subscription = await database_1.default.strategySubscription.findFirst({
            where: {
                id: subscriptionId,
                userId
            },
            include: {
                strategy: {
                    select: {
                        name: true,
                        executionConfig: true
                    }
                },
                brokerCredential: {
                    select: {
                        apiKey: true,
                        apiSecret: true
                    }
                }
            }
        });
        if (!subscription) {
            return res.status(404).json({
                error: 'Subscription not found'
            });
        }
        if (!subscription.brokerCredential) {
            return res.status(400).json({
                error: 'No broker credentials found for this subscription'
            });
        }
        const executionConfig = subscription.strategy?.executionConfig;
        const tradingPair = executionConfig?.symbol || executionConfig?.pair || 'UNKNOWN';
        try {
            const timestamp = Date.now();
            const body = {
                timestamp,
                status: 'open',
                side: 'buy,sell',
                page: '1',
                size: '100',
                margin_currency_short_name: ['INR', 'USDT']
            };
            const orders = await CoinDCXClient.listFuturesOrders(subscription.brokerCredential.apiKey, subscription.brokerCredential.apiSecret, body);
            const strategyOrders = orders.filter((order) => order.pair === tradingPair && order.status === 'open');
            res.json({
                subscriptionId,
                strategyName: subscription.strategy?.name,
                tradingPair,
                isLiveOnCoinDCX: strategyOrders.length > 0,
                openOrdersCount: strategyOrders.length,
                totalOpenOrders: orders.length,
                orders: strategyOrders.map((order) => ({
                    id: order.id,
                    pair: order.pair,
                    side: order.side,
                    orderType: order.order_type,
                    price: order.price,
                    quantity: order.total_quantity,
                    remaining: order.remaining_quantity,
                    leverage: order.leverage,
                    createdAt: order.created_at
                }))
            });
        }
        catch (coindcxError) {
            return res.status(500).json({
                error: 'Failed to verify with CoinDCX',
                details: coindcxError.message,
                subscriptionId,
                strategyName: subscription.strategy?.name
            });
        }
    }
    catch (error) {
        next(error);
    }
});
//# sourceMappingURL=strategy-execution.js.map