declare const router: import("express-serve-static-core").Router;
export { router as webhookRoutes };
//# sourceMappingURL=webhooks.d.ts.map