"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.strategyUploadRoutes = void 0;
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const auth_1 = require("../middleware/auth");
const strategy_service_1 = require("../services/strategy-service");
const database_1 = __importDefault(require("../utils/database"));
const logger_1 = require("../utils/logger");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const uuid_1 = require("uuid");
const child_process_1 = require("child_process");
const python_env_1 = require("../services/python-env");
const strategy_structure_validator_1 = require("../services/strategy-structure-validator");
const strategy_environment_manager_1 = require("../services/strategy-environment-manager");
const strategy_executor_1 = require("../services/strategy-execution/strategy-executor");
const logger = new logger_1.Logger('StrategyUpload');
const router = (0, express_1.Router)();
exports.strategyUploadRoutes = router;
function calculateMarginFromConfig(config) {
    let marginRequired = null;
    let marginCurrency = 'INR';
    const pair = config.pair || config.instrument || '';
    if (pair.startsWith('B-')) {
        marginCurrency = 'USDT';
    }
    if (config.riskProfile) {
        const { recommendedCapital, leverage } = config.riskProfile;
        if (recommendedCapital && leverage && leverage > 0) {
            if (marginCurrency === 'USDT' && leverage > 1) {
                marginRequired = recommendedCapital / leverage;
            }
            else {
                marginRequired = recommendedCapital;
            }
        }
        else if (recommendedCapital) {
            marginRequired = recommendedCapital;
        }
    }
    return { marginRequired, marginCurrency };
}
async function executeLiveTraderBacktest(strategyCode, requirementsTxt, config) {
    return new Promise((resolve, reject) => {
        logger.info('Setting up isolated Python environment for backtest...');
        const env = python_env_1.uvEnvManager.ensureEnv(requirementsTxt);
        if (!fs.existsSync(env.pythonPath)) {
            logger.error(`Python path not found: ${env.pythonPath}`);
            return reject(new Error('Failed to create Python environment for backtest'));
        }
        if (env.created) {
            logger.info(`Created new Python environment: ${env.pythonPath}`);
        }
        else {
            logger.info(`Using cached Python environment: ${env.pythonPath}`);
        }
        const pythonScript = path.join(__dirname, '../../python/livetrader_backtest_executor.py');
        const pythonProcess = (0, child_process_1.spawn)(env.pythonPath, [pythonScript], {
            stdio: ['pipe', 'pipe', 'pipe']
        });
        let stdout = '';
        let stderr = '';
        pythonProcess.stdout.on('data', (data) => {
            stdout += data.toString();
        });
        pythonProcess.stderr.on('data', (data) => {
            stderr += data.toString();
            logger.debug(`LiveTrader backtest stderr: ${data.toString()}`);
        });
        pythonProcess.on('close', (code) => {
            if (code !== 0) {
                logger.error(`LiveTrader backtest failed with code ${code}`);
                logger.error(`Stderr: ${stderr}`);
                return reject(new Error(`Backtest process exited with code ${code}`));
            }
            try {
                const result = JSON.parse(stdout);
                resolve(result);
            }
            catch (parseError) {
                logger.error('Failed to parse backtest result:', parseError);
                logger.error('Stdout:', stdout);
                reject(new Error('Failed to parse backtest result'));
            }
        });
        pythonProcess.on('error', (error) => {
            logger.error('Failed to start backtest process:', error);
            reject(error);
        });
        const input = JSON.stringify({
            strategy_code: strategyCode,
            config: config
        });
        pythonProcess.stdin.write(input);
        pythonProcess.stdin.end();
        setTimeout(() => {
            pythonProcess.kill();
            reject(new Error('Backtest timeout (5 minutes)'));
        }, 5 * 60 * 1000);
    });
}
const storage = multer_1.default.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = '/tmp/claude/strategy-uploads';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueName = `${(0, uuid_1.v4)()}-${file.originalname}`;
        cb(null, uniqueName);
    }
});
const upload = (0, multer_1.default)({
    storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'text/x-python' || file.originalname.endsWith('.py') || file.originalname === 'requirements.txt' || file.mimetype === 'text/plain') {
            cb(null, true);
        }
        else {
            cb(new Error('Only Python (.py) and requirements.txt files are allowed'));
        }
    },
    limits: {
        fileSize: 5 * 1024 * 1024,
    }
});
router.post('/validate', auth_1.authenticate, upload.single('strategyFile'), async (req, res, next) => {
    try {
        const file = req.file;
        if (!file) {
            return res.status(400).json({
                error: 'No strategy file provided'
            });
        }
        const strategyCode = fs.readFileSync(file.path, 'utf8');
        fs.unlinkSync(file.path);
        logger.info('Validating strategy structure...');
        const validationResult = await strategy_structure_validator_1.strategyStructureValidator.validate(strategyCode);
        const formattedErrors = strategy_structure_validator_1.strategyStructureValidator.formatErrors(validationResult);
        const summary = strategy_structure_validator_1.strategyStructureValidator.getSummary(validationResult);
        logger.info(`Validation complete: ${validationResult.is_valid ? 'PASSED' : 'FAILED'}`);
        res.json({
            success: true,
            validation: {
                is_valid: validationResult.is_valid,
                summary,
                errors: formattedErrors,
                warnings: validationResult.warnings,
                details: {
                    found_classes: validationResult.found_classes,
                    found_methods: validationResult.found_methods,
                    total_errors: validationResult.summary.total_errors,
                    total_warnings: validationResult.summary.total_warnings,
                    classes_expected: validationResult.summary.classes_expected,
                    classes_found: validationResult.summary.classes_found
                }
            }
        });
    }
    catch (error) {
        logger.error('Strategy validation failed:', error);
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }
        if (error instanceof Error) {
            return res.status(500).json({
                error: 'Validation failed',
                message: error.message
            });
        }
        next(error);
    }
});
router.post('/upload', auth_1.authenticate, upload.single('strategyFile'), async (req, res, next) => {
    try {
        const userId = req.userId;
        const file = req.file;
        const { name, description, config } = req.body;
        if (!file) {
            return res.status(400).json({
                error: 'No strategy file uploaded'
            });
        }
        if (!name || !config) {
            return res.status(400).json({
                error: 'Strategy name and configuration are required'
            });
        }
        let parsedConfig;
        try {
            parsedConfig = JSON.parse(config);
        }
        catch (error) {
            return res.status(400).json({
                error: 'Invalid configuration JSON'
            });
        }
        const strategyCode = fs.readFileSync(file.path, 'utf8');
        fs.unlinkSync(file.path);
        const validationResult = await validateStrategyCode(strategyCode, parsedConfig);
        if (!validationResult.isValid) {
            return res.status(400).json({
                error: 'Strategy validation failed',
                details: validationResult.errors
            });
        }
        const strategy = await database_1.default.strategy.create({
            data: {
                name,
                code: parsedConfig.code || generateStrategyCode(name),
                description: description || '',
                detailedDescription: parsedConfig.detailedDescription || '',
                author: parsedConfig.author || 'Unknown',
                version: '1.0.0',
                instrument: parsedConfig.pair || 'B-BTC_USDT',
                tags: Array.isArray(parsedConfig.tags) ? parsedConfig.tags.join(',') : (parsedConfig.tags || ''),
                validationStatus: validationResult.isValid ? 'VALID' : 'INVALID',
                validationErrors: validationResult.errors?.join(', '),
                lastValidatedAt: new Date(),
                isActive: false,
                isApproved: false,
                isMarketplace: false,
                winRate: parsedConfig.winRate,
                riskReward: parsedConfig.riskReward,
                maxDrawdown: parsedConfig.maxDrawdown,
                roi: parsedConfig.roi,
                marginRequired: parsedConfig.marginRequired,
                supportedPairs: parsedConfig.supportedPairs ? JSON.stringify(parsedConfig.supportedPairs) : null,
                timeframes: parsedConfig.timeframes ? JSON.stringify(parsedConfig.timeframes) : null,
                strategyType: parsedConfig.strategyType,
                versions: {
                    create: {
                        version: '1.0.0',
                        strategyCode,
                        configData: parsedConfig,
                        isValidated: validationResult.isValid,
                        validationErrors: validationResult.errors?.join(', ')
                    }
                }
            }
        });
        logger.info(`Strategy uploaded: ${strategy.id} by user ${userId}`);
        let backtestMetrics = null;
        try {
            logger.info(`Auto-triggering backtest for strategy ${strategy.id}`);
            const { backtestEngine } = await Promise.resolve().then(() => __importStar(require('../services/backtest-engine')));
            const executionConfig = parsedConfig.executionConfig || {};
            const symbol = executionConfig.symbol || parsedConfig.pair || parsedConfig.pairs?.[0];
            const resolution = executionConfig.resolution || parsedConfig.timeframes?.[0] || '5';
            if (!symbol) {
                logger.warn(`Cannot run auto-backtest: no symbol found in config`);
            }
            else {
                const endDate = new Date();
                const startDate = new Date();
                startDate.setDate(startDate.getDate() - 365);
                const resolutionMap = {
                    '1': '1m', '5': '5m', '15': '15m', '30': '30m',
                    '60': '1h', '120': '2h', '240': '4h', '1D': '1d'
                };
                const mappedResolution = resolutionMap[resolution] || `${resolution}m`;
                const backtestResult = await backtestEngine.runBacktest({
                    strategyId: strategy.id,
                    symbol,
                    resolution: mappedResolution,
                    startDate,
                    endDate,
                    initialCapital: 10000,
                    riskPerTrade: 0.01,
                    leverage: parsedConfig.riskProfile?.leverage || 10,
                    commission: 0.001,
                });
                await database_1.default.strategy.update({
                    where: { id: strategy.id },
                    data: {
                        winRate: backtestResult.metrics.winRate,
                        riskReward: backtestResult.metrics.profitFactor,
                        maxDrawdown: backtestResult.metrics.maxDrawdownPct,
                        roi: backtestResult.metrics.totalPnlPct,
                        isMarketplace: true,
                        isPublic: true,
                        isApproved: true,
                        isActive: true,
                    },
                });
                backtestMetrics = {
                    winRate: backtestResult.metrics.winRate,
                    profitFactor: backtestResult.metrics.profitFactor,
                    maxDrawdown: backtestResult.metrics.maxDrawdownPct,
                    roi: backtestResult.metrics.totalPnlPct,
                    totalTrades: backtestResult.metrics.totalTrades,
                };
                logger.info(`Auto-backtest completed for strategy ${strategy.id}: ` +
                    `Win Rate ${backtestMetrics.winRate.toFixed(1)}%, ` +
                    `ROI ${backtestMetrics.roi.toFixed(2)}%`);
            }
        }
        catch (backtestError) {
            logger.error('Auto-backtest failed (non-fatal):', backtestError);
        }
        res.json({
            success: true,
            strategy: {
                id: strategy.id,
                name: strategy.name,
                code: strategy.code,
                description: strategy.description,
                author: strategy.author,
                version: strategy.version,
                createdAt: strategy.createdAt,
            },
            validation: validationResult,
            backtest: backtestMetrics,
            visibility: {
                marketplace: !!(backtestMetrics),
                processing: !backtestMetrics
            }
        });
    }
    catch (error) {
        logger.error('Strategy upload failed:', error);
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }
        if (error instanceof Error) {
            return res.status(500).json({
                error: 'Strategy upload failed',
                message: error.message
            });
        }
        next(error);
    }
});
router.get('/strategies', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { page = 1, limit = 10, search, status, all } = req.query;
        const skip = (Number(page) - 1) * Number(limit);
        const whereConditions = {};
        if (search) {
            whereConditions.OR = [
                { name: { contains: search, mode: 'insensitive' } },
                { code: { contains: search, mode: 'insensitive' } },
                { description: { contains: search, mode: 'insensitive' } }
            ];
        }
        if (status) {
            whereConditions.isActive = status === 'active';
        }
        else if (!all || all === 'false') {
            whereConditions.isActive = true;
        }
        const [strategies, total] = await Promise.all([
            database_1.default.strategy.findMany({
                where: whereConditions,
                select: {
                    id: true,
                    name: true,
                    code: true,
                    description: true,
                    author: true,
                    version: true,
                    isActive: true,
                    isMarketplace: true,
                    tags: true,
                    instrument: true,
                    createdAt: true,
                    updatedAt: true,
                    winRate: true,
                    roi: true,
                    riskReward: true,
                    maxDrawdown: true,
                    sharpeRatio: true,
                    totalTrades: true,
                    profitFactor: true,
                    marginRequired: true,
                    supportedPairs: true,
                    timeframes: true,
                    botDeployments: {
                        select: {
                            id: true,
                            status: true,
                            deployedAt: true,
                        },
                        orderBy: { deployedAt: 'desc' },
                        take: 1,
                    },
                    backtestResults: {
                        select: {
                            id: true,
                            startDate: true,
                            endDate: true,
                            initialBalance: true,
                            finalBalance: true,
                            totalReturn: true,
                            totalReturnPct: true,
                            maxDrawdown: true,
                            sharpeRatio: true,
                            winRate: true,
                            profitFactor: true,
                            totalTrades: true,
                            avgTrade: true,
                            equityCurve: true,
                            tradeHistory: true,
                            createdAt: true,
                        },
                        orderBy: { createdAt: 'desc' },
                        take: 1,
                    }
                },
                orderBy: { createdAt: 'desc' },
                skip,
                take: Number(limit),
            }),
            database_1.default.strategy.count({ where: whereConditions })
        ]);
        res.json({
            strategies: strategies.map(strategy => {
                const supportedPairs = strategy.supportedPairs ? JSON.parse(strategy.supportedPairs) : null;
                const timeframes = strategy.timeframes ? JSON.parse(strategy.timeframes) : null;
                const deploymentCount = strategy.botDeployments.filter(d => ['ACTIVE', 'DEPLOYING', 'STARTING'].includes(d.status)).length;
                return {
                    ...strategy,
                    supportedPairs,
                    timeframes,
                    deploymentCount,
                    subscriberCount: 0,
                    latestDeployment: strategy.botDeployments[0] || null,
                    latestBacktest: strategy.backtestResults[0] || null,
                    features: timeframes ? {
                        timeframes: timeframes,
                        leverage: 10,
                    } : undefined,
                    botDeployments: undefined,
                    backtestResults: undefined,
                };
            }),
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                pages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        logger.error('Failed to get user strategies:', error);
        next(error);
    }
});
router.get('/:id', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const strategyId = req.params.id;
        const strategy = await database_1.default.strategy.findFirst({
            where: { id: strategyId },
            include: {
                botDeployments: {
                    orderBy: { deployedAt: 'desc' },
                    take: 5,
                },
                versions: {
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                },
                backtestResults: {
                    select: {
                        id: true,
                        startDate: true,
                        endDate: true,
                        initialBalance: true,
                        finalBalance: true,
                        totalReturn: true,
                        totalReturnPct: true,
                        maxDrawdown: true,
                        sharpeRatio: true,
                        winRate: true,
                        profitFactor: true,
                        totalTrades: true,
                        avgTrade: true,
                        equityCurve: true,
                        tradeHistory: true,
                        monthlyReturns: true,
                        createdAt: true,
                    },
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                }
            }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        const formattedStrategy = {
            ...strategy,
            latestBacktest: strategy.backtestResults?.[0] || null,
            backtestResults: undefined,
        };
        res.json({ strategy: formattedStrategy });
    }
    catch (error) {
        logger.error('Failed to get strategy details:', error);
        next(error);
    }
});
router.put('/:id', auth_1.authenticate, upload.single('strategyFile'), async (req, res, next) => {
    try {
        const userId = req.userId;
        const strategyId = req.params.id;
        const { name, description, config } = req.body;
        const file = req.file;
        const existingStrategy = await database_1.default.strategy.findFirst({
            where: { id: strategyId },
            include: {
                versions: {
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                }
            }
        });
        if (!existingStrategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        const updateData = {};
        if (name)
            updateData.name = name;
        if (description !== undefined)
            updateData.description = description;
        let parsedConfig = null;
        if (config) {
            try {
                parsedConfig = JSON.parse(config);
            }
            catch (error) {
                return res.status(400).json({
                    error: 'Invalid configuration JSON'
                });
            }
        }
        if (file) {
            const strategyCode = fs.readFileSync(file.path, 'utf8');
            fs.unlinkSync(file.path);
            const currentConfig = existingStrategy.versions[0]?.configData || {};
            const validationResult = await validateStrategyCode(strategyCode, parsedConfig || currentConfig);
            if (!validationResult.isValid) {
                return res.status(400).json({
                    error: 'Strategy validation failed',
                    details: validationResult.errors
                });
            }
            const newVersion = incrementVersion(existingStrategy.version);
            updateData.version = newVersion;
            updateData.newStrategyCode = strategyCode;
            updateData.newConfigData = parsedConfig || currentConfig;
        }
        const newStrategyCode = updateData.newStrategyCode;
        const newConfigData = updateData.newConfigData;
        delete updateData.newStrategyCode;
        delete updateData.newConfigData;
        const updatedStrategy = await database_1.default.strategy.update({
            where: { id: strategyId },
            data: updateData
        });
        if (newStrategyCode) {
            await database_1.default.strategyVersion.create({
                data: {
                    strategyId: updatedStrategy.id,
                    version: updatedStrategy.version,
                    strategyCode: newStrategyCode,
                    configData: newConfigData,
                    isValidated: true,
                }
            });
        }
        logger.info(`Strategy updated: ${strategyId} by user ${userId}`);
        res.json({
            success: true,
            strategy: {
                id: updatedStrategy.id,
                name: updatedStrategy.name,
                code: updatedStrategy.code,
                description: updatedStrategy.description,
                version: updatedStrategy.version,
                updatedAt: updatedStrategy.updatedAt,
            }
        });
    }
    catch (error) {
        logger.error('Strategy update failed:', error);
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }
        next(error);
    }
});
router.delete('/:id', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const strategyId = req.params.id;
        const activeDeployments = await database_1.default.botDeployment.findMany({
            where: {
                strategyId,
                status: {
                    in: ['ACTIVE', 'DEPLOYING', 'STARTING']
                }
            }
        });
        if (activeDeployments.length > 0) {
            return res.status(400).json({
                error: 'Cannot delete strategy with active deployments. Please stop all deployments first.'
            });
        }
        await database_1.default.strategy.delete({
            where: { id: strategyId }
        });
        logger.info(`Strategy permanently deleted: ${strategyId} by user ${userId}`);
        res.json({
            success: true,
            message: 'Strategy deleted successfully'
        });
    }
    catch (error) {
        logger.error('Strategy deletion failed:', error);
        next(error);
    }
});
router.patch('/:id/deactivate', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const strategyId = req.params.id;
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        await database_1.default.strategy.update({
            where: { id: strategyId },
            data: { isActive: false }
        });
        logger.info(`Strategy soft deleted: ${strategyId} by user ${userId}`);
        res.json({
            success: true,
            message: 'Strategy deactivated successfully (can be restored later)'
        });
    }
    catch (error) {
        logger.error('Strategy deactivation failed:', error);
        next(error);
    }
});
router.patch('/:id/activate', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const strategyId = req.params.id;
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        await database_1.default.strategy.update({
            where: { id: strategyId },
            data: { isActive: true }
        });
        logger.info(`Strategy restored: ${strategyId} by user ${userId}`);
        res.json({
            success: true,
            message: 'Strategy activated successfully'
        });
    }
    catch (error) {
        logger.error('Strategy activation failed:', error);
        next(error);
    }
});
router.post('/cli-upload', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { strategyCode, config, requirements, name, description } = req.body;
        if (!strategyCode || !config) {
            return res.status(400).json({
                error: 'Strategy code and config are required'
            });
        }
        let parsedConfig;
        try {
            parsedConfig = typeof config === 'string' ? JSON.parse(config) : config;
        }
        catch (error) {
            return res.status(400).json({
                error: 'Invalid configuration JSON'
            });
        }
        const strategyName = name || parsedConfig.name || 'Unnamed Strategy';
        const validationResult = await validateStrategyCode(strategyCode, parsedConfig);
        if (!validationResult.isValid) {
            return res.status(400).json({
                error: 'Strategy validation failed',
                details: validationResult.errors
            });
        }
        const existingStrategy = await database_1.default.strategy.findFirst({
            where: {
                code: parsedConfig.code || generateStrategyCode(strategyName)
            }
        });
        let strategy;
        if (existingStrategy) {
            const newVersion = incrementVersion(existingStrategy.version);
            const { marginRequired, marginCurrency } = calculateMarginFromConfig(parsedConfig);
            strategy = await database_1.default.strategy.update({
                where: { id: existingStrategy.id },
                data: {
                    version: newVersion,
                    description: description || parsedConfig.description || existingStrategy.description,
                    marginRequired: marginRequired,
                    marginCurrency: marginCurrency,
                    validationStatus: validationResult.isValid ? 'VALID' : 'INVALID',
                    validationErrors: validationResult.errors?.join(', '),
                    lastValidatedAt: new Date(),
                    versions: {
                        create: {
                            version: newVersion,
                            strategyCode,
                            configData: parsedConfig,
                            requirements: requirements || null,
                            isValidated: validationResult.isValid,
                            validationErrors: validationResult.errors?.join(', ')
                        }
                    }
                },
                include: {
                    versions: {
                        orderBy: { createdAt: 'desc' },
                        take: 1
                    }
                }
            });
            logger.info(`Strategy updated via CLI: ${strategy.id} (v${newVersion}) by user ${userId}`);
        }
        else {
            const { marginRequired, marginCurrency } = calculateMarginFromConfig(parsedConfig);
            strategy = await database_1.default.strategy.create({
                data: {
                    name: strategyName,
                    code: parsedConfig.code || generateStrategyCode(strategyName),
                    description: description || parsedConfig.description || '',
                    detailedDescription: parsedConfig.detailedDescription || '',
                    author: parsedConfig.author || 'Unknown',
                    version: '1.0.0',
                    instrument: parsedConfig.pair || 'B-BTC_USDT',
                    tags: Array.isArray(parsedConfig.tags) ? parsedConfig.tags.join(',') : (parsedConfig.tags || ''),
                    validationStatus: validationResult.isValid ? 'VALID' : 'INVALID',
                    validationErrors: validationResult.errors?.join(', '),
                    lastValidatedAt: new Date(),
                    isActive: false,
                    isApproved: false,
                    isMarketplace: false,
                    winRate: parsedConfig.winRate,
                    riskReward: parsedConfig.riskReward,
                    maxDrawdown: parsedConfig.maxDrawdown,
                    roi: parsedConfig.roi,
                    marginRequired: marginRequired,
                    marginCurrency: marginCurrency,
                    supportedPairs: parsedConfig.supportedPairs ? JSON.stringify(parsedConfig.supportedPairs) : null,
                    timeframes: parsedConfig.timeframes ? JSON.stringify(parsedConfig.timeframes) : null,
                    strategyType: parsedConfig.strategyType,
                    versions: {
                        create: {
                            version: '1.0.0',
                            strategyCode,
                            configData: parsedConfig,
                            requirements: requirements || null,
                            isValidated: validationResult.isValid,
                            validationErrors: validationResult.errors?.join(', ')
                        }
                    }
                },
                include: {
                    versions: {
                        orderBy: { createdAt: 'desc' },
                        take: 1
                    }
                }
            });
            logger.info(`New strategy created via CLI: ${strategy.id} by user ${userId}`);
        }
        let backtestMetrics = null;
        let backtestError = null;
        if (parsedConfig.strategyType === 'livetrader') {
            logger.info(`LiveTrader strategy detected - running backtest via LiveTrader.backtest() method`);
            try {
                const requirementsTxt = requirements || 'pandas>=2.0.0\nnumpy>=1.24.0\npandas-ta>=0.3.14b\nrequests>=2.31.0';
                const pair = parsedConfig.executionConfig?.symbol || parsedConfig.pair || parsedConfig.pairs?.[0];
                const resolution = parsedConfig.resolution || parsedConfig.timeframes?.[0] || '5';
                logger.debug(`Backtest config - pair: ${pair}, resolution: ${resolution}, parsed: ${JSON.stringify(parsedConfig)}`);
                const backtestResult = await executeLiveTraderBacktest(strategyCode, requirementsTxt, {
                    ...parsedConfig,
                    api_key: 'BACKTEST_MODE',
                    api_secret: 'BACKTEST_MODE'
                });
                if (!backtestResult.success) {
                    throw new Error(backtestResult.error || 'Backtest failed');
                }
                await database_1.default.strategy.update({
                    where: { id: strategy.id },
                    data: {
                        winRate: backtestResult.winRate,
                        riskReward: backtestResult.profitFactor,
                        maxDrawdown: backtestResult.maxDrawdown,
                        roi: backtestResult.roi,
                        isActive: true,
                        isApproved: true,
                        isMarketplace: true,
                    },
                });
                backtestMetrics = {
                    winRate: backtestResult.winRate,
                    profitFactor: backtestResult.profitFactor,
                    maxDrawdown: backtestResult.maxDrawdown,
                    roi: backtestResult.roi,
                    totalTrades: backtestResult.totalTrades,
                };
                logger.info(`LiveTrader backtest completed for strategy ${strategy.id}: ` +
                    `Win Rate ${backtestMetrics.winRate.toFixed(1)}%, ` +
                    `ROI ${backtestMetrics.roi.toFixed(2)}%`);
            }
            catch (err) {
                logger.error('LiveTrader backtest failed (non-fatal):', err);
                backtestError = err instanceof Error ? err.message : String(err);
            }
        }
        else {
            try {
                logger.info(`Auto-triggering backtest for strategy ${strategy.id}`);
                const { backtestEngine } = await Promise.resolve().then(() => __importStar(require('../services/backtest-engine')));
                const executionConfig = parsedConfig.executionConfig || {};
                const symbol = executionConfig.symbol || parsedConfig.pair || parsedConfig.pairs?.[0];
                const resolution = executionConfig.resolution || parsedConfig.timeframes?.[0] || '5';
                if (!symbol) {
                    logger.warn(`Cannot run auto-backtest: no symbol found in config`);
                }
                else {
                    const endDate = new Date();
                    const startDate = new Date();
                    startDate.setDate(startDate.getDate() - 365);
                    const resolutionMap = {
                        '1': '1m', '5': '5m', '15': '15m', '30': '30m',
                        '60': '1h', '120': '2h', '240': '4h', '1D': '1d'
                    };
                    const mappedResolution = resolutionMap[resolution] || `${resolution}m`;
                    const backtestResult = await backtestEngine.runBacktest({
                        strategyId: strategy.id,
                        symbol,
                        resolution: mappedResolution,
                        startDate,
                        endDate,
                        initialCapital: 10000,
                        riskPerTrade: 0.01,
                        leverage: parsedConfig.riskProfile?.leverage || 10,
                        commission: 0.001,
                    });
                    await database_1.default.strategy.update({
                        where: { id: strategy.id },
                        data: {
                            winRate: backtestResult.metrics.winRate,
                            riskReward: backtestResult.metrics.profitFactor,
                            maxDrawdown: backtestResult.metrics.maxDrawdownPct,
                            roi: backtestResult.metrics.totalPnlPct,
                            isActive: true,
                            isApproved: true,
                            isMarketplace: true,
                        },
                    });
                    backtestMetrics = {
                        winRate: backtestResult.metrics.winRate,
                        profitFactor: backtestResult.metrics.profitFactor,
                        maxDrawdown: backtestResult.metrics.maxDrawdownPct,
                        roi: backtestResult.metrics.totalPnlPct,
                        totalTrades: backtestResult.metrics.totalTrades,
                    };
                    logger.info(`Auto-backtest completed for strategy ${strategy.id}: ` +
                        `Win Rate ${backtestMetrics.winRate.toFixed(1)}%, ` +
                        `ROI ${backtestMetrics.roi.toFixed(2)}%`);
                }
            }
            catch (err) {
                logger.error('Auto-backtest failed (non-fatal):', err);
                backtestError = err instanceof Error ? err.message : String(err);
            }
        }
        res.json({
            success: true,
            strategy: {
                id: strategy.id,
                name: strategy.name,
                code: strategy.code,
                description: strategy.description,
                author: strategy.author,
                version: strategy.version,
                createdAt: strategy.createdAt,
                updatedAt: strategy.updatedAt,
                isNew: !existingStrategy,
            },
            validation: validationResult,
            backtest: backtestMetrics,
            backtestStatus: backtestError ? 'FAILED' : (backtestMetrics ? 'DONE' : 'PROCESSING'),
            backtestError,
            visibility: {
                marketplace: !!backtestMetrics,
                processing: !backtestMetrics && !backtestError,
                failed: !!backtestError
            }
        });
    }
    catch (error) {
        logger.error('CLI strategy upload failed:', error);
        if (error instanceof Error) {
            return res.status(500).json({
                error: 'Strategy upload failed',
                message: error.message
            });
        }
        next(error);
    }
});
router.post('/:id/backtest-results', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const strategyId = req.params.id;
        const { startDate, endDate, initialBalance, finalBalance, totalReturn, totalReturnPct, maxDrawdown, sharpeRatio, winRate, profitFactor, totalTrades, avgTrade, equityCurve, tradeHistory, timeframe, } = req.body;
        if (!startDate || !endDate || !initialBalance || !finalBalance) {
            return res.status(400).json({
                error: 'Missing required backtest parameters',
                required: ['startDate', 'endDate', 'initialBalance', 'finalBalance']
            });
        }
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        const backtestResult = await database_1.default.backtestResult.create({
            data: {
                strategyId,
                version: strategy.version,
                startDate: new Date(startDate),
                endDate: new Date(endDate),
                initialBalance,
                finalBalance,
                totalReturn: totalReturn || (finalBalance - initialBalance),
                totalReturnPct: totalReturnPct || ((finalBalance - initialBalance) / initialBalance * 100),
                maxDrawdown: maxDrawdown || 0,
                sharpeRatio: sharpeRatio || 0,
                winRate: winRate || 0,
                profitFactor: profitFactor || 0,
                totalTrades: totalTrades || 0,
                avgTrade: avgTrade || 0,
                timeframe: timeframe || '1d',
                equityCurve: equityCurve || {},
                tradeHistory: tradeHistory || [],
                monthlyReturns: {},
                backtestDuration: 0,
            }
        });
        const riskReward = avgTrade && maxDrawdown ? Math.abs(avgTrade / maxDrawdown) : 0;
        await database_1.default.strategy.update({
            where: { id: strategyId },
            data: {
                winRate,
                roi: totalReturnPct,
                maxDrawdown,
                sharpeRatio,
                profitFactor,
                totalTrades,
                riskReward,
                avgTradeReturn: avgTrade,
                updatedAt: new Date(),
            }
        });
        logger.info(`Backtest results uploaded for strategy ${strategyId} by user ${userId}`);
        res.json({
            success: true,
            message: 'Backtest results uploaded successfully',
            backtestResult: {
                id: backtestResult.id,
                winRate,
                roi: totalReturnPct,
                maxDrawdown,
                sharpeRatio,
                profitFactor,
                totalTrades,
            }
        });
    }
    catch (error) {
        logger.error('Backtest results upload failed:', error);
        next(error);
    }
});
router.post('/:id/deploy', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const strategyId = req.params.id;
        const { auto_start = true } = req.body;
        const strategy = await database_1.default.strategy.findFirst({
            where: { id: strategyId, isApproved: true },
            include: {
                versions: {
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                }
            }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found or not approved'
            });
        }
        if (!strategy.versions || strategy.versions.length === 0) {
            return res.status(400).json({
                error: 'Strategy has no uploaded code'
            });
        }
        const latestVersion = strategy.versions[0];
        const deploymentRequest = {
            user_id: userId,
            strategy_code: latestVersion.strategyCode,
            config: latestVersion.configData,
            auto_start,
            environment: 'production',
        };
        const deploymentResult = await strategy_service_1.strategyService.deployStrategy(deploymentRequest);
        if (!deploymentResult.success) {
            return res.status(400).json({
                error: deploymentResult.message,
                details: deploymentResult.error_details,
            });
        }
        const deployment = await database_1.default.botDeployment.create({
            data: {
                userId,
                strategyId: strategy.id,
                status: 'DEPLOYING',
                leverage: latestVersion.configData?.leverage || 10,
                riskPerTrade: latestVersion.configData?.risk_per_trade || 0.01,
                marginCurrency: 'USDT',
            },
        });
        res.json({
            success: true,
            deployment: {
                id: deployment.id,
                strategyInstanceId: deploymentResult.strategy_id,
                status: deploymentResult.status,
                message: deploymentResult.message,
            },
        });
    }
    catch (error) {
        logger.error('Strategy deployment failed:', error);
        next(error);
    }
});
async function validateStrategyCode(code, config) {
    try {
        const errors = [];
        const warnings = [];
        const hasAllClasses = code.includes('class CoinDCXClient') &&
            code.includes('class Trader') &&
            code.includes('class LiveTrader') &&
            code.includes('class Backtester');
        if (hasAllClasses) {
            logger.info('Detected new multi-tenant format - using structural validator');
            try {
                const structuralValidation = await strategy_structure_validator_1.strategyStructureValidator.validate(code);
                if (!structuralValidation.is_valid) {
                    const formattedErrors = strategy_structure_validator_1.strategyStructureValidator.formatErrors(structuralValidation);
                    errors.push(...formattedErrors);
                }
                if (structuralValidation.found_classes.length > 0) {
                    logger.info(`Found classes: ${structuralValidation.found_classes.join(', ')}`);
                }
            }
            catch (validationError) {
                logger.error('Structural validation failed:', validationError);
                errors.push(`Structural validation error: ${validationError}`);
            }
        }
        else {
            const isLiveTrader = config.strategyType === 'livetrader' || code.includes('class LiveTrader');
            if (isLiveTrader) {
                if (!code.includes('class LiveTrader')) {
                    errors.push('LiveTrader strategy must contain a LiveTrader class');
                }
                if (!code.includes('def check_for_new_signal')) {
                    errors.push('LiveTrader must implement check_for_new_signal method');
                }
            }
            else {
                if (!code.includes('class ') || !code.includes('BaseStrategy')) {
                    errors.push('Strategy must contain a class that inherits from BaseStrategy');
                }
                if (!code.includes('def generate_signals')) {
                    errors.push('Strategy must implement generate_signals method');
                }
                const dangerousPatterns = [
                    'import os',
                    'import subprocess',
                    'import sys',
                    'eval(',
                    'exec(',
                    '__import__',
                    'open(',
                    'file(',
                ];
                for (const pattern of dangerousPatterns) {
                    if (code.includes(pattern)) {
                        warnings.push(`Potentially dangerous pattern detected: ${pattern}`);
                    }
                }
            }
        }
        const requiredConfigFields = ['name', 'code', 'author'];
        for (const field of requiredConfigFields) {
            if (!config[field]) {
                errors.push(`Missing required configuration field: ${field}`);
            }
        }
        return {
            isValid: errors.length === 0,
            errors,
            warnings,
            estimatedMemory: Math.max(50, code.length / 1000),
            estimatedCpu: 5.0,
        };
    }
    catch (error) {
        return {
            isValid: false,
            errors: [`Validation error: ${error}`],
            warnings: [],
        };
    }
}
function generateStrategyCode(name) {
    return name.toUpperCase().replace(/[^A-Z0-9]/g, '_') + '_V1';
}
function incrementVersion(currentVersion) {
    const parts = currentVersion.split('.');
    const patch = parseInt(parts[2] || '0') + 1;
    return `${parts[0]}.${parts[1]}.${patch}`;
}
function extractStrategyConfig(strategyCode) {
    try {
        const configRegex = /STRATEGY_CONFIG\s*=\s*\{([^}]+)\}/s;
        const match = strategyCode.match(configRegex);
        if (!match) {
            return {
                success: false,
                config: {},
                extractedParams: [],
                error: 'STRATEGY_CONFIG not found in Python file'
            };
        }
        const configBlock = match[1];
        const extractedConfig = {};
        const extractedParams = [];
        const lineRegex = /["']([^"']+)["']\s*:\s*([^,\n]+)/g;
        let lineMatch;
        while ((lineMatch = lineRegex.exec(configBlock)) !== null) {
            const key = lineMatch[1];
            let value = lineMatch[2].trim();
            if (value === 'True') {
                extractedConfig[key] = true;
            }
            else if (value === 'False') {
                extractedConfig[key] = false;
            }
            else if (value === 'None') {
                extractedConfig[key] = null;
            }
            else if (!isNaN(Number(value))) {
                extractedConfig[key] = Number(value);
            }
            else if (value.startsWith('"') || value.startsWith("'")) {
                extractedConfig[key] = value.slice(1, -1);
            }
            else {
                extractedConfig[key] = value;
            }
            extractedParams.push(key);
        }
        logger.info(`✅ Extracted ${extractedParams.length} parameters from STRATEGY_CONFIG`);
        return {
            success: true,
            config: extractedConfig,
            extractedParams,
        };
    }
    catch (error) {
        logger.error('Failed to extract STRATEGY_CONFIG:', error);
        return {
            success: false,
            config: {},
            extractedParams: [],
            error: error instanceof Error ? error.message : String(error)
        };
    }
}
router.post('/upload-simple', auth_1.authenticate, upload.fields([
    { name: 'strategyFile', maxCount: 1 },
    { name: 'requirementsFile', maxCount: 1 }
]), async (req, res, next) => {
    try {
        const userId = req.userId;
        const files = req.files;
        const configJson = req.body.config;
        if (!files || !files.strategyFile || files.strategyFile.length === 0) {
            return res.status(400).json({
                error: 'No strategy file uploaded'
            });
        }
        if (!configJson) {
            return res.status(400).json({
                error: 'Config JSON is required'
            });
        }
        let config;
        try {
            config = typeof configJson === 'string' ? JSON.parse(configJson) : configJson;
        }
        catch (error) {
            return res.status(400).json({
                error: 'Invalid config JSON'
            });
        }
        const strategyFile = files.strategyFile[0];
        const strategyCode = fs.readFileSync(strategyFile.path, 'utf8');
        fs.unlinkSync(strategyFile.path);
        let requirementsTxt = 'pandas>=2.0.0\nnumpy>=1.24.0\npandas-ta>=0.3.14b\nrequests>=2.31.0';
        if (files.requirementsFile && files.requirementsFile.length > 0) {
            const reqFile = files.requirementsFile[0];
            requirementsTxt = fs.readFileSync(reqFile.path, 'utf8');
            fs.unlinkSync(reqFile.path);
            logger.info(`Using custom requirements.txt with ${requirementsTxt.split('\n').length} packages`);
        }
        else {
            logger.info('No requirements.txt provided, using defaults');
        }
        logger.info(`Simple upload: ${strategyFile.originalname} by user ${userId}`);
        const hasLiveTrader = strategyCode.includes('class LiveTrader');
        const hasBacktester = strategyCode.includes('class Backtester');
        const hasTrader = strategyCode.includes('class Trader');
        const saveStrategyToFile = (strategyId, strategyName, code) => {
            try {
                const strategiesDir = path.join(__dirname, '../../strategies');
                const strategyDir = path.join(strategiesDir, strategyId);
                if (!fs.existsSync(strategiesDir)) {
                    fs.mkdirSync(strategiesDir, { recursive: true });
                }
                if (!fs.existsSync(strategyDir)) {
                    fs.mkdirSync(strategyDir, { recursive: true });
                }
                const filename = `${strategyName.replace(/[^a-zA-Z0-9]/g, '_')}.py`;
                const filepath = path.join(strategyDir, filename);
                fs.writeFileSync(filepath, code, 'utf8');
                const logsDir = path.join(strategyDir, 'logs');
                if (!fs.existsSync(logsDir)) {
                    fs.mkdirSync(logsDir, { recursive: true });
                }
                logger.info(`Strategy saved to: ${filepath}`);
                return filepath;
            }
            catch (error) {
                logger.error('Failed to save strategy file:', error);
                return null;
            }
        };
        if (!hasLiveTrader) {
            return res.status(400).json({
                error: 'Strategy must contain LiveTrader class',
                hint: 'Expected: class LiveTrader with check_for_new_signal method'
            });
        }
        if (!hasTrader) {
            return res.status(400).json({
                error: 'Strategy must contain Trader class with generate_signals method',
                hint: 'Expected: class Trader with def generate_signals(self, df, params)'
            });
        }
        if (strategyCode.includes("open('config.json'") || strategyCode.includes('open("config.json"')) {
            return res.status(400).json({
                error: 'Strategy reads from config.json - not compatible with multi-tenant execution',
                hint: 'Use settings parameter instead: self.api_key = settings["api_key"]',
                details: 'Multiple subscribers need their own API keys. Config file won\'t work.'
            });
        }
        const apiKeyMatch = strategyCode.match(/api_key\s*=\s*['"][^'"]+['"]/i);
        const apiSecretMatch = strategyCode.match(/api_secret\s*=\s*['"][^'"]+['"]/i);
        if (apiKeyMatch || apiSecretMatch) {
            return res.status(400).json({
                error: 'Strategy contains hardcoded API keys - not compatible with multi-tenant execution',
                hint: 'Accept keys from settings parameter: self.api_key = settings["api_key"]',
                details: 'Each subscriber must use their own API keys.'
            });
        }
        logger.info('Extracting STRATEGY_CONFIG from Python file...');
        const configExtraction = extractStrategyConfig(strategyCode);
        const mergedConfig = {
            ...configExtraction.config,
            ...config,
        };
        logger.info(`Config merge: extracted=${configExtraction.extractedParams.length} params, user=${Object.keys(config).length}, merged=${Object.keys(mergedConfig).length}`);
        const strategyName = mergedConfig.name || config.name || strategyFile.originalname.replace('.py', '');
        const strategyCode_db = mergedConfig.code || config.code || generateStrategyCode(strategyName);
        const existingStrategy = await database_1.default.strategy.findFirst({
            where: { code: strategyCode_db }
        });
        let strategy;
        if (existingStrategy) {
            const newVersion = incrementVersion(existingStrategy.version);
            strategy = await database_1.default.strategy.update({
                where: { id: existingStrategy.id },
                data: {
                    version: newVersion,
                    updatedAt: new Date(),
                    versions: {
                        create: {
                            version: newVersion,
                            strategyCode,
                            configData: config,
                            requirements: config.requirements || null,
                            isValidated: true
                        }
                    }
                },
                include: {
                    versions: {
                        orderBy: { createdAt: 'desc' },
                        take: 1
                    }
                }
            });
            logger.info(`Strategy updated: ${strategy.id} (v${newVersion})`);
            saveStrategyToFile(strategy.id, strategyName, strategyCode);
        }
        else {
            strategy = await database_1.default.strategy.create({
                data: {
                    name: strategyName,
                    code: strategyCode_db,
                    description: config.description || '',
                    detailedDescription: config.detailedDescription || '',
                    author: config.author || 'Unknown',
                    version: '1.0.0',
                    instrument: config.pair || 'B-BTC_USDT',
                    tags: Array.isArray(config.tags) ? config.tags.join(',') : '',
                    strategyType: 'multi_tenant',
                    isActive: false,
                    isApproved: false,
                    isMarketplace: false,
                    supportedPairs: config.supportedPairs ? JSON.stringify(config.supportedPairs) : null,
                    timeframes: config.timeframes ? JSON.stringify(config.timeframes) : null,
                    versions: {
                        create: {
                            version: '1.0.0',
                            strategyCode,
                            configData: config,
                            requirements: config.requirements || null,
                            isValidated: true
                        }
                    }
                },
                include: {
                    versions: {
                        orderBy: { createdAt: 'desc' },
                        take: 1
                    }
                }
            });
            logger.info(`New strategy created: ${strategy.id}`);
            saveStrategyToFile(strategy.id, strategyName, strategyCode);
        }
        logger.info(`Creating isolated Python environment for strategy ${strategy.id}...`);
        try {
            await strategy_environment_manager_1.strategyEnvironmentManager.createEnvironment(strategy.id);
            logger.info(`Environment created successfully for strategy ${strategy.id}`);
        }
        catch (envError) {
            logger.error(`Failed to create environment for strategy ${strategy.id}:`, envError);
            return res.status(500).json({
                success: false,
                error: 'Failed to create Python environment',
                message: envError instanceof Error ? envError.message : String(envError)
            });
        }
        if (hasBacktester) {
            logger.info('Backtester class detected - starting async backtest...');
            const resolution = await strategy_executor_1.strategyExecutor.getStrategyResolution(strategy.id) || config.resolution || '5m';
            const endDate = new Date();
            const startDate = new Date();
            startDate.setFullYear(startDate.getFullYear() - 1);
            const backtestSettings = {
                ...mergedConfig,
                strategy_id: strategy.id,
                pair: config.pair || 'B-BTC_USDT',
                capital: config.capital || 10000,
                leverage: config.leverage || 10,
                risk_per_trade: config.risk_per_trade || 0.01,
                resolution,
                commission_rate: 0.0005,
                gst_rate: 0.18,
                sl_rate: config.sl_rate || 0.02,
                tp_rate: config.tp_rate || 0.04,
                start_date: startDate.toISOString().split('T')[0],
                end_date: endDate.toISOString().split('T')[0],
            };
            logger.info(`Backtest settings keys (${Object.keys(backtestSettings).length}): ${Object.keys(backtestSettings).join(', ')}`);
            strategy_executor_1.strategyExecutor.executeBacktestAsync(strategy.id, backtestSettings)
                .catch(err => {
                logger.error(`Async backtest failed for ${strategy.id}:`, err);
            });
            logger.info(`Async backtest started for strategy ${strategy.id}`);
        }
        res.json({
            success: true,
            strategy: {
                id: strategy.id,
                name: strategy.name,
                code: strategy.code,
                version: strategy.version,
                isNew: !existingStrategy
            },
            detected: {
                liveTrader: hasLiveTrader,
                backtester: hasBacktester,
                trader: hasTrader
            },
            configExtraction: {
                success: configExtraction.success,
                extractedParams: configExtraction.extractedParams,
                paramCount: configExtraction.extractedParams.length,
                message: configExtraction.success
                    ? `Successfully extracted ${configExtraction.extractedParams.length} parameters from STRATEGY_CONFIG`
                    : configExtraction.error || 'Failed to extract config',
                warning: !configExtraction.success
                    ? 'Strategy will use hardcoded defaults. Consider adding STRATEGY_CONFIG = {...} to your Python file.'
                    : undefined
            },
            backtest: {
                status: hasBacktester ? 'running' : 'not_applicable',
                message: hasBacktester
                    ? 'Backtest running in background. Monitor progress at /api/strategies/' + strategy.id + '/backtest/progress'
                    : 'No Backtester class found'
            },
            message: 'Strategy uploaded successfully. Backtest running in background.'
        });
    }
    catch (error) {
        logger.error('Simple upload failed:', error);
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }
        next(error);
    }
});
router.get('/:id/logs', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const strategyId = req.params.id;
        const { limit = 50 } = req.query;
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        const strategiesDir = path.join(__dirname, '../../strategies');
        const strategyDir = path.join(strategiesDir, strategyId);
        const logsDir = path.join(strategyDir, 'logs');
        if (!fs.existsSync(logsDir)) {
            return res.json({
                success: true,
                logs: [],
                message: 'No logs found for this strategy (not yet executed)'
            });
        }
        const logFiles = fs.readdirSync(logsDir)
            .filter(file => file.startsWith('trading_') && file.endsWith('.log'))
            .map(file => ({
            name: file,
            path: path.join(logsDir, file),
            mtime: fs.statSync(path.join(logsDir, file)).mtime
        }))
            .sort((a, b) => b.mtime.getTime() - a.mtime.getTime());
        if (logFiles.length === 0) {
            return res.json({
                success: true,
                logs: [],
                message: 'No log files found'
            });
        }
        const latestLogFile = logFiles[0];
        const logContent = fs.readFileSync(latestLogFile.path, 'utf8');
        const logLines = logContent.split('\n')
            .filter(line => line.trim().length > 0)
            .slice(-Number(limit));
        const parsedLogs = logLines.map(line => {
            const match = line.match(/^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) - (\w+) - (.+)$/);
            if (match) {
                return {
                    timestamp: match[1],
                    level: match[2],
                    message: match[3]
                };
            }
            return { timestamp: '', level: 'INFO', message: line };
        });
        const errorCsvPath = path.join(logsDir, 'error_log.csv');
        let errors = [];
        if (fs.existsSync(errorCsvPath)) {
            const errorContent = fs.readFileSync(errorCsvPath, 'utf8');
            const errorLines = errorContent.split('\n')
                .slice(1)
                .filter(line => line.trim().length > 0)
                .slice(-Number(limit));
            errors = errorLines.map(line => {
                const parts = line.split(',');
                return {
                    timestamp: parts[0] || '',
                    level: parts[1] || 'ERROR',
                    message: parts[2] || '',
                    function: parts[3] || '',
                    line: parts[4] || ''
                };
            });
        }
        res.json({
            success: true,
            logs: parsedLogs,
            errors,
            metadata: {
                totalLogFiles: logFiles.length,
                latestLogFile: latestLogFile.name,
                latestLogTime: latestLogFile.mtime,
                logFilesAvailable: logFiles.map(f => ({
                    name: f.name,
                    timestamp: f.mtime,
                    size: fs.statSync(f.path).size
                }))
            }
        });
    }
    catch (error) {
        logger.error('Failed to retrieve strategy logs:', error);
        next(error);
    }
});
//# sourceMappingURL=strategy-upload.js.map