"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.brokerRoutes = void 0;
const express_1 = require("express");
const crypto_1 = __importDefault(require("crypto"));
const auth_1 = require("../middleware/auth");
const simple_crypto_1 = require("../utils/simple-crypto");
const database_1 = __importDefault(require("../utils/database"));
const CoinDCXClient = __importStar(require("../services/coindcx-client"));
const router = (0, express_1.Router)();
exports.brokerRoutes = router;
router.post('/keys', auth_1.authenticate, async (req, res, next) => {
    try {
        const { apiKey, apiSecret } = req.body;
        const userId = req.userId;
        if (!apiKey || !apiSecret) {
            return res.status(400).json({
                error: 'API Key and API Secret are required'
            });
        }
        if (typeof apiKey !== 'string' || typeof apiSecret !== 'string') {
            return res.status(400).json({
                error: 'API Key and Secret must be strings'
            });
        }
        const encryptedApiKey = (0, simple_crypto_1.encrypt)(apiKey);
        const encryptedApiSecret = (0, simple_crypto_1.encrypt)(apiSecret);
        const brokerCredential = await database_1.default.brokerCredential.upsert({
            where: {
                userId_brokerName: {
                    userId,
                    brokerName: 'coindcx'
                }
            },
            update: {
                apiKey: encryptedApiKey,
                apiSecret: encryptedApiSecret,
                isActive: true,
                updatedAt: new Date()
            },
            create: {
                userId,
                brokerName: 'coindcx',
                apiKey: encryptedApiKey,
                apiSecret: encryptedApiSecret,
                isActive: true
            }
        });
        res.json({
            message: 'CoinDCX credentials stored successfully',
            credential: {
                id: brokerCredential.id,
                brokerName: brokerCredential.brokerName,
                isActive: brokerCredential.isActive,
                createdAt: brokerCredential.createdAt,
                updatedAt: brokerCredential.updatedAt
            }
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/credentials', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const credentials = await database_1.default.brokerCredential.findMany({
            where: {
                userId,
            },
            select: {
                id: true,
                brokerName: true,
                isActive: true,
                createdAt: true,
                updatedAt: true,
            },
            orderBy: {
                createdAt: 'desc',
            },
        });
        res.json({
            credentials,
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/balance', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const brokerCredential = await database_1.default.brokerCredential.findUnique({
            where: {
                userId_brokerName: {
                    userId,
                    brokerName: 'coindcx'
                }
            }
        });
        if (!brokerCredential || !brokerCredential.isActive) {
            return res.status(404).json({
                error: 'No active broker credentials found. Please connect your broker first.'
            });
        }
        const apiKey = (0, simple_crypto_1.decrypt)(brokerCredential.apiKey);
        const apiSecret = (0, simple_crypto_1.decrypt)(brokerCredential.apiSecret);
        const balances = await CoinDCXClient.getBalances(apiKey, apiSecret);
        const inrBalance = balances.find(b => b.currency.toLowerCase() === 'inr');
        const totalAvailable = inrBalance ? inrBalance.balance : 0;
        res.json({
            totalAvailable,
            balances: balances.filter(b => b.balance > 0).slice(0, 10),
            currency: 'INR',
        });
    }
    catch (error) {
        console.error('Failed to fetch balance:', error);
        next(error);
    }
});
router.get('/futures-balance', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const brokerCredential = await database_1.default.brokerCredential.findUnique({
            where: {
                userId_brokerName: {
                    userId,
                    brokerName: 'coindcx'
                }
            }
        });
        if (!brokerCredential || !brokerCredential.isActive) {
            return res.status(404).json({
                error: 'No active broker credentials found. Please connect your broker first.'
            });
        }
        try {
            const wallets = await CoinDCXClient.getFuturesWallets(brokerCredential.apiKey, brokerCredential.apiSecret);
            const calculateAvailable = (wallet) => {
                const balance = Number(wallet.balance || 0);
                const locked = Number(wallet.locked_balance || 0);
                const crossOrder = Number(wallet.cross_order_margin || 0);
                const crossUser = Number(wallet.cross_user_margin || 0);
                return balance - (locked + crossOrder + crossUser);
            };
            const usdtWallet = wallets.find((w) => w.currency_short_name === 'USDT');
            const inrWallet = wallets.find((w) => w.currency_short_name === 'INR');
            const primaryWallet = usdtWallet || inrWallet;
            const currency = primaryWallet?.currency_short_name || 'USDT';
            const totalAvailable = primaryWallet ? calculateAvailable(primaryWallet) : 0;
            res.json({
                totalAvailable,
                usdtAvailable: usdtWallet ? calculateAvailable(usdtWallet) : 0,
                inrAvailable: inrWallet ? calculateAvailable(inrWallet) : 0,
                wallets: wallets.map((w) => ({
                    currency: w.currency_short_name,
                    available: calculateAvailable(w),
                    locked: Number(w.locked_balance || 0),
                    total: Number(w.balance || 0)
                })),
                currency,
            });
        }
        catch (walletError) {
            console.warn('CoinDCX futures wallet API error:', walletError.message);
            res.json({
                totalAvailable: 0,
                usdtAvailable: 0,
                wallets: [],
                currency: 'USDT',
                warning: 'Unable to fetch futures wallet. Please ensure your API key has futures trading permissions enabled on CoinDCX.'
            });
        }
    }
    catch (error) {
        console.error('Failed to fetch futures balance:', error);
        next(error);
    }
});
router.get('/status', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const brokerCredential = await database_1.default.brokerCredential.findUnique({
            where: {
                userId_brokerName: {
                    userId,
                    brokerName: 'coindcx'
                }
            },
            select: {
                id: true,
                brokerName: true,
                isActive: true,
                createdAt: true,
                updatedAt: true
            }
        });
        if (!brokerCredential) {
            return res.json({
                connected: false,
                message: 'No CoinDCX credentials found'
            });
        }
        res.json({
            connected: brokerCredential.isActive,
            brokerName: brokerCredential.brokerName,
            connectedAt: brokerCredential.createdAt,
            lastUpdated: brokerCredential.updatedAt
        });
    }
    catch (error) {
        next(error);
    }
});
router.delete('/keys', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const activeDeployments = await database_1.default.botDeployment.findMany({
            where: {
                userId,
                status: {
                    in: ['ACTIVE', 'STARTING', 'DEPLOYING']
                }
            }
        });
        if (activeDeployments.length > 0) {
            return res.status(400).json({
                error: 'Cannot delete credentials while you have active bot deployments. Please stop all bots first.'
            });
        }
        await database_1.default.brokerCredential.delete({
            where: {
                userId_brokerName: {
                    userId,
                    brokerName: 'coindcx'
                }
            }
        });
        res.json({
            message: 'CoinDCX credentials deleted successfully'
        });
    }
    catch (error) {
        if (error.code === 'P2025') {
            return res.status(404).json({
                error: 'No CoinDCX credentials found to delete'
            });
        }
        next(error);
    }
});
router.post('/test', auth_1.authenticate, async (req, res, next) => {
    try {
        const { apiKey, apiSecret } = req.body;
        if (!apiKey || !apiSecret) {
            return res.status(400).json({
                error: 'API Key and API Secret are required for testing'
            });
        }
        if (typeof apiKey !== 'string' || typeof apiSecret !== 'string') {
            return res.status(400).json({
                error: 'API Key and Secret must be strings'
            });
        }
        try {
            const timestamp = Math.floor(Date.now());
            const payload = { timestamp };
            const body = JSON.stringify(payload).replace(/\s/g, '');
            const signature = crypto_1.default
                .createHmac('sha256', apiSecret)
                .update(body)
                .digest('hex');
            console.log('🔍 CoinDCX API Test Debug Info:');
            console.log('📅 Timestamp:', timestamp);
            console.log('📦 Payload:', payload);
            console.log('📄 JSON Body:', body);
            console.log('🔑 API Key (first 8 chars):', apiKey.substring(0, 8) + '...');
            console.log('🔐 Generated Signature:', signature);
            console.log('🌐 Request URL:', 'https://api.coindcx.com/exchange/v1/users/balances');
            const response = await fetch('https://api.coindcx.com/exchange/v1/users/balances', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-AUTH-APIKEY': apiKey,
                    'X-AUTH-SIGNATURE': signature,
                },
                body,
            });
            console.log('📡 CoinDCX Response Status:', response.status);
            console.log('📋 Response Headers:', Object.fromEntries(response.headers));
            if (!response.ok) {
                let errorMessage = 'Invalid API credentials';
                let responseBody = '';
                try {
                    responseBody = await response.text();
                    console.log('❌ CoinDCX Error Response Body:', responseBody);
                    const errorData = JSON.parse(responseBody);
                    errorMessage = errorData.message || errorData.error || errorMessage;
                }
                catch (parseError) {
                    console.log('⚠️ Could not parse error response as JSON:', parseError);
                    errorMessage = responseBody || errorMessage;
                }
                if (response.status === 401) {
                    errorMessage = 'Authentication failed. Please check your API key and secret. CoinDCX says: ' + errorMessage;
                }
                else if (response.status === 403) {
                    errorMessage = 'API access forbidden. Please ensure your API key has the required permissions. CoinDCX says: ' + errorMessage;
                }
                else if (response.status === 429) {
                    errorMessage = 'Rate limit exceeded. Please try again later. CoinDCX says: ' + errorMessage;
                }
                console.log('💥 Final error message:', errorMessage);
                return res.status(400).json({
                    error: errorMessage,
                    statusCode: response.status,
                    details: {
                        timestamp,
                        endpoint: '/exchange/v1/users/balances',
                        bodyLength: body.length
                    }
                });
            }
            const accountData = await response.json();
            res.json({
                success: true,
                message: 'CoinDCX API connection test successful',
                accountInfo: {
                    hasAccess: true,
                    timestamp: new Date().toISOString()
                }
            });
        }
        catch (apiError) {
            console.error('💥 CoinDCX API test error:', apiError);
            console.error('🔧 Error details:', {
                name: apiError instanceof Error ? apiError.name : 'Unknown',
                message: apiError instanceof Error ? apiError.message : String(apiError),
                stack: apiError instanceof Error ? apiError.stack : undefined
            });
            if (apiError instanceof Error) {
                if (apiError.message.includes('ENOTFOUND') || apiError.message.includes('ECONNREFUSED')) {
                    console.error('🌐 Network connectivity issue detected');
                    return res.status(500).json({
                        error: 'Unable to connect to CoinDCX API. Please check your internet connection.',
                        details: { errorType: 'NETWORK_ERROR', originalMessage: apiError.message }
                    });
                }
                console.error('🚫 API connection failed with error:', apiError.message);
                return res.status(400).json({
                    error: 'API connection test failed: ' + apiError.message,
                    details: { errorType: 'API_ERROR', originalMessage: apiError.message }
                });
            }
            console.error('❓ Unknown error type:', typeof apiError);
            return res.status(500).json({
                error: 'Unknown error occurred while testing API connection',
                details: { errorType: 'UNKNOWN_ERROR', originalMessage: String(apiError) }
            });
        }
    }
    catch (error) {
        console.error('Broker test error:', error);
        next(error);
    }
});
//# sourceMappingURL=broker.js.map