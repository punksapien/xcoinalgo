"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.backtestProgressRoutes = void 0;
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const backtest_progress_tracker_1 = require("../services/backtest-progress-tracker");
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('BacktestProgress');
const router = (0, express_1.Router)();
exports.backtestProgressRoutes = router;
router.get('/:strategyId/progress', async (req, res) => {
    const strategyId = req.params.strategyId;
    const token = req.query.token || req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
        res.status(401).json({ error: 'Authentication required' });
        return;
    }
    logger.info(`SSE client connected for strategy ${strategyId}`);
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.write(`data: ${JSON.stringify({ type: 'connected', strategyId })}\n\n`);
    const currentProgress = backtest_progress_tracker_1.backtestProgressTracker.getProgress(strategyId);
    if (currentProgress) {
        res.write(`data: ${JSON.stringify({ type: 'progress', ...currentProgress })}\n\n`);
    }
    const unsubscribe = backtest_progress_tracker_1.backtestProgressTracker.subscribeToStrategy(strategyId, (progress) => {
        const eventData = JSON.stringify({ type: 'progress', ...progress });
        res.write(`data: ${eventData}\n\n`);
        if (progress.stage === 'complete' || progress.stage === 'error') {
            logger.info(`Backtest ${progress.stage} for strategy ${strategyId}, closing SSE connection`);
            setTimeout(() => {
                res.end();
            }, 1000);
        }
    });
    req.on('close', () => {
        logger.info(`SSE client disconnected for strategy ${strategyId}`);
        unsubscribe();
    });
    const heartbeatInterval = setInterval(() => {
        res.write(`:heartbeat\n\n`);
    }, 15000);
    res.on('close', () => {
        clearInterval(heartbeatInterval);
        unsubscribe();
    });
});
router.get('/:strategyId/status', auth_1.authenticate, async (req, res) => {
    const strategyId = req.params.strategyId;
    const progress = backtest_progress_tracker_1.backtestProgressTracker.getProgress(strategyId);
    if (!progress) {
        return res.json({
            success: true,
            status: 'not_found',
            message: 'No active backtest found for this strategy'
        });
    }
    res.json({
        success: true,
        status: 'active',
        progress: {
            stage: progress.stage,
            progress: progress.progress,
            message: progress.message,
            totalCandles: progress.totalCandles,
            fetchDuration: progress.fetchDuration,
            backtestDuration: progress.backtestDuration,
            totalDuration: progress.totalDuration,
            error: progress.error,
            metrics: progress.metrics,
            totalTrades: progress.totalTrades
        }
    });
});
//# sourceMappingURL=backtest-progress.js.map