"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.marketplaceRoutes = void 0;
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = __importDefault(require("../utils/database"));
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('Marketplace');
const router = (0, express_1.Router)();
exports.marketplaceRoutes = router;
router.get('/', async (req, res, next) => {
    try {
        const { search, tags, sortBy = 'popularity', minWinRate, page = 1, limit = 12 } = req.query;
        const skip = (Number(page) - 1) * Number(limit);
        const whereConditions = {
            isActive: true,
            isApproved: true,
        };
        if (search) {
            whereConditions.OR = [
                { name: { contains: search, mode: 'insensitive' } },
                { description: { contains: search, mode: 'insensitive' } },
                { author: { contains: search, mode: 'insensitive' } }
            ];
        }
        if (tags) {
            const tagArray = tags.split(',');
            whereConditions.tags = {
                contains: tagArray[0],
            };
        }
        if (minWinRate) {
            whereConditions.winRate = {
                gte: Number(minWinRate)
            };
        }
        let orderBy = { createdAt: 'desc' };
        if (sortBy === 'popularity') {
            orderBy = { subscriberCount: 'desc' };
        }
        else if (sortBy === 'performance') {
            orderBy = { roi: 'desc' };
        }
        const [strategies, total] = await Promise.all([
            database_1.default.strategy.findMany({
                where: whereConditions,
                select: {
                    id: true,
                    name: true,
                    code: true,
                    description: true,
                    detailedDescription: true,
                    author: true,
                    version: true,
                    tags: true,
                    createdAt: true,
                    updatedAt: true,
                    winRate: true,
                    roi: true,
                    riskReward: true,
                    maxDrawdown: true,
                    marginRequired: true,
                    instrument: true,
                    supportedPairs: true,
                    timeframes: true,
                    strategyType: true,
                    subscriberCount: true,
                },
                orderBy,
                skip,
                take: Number(limit),
            }),
            database_1.default.strategy.count({ where: whereConditions })
        ]);
        res.json({
            strategies: strategies.map(strategy => ({
                ...strategy,
                supportedPairs: strategy.supportedPairs ? JSON.parse(strategy.supportedPairs) : null,
                timeframes: strategy.timeframes ? JSON.parse(strategy.timeframes) : null,
            })),
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                pages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        logger.error('Failed to fetch marketplace strategies:', error);
        next(error);
    }
});
router.get('/:id', async (req, res, next) => {
    try {
        const { id } = req.params;
        const strategy = await database_1.default.strategy.findFirst({
            where: {
                id,
                isActive: true,
                isApproved: true,
            },
            select: {
                id: true,
                name: true,
                code: true,
                description: true,
                detailedDescription: true,
                author: true,
                version: true,
                tags: true,
                createdAt: true,
                updatedAt: true,
                isActive: true,
                isPublic: true,
                isMarketplace: true,
                executionConfig: true,
                winRate: true,
                roi: true,
                riskReward: true,
                maxDrawdown: true,
                marginRequired: true,
                sharpeRatio: true,
                totalTrades: true,
                profitFactor: true,
                avgTradeReturn: true,
                instrument: true,
                supportedPairs: true,
                timeframes: true,
                strategyType: true,
                subscriberCount: true,
                versions: {
                    select: {
                        version: true,
                        createdAt: true,
                        configData: true,
                    },
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                },
                backtestResults: {
                    select: {
                        id: true,
                        startDate: true,
                        endDate: true,
                        initialBalance: true,
                        finalBalance: true,
                        totalReturn: true,
                        totalReturnPct: true,
                        maxDrawdown: true,
                        maxDrawdownDuration: true,
                        sharpeRatio: true,
                        winRate: true,
                        profitFactor: true,
                        totalTrades: true,
                        avgTrade: true,
                        equityCurve: true,
                        tradeHistory: true,
                        monthlyReturns: true,
                        createdAt: true,
                    },
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                }
            }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found or not available in marketplace'
            });
        }
        res.json({
            strategy: {
                ...strategy,
                supportedPairs: strategy.supportedPairs ? JSON.parse(strategy.supportedPairs) : null,
                timeframes: strategy.timeframes ? JSON.parse(strategy.timeframes) : null,
                latestVersion: strategy.versions[0] || null,
                latestBacktest: strategy.backtestResults[0] || null,
                versions: undefined,
                backtestResults: undefined,
            }
        });
    }
    catch (error) {
        logger.error('Failed to fetch strategy details:', error);
        next(error);
    }
});
router.post('/:id/publish', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id } = req.params;
        const userId = req.userId;
        const strategy = await database_1.default.strategy.findUnique({
            where: { id },
            include: {
                versions: {
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                }
            }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        if (!strategy.versions || strategy.versions.length === 0) {
            return res.status(400).json({
                error: 'Cannot publish strategy without code. Please upload your strategy first.'
            });
        }
        if (!strategy.isApproved) {
            return res.status(400).json({
                error: 'Strategy must be approved before publishing to marketplace'
            });
        }
        const updatedStrategy = await database_1.default.strategy.update({
            where: { id },
            data: {
                isActive: true,
            },
            select: {
                id: true,
                name: true,
                code: true,
                isActive: true,
                subscriberCount: true,
            }
        });
        logger.info(`Strategy published to marketplace: ${id} by user ${userId}`);
        res.json({
            success: true,
            message: 'Strategy published to marketplace successfully',
            strategy: {
                id: updatedStrategy.id,
                name: updatedStrategy.name,
                code: updatedStrategy.code,
                isActive: updatedStrategy.isActive,
                marketplaceUrl: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/marketplace/${updatedStrategy.id}`,
            }
        });
    }
    catch (error) {
        logger.error('Failed to publish strategy:', error);
        next(error);
    }
});
router.post('/:id/unpublish', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id } = req.params;
        const userId = req.userId;
        const strategy = await database_1.default.strategy.findUnique({
            where: { id }
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found'
            });
        }
        await database_1.default.strategy.update({
            where: { id },
            data: {
                isActive: false,
            }
        });
        logger.info(`Strategy unpublished from marketplace: ${id} by user ${userId}`);
        res.json({
            success: true,
            message: 'Strategy removed from marketplace'
        });
    }
    catch (error) {
        logger.error('Failed to unpublish strategy:', error);
        next(error);
    }
});
//# sourceMappingURL=marketplace.js.map