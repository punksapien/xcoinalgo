"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logsRoutes = void 0;
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = __importDefault(require("../utils/database"));
const router = (0, express_1.Router)();
exports.logsRoutes = router;
router.get('/strategy/:id', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id } = req.params;
        const { since, limit = 200 } = req.query;
        const sinceDate = since ? new Date(String(since)) : new Date(Date.now() - 24 * 3600 * 1000);
        const take = Math.min(Number(limit) || 200, 2000);
        const rows = await database_1.default.strategyExecution.findMany({
            where: { strategyId: id, executedAt: { gte: sinceDate } },
            orderBy: { executedAt: 'desc' },
            take,
            select: {
                executedAt: true,
                status: true,
                signalType: true,
                subscribersCount: true,
                tradesGenerated: true,
                duration: true,
                workerId: true,
                error: true,
            }
        });
        res.json({ logs: rows });
    }
    catch (e) {
        next(e);
    }
});
//# sourceMappingURL=logs.js.map