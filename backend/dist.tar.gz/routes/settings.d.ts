declare const router: import("express-serve-static-core").Router;
export declare function authenticateApiKey(apiKey: string): Promise<{
    userId: string;
    email: string;
} | null>;
export { router as settingsRoutes };
//# sourceMappingURL=settings.d.ts.map