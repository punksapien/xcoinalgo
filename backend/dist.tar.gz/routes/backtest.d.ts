declare const router: import("express-serve-static-core").Router;
export { router as backtestRoutes };
//# sourceMappingURL=backtest.d.ts.map