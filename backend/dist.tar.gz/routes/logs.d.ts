declare const router: import("express-serve-static-core").Router;
export { router as logsRoutes };
//# sourceMappingURL=logs.d.ts.map