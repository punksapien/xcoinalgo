"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsRoutes = void 0;
exports.authenticateApiKey = authenticateApiKey;
const express_1 = require("express");
const bcrypt_1 = __importDefault(require("bcrypt"));
const crypto_1 = __importDefault(require("crypto"));
const database_1 = __importDefault(require("../utils/database"));
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
exports.settingsRoutes = router;
function generateApiKey() {
    const randomBytes = crypto_1.default.randomBytes(32).toString('hex');
    return `xcoin_${randomBytes}`;
}
function getKeyPrefix(apiKey) {
    return apiKey.substring(0, 12);
}
router.post('/api-keys', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { name } = req.body;
        if (!name || typeof name !== 'string' || name.trim().length === 0) {
            return res.status(400).json({
                error: 'API key name is required'
            });
        }
        if (name.length > 100) {
            return res.status(400).json({
                error: 'API key name must be less than 100 characters'
            });
        }
        const apiKey = generateApiKey();
        const keyPrefix = getKeyPrefix(apiKey);
        const saltRounds = 12;
        const keyHash = await bcrypt_1.default.hash(apiKey, saltRounds);
        const newApiKey = await database_1.default.apiKey.create({
            data: {
                userId,
                name: name.trim(),
                keyHash,
                keyPrefix,
            },
            select: {
                id: true,
                name: true,
                keyPrefix: true,
                createdAt: true,
                lastUsedAt: true,
                expiresAt: true,
            }
        });
        res.status(201).json({
            message: 'API key created successfully',
            apiKey,
            keyInfo: newApiKey
        });
    }
    catch (error) {
        console.error('Error creating API key:', error);
        next(error);
    }
});
router.get('/api-keys', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const apiKeys = await database_1.default.apiKey.findMany({
            where: {
                userId,
                isActive: true
            },
            select: {
                id: true,
                name: true,
                keyPrefix: true,
                createdAt: true,
                lastUsedAt: true,
                expiresAt: true,
                isActive: true,
            },
            orderBy: {
                createdAt: 'desc'
            }
        });
        res.json({
            apiKeys
        });
    }
    catch (error) {
        console.error('Error fetching API keys:', error);
        next(error);
    }
});
router.delete('/api-keys/:id', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { id } = req.params;
        if (!id) {
            return res.status(400).json({
                error: 'API key ID is required'
            });
        }
        const apiKey = await database_1.default.apiKey.findFirst({
            where: {
                id,
                userId
            }
        });
        if (!apiKey) {
            return res.status(404).json({
                error: 'API key not found'
            });
        }
        await database_1.default.apiKey.update({
            where: { id },
            data: {
                isActive: false,
                updatedAt: new Date()
            }
        });
        res.json({
            message: 'API key revoked successfully'
        });
    }
    catch (error) {
        console.error('Error revoking API key:', error);
        next(error);
    }
});
async function authenticateApiKey(apiKey) {
    try {
        if (!apiKey.startsWith('xcoin_')) {
            return null;
        }
        const keyPrefix = getKeyPrefix(apiKey);
        const apiKeys = await database_1.default.apiKey.findMany({
            where: {
                keyPrefix,
                isActive: true
            },
            include: {
                user: {
                    select: {
                        id: true,
                        email: true
                    }
                }
            }
        });
        for (const key of apiKeys) {
            const isMatch = await bcrypt_1.default.compare(apiKey, key.keyHash);
            if (isMatch) {
                database_1.default.apiKey.update({
                    where: { id: key.id },
                    data: { lastUsedAt: new Date() }
                }).catch(err => console.error('Error updating lastUsedAt:', err));
                return {
                    userId: key.user.id,
                    email: key.user.email
                };
            }
        }
        return null;
    }
    catch (error) {
        console.error('Error authenticating API key:', error);
        return null;
    }
}
//# sourceMappingURL=settings.js.map