"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.botRoutes = void 0;
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = __importDefault(require("../utils/database"));
const strategyExecutor_1 = require("../services/strategyExecutor");
const client_1 = require("@prisma/client");
const router = (0, express_1.Router)();
exports.botRoutes = router;
router.post('/start', auth_1.authenticate, async (req, res, next) => {
    try {
        const { strategyId, leverage = 10, riskPerTrade = 0.005, marginCurrency = 'USDT', executionInterval = 300 } = req.body;
        const userId = req.userId;
        if (!strategyId) {
            return res.status(400).json({
                error: 'Strategy ID is required'
            });
        }
        const strategy = await database_1.default.strategy.findUnique({
            where: { id: strategyId }
        });
        if (!strategy || !strategy.isActive) {
            return res.status(404).json({
                error: 'Strategy not found or not active'
            });
        }
        const brokerCredential = await database_1.default.brokerCredential.findUnique({
            where: {
                userId_brokerName: {
                    userId,
                    brokerName: 'coindcx'
                }
            }
        });
        if (!brokerCredential || !brokerCredential.isActive) {
            return res.status(400).json({
                error: 'CoinDCX credentials not found. Please set up your broker connection first.'
            });
        }
        const existingDeployment = await database_1.default.botDeployment.findUnique({
            where: {
                userId_strategyId: {
                    userId,
                    strategyId
                }
            }
        });
        if (existingDeployment && existingDeployment.status !== client_1.BotStatus.STOPPED) {
            return res.status(400).json({
                error: 'You already have this strategy deployed. Stop the existing deployment first.'
            });
        }
        const deployment = await database_1.default.botDeployment.upsert({
            where: {
                userId_strategyId: {
                    userId,
                    strategyId
                }
            },
            update: {
                status: client_1.BotStatus.DEPLOYING,
                leverage,
                riskPerTrade,
                marginCurrency,
                executionInterval,
                deployedAt: new Date(),
                errorMessage: null
            },
            create: {
                userId,
                strategyId,
                status: client_1.BotStatus.DEPLOYING,
                leverage,
                riskPerTrade,
                marginCurrency,
                executionInterval
            },
            include: {
                strategy: {
                    select: {
                        name: true,
                        code: true
                    }
                }
            }
        });
        await database_1.default.strategy.update({
            where: { id: strategyId },
            data: {
                deploymentCount: { increment: 1 }
            }
        });
        try {
            const result = await strategyExecutor_1.strategyExecutor.deployStrategy(deployment.id);
            res.json({
                message: 'Bot started successfully',
                deployment: {
                    id: deployment.id,
                    strategyName: deployment.strategy.name,
                    strategyCode: deployment.strategy.code,
                    status: client_1.BotStatus.ACTIVE,
                    strategyId: result.strategy_id,
                    executionInterval,
                    deployedAt: deployment.deployedAt
                }
            });
        }
        catch (deployError) {
            await database_1.default.botDeployment.update({
                where: { id: deployment.id },
                data: {
                    status: client_1.BotStatus.ERROR,
                    errorMessage: deployError instanceof Error ? deployError.message : 'Deployment failed'
                }
            });
            return res.status(500).json({
                error: 'Failed to start bot',
                details: deployError instanceof Error ? deployError.message : 'Unknown error'
            });
        }
    }
    catch (error) {
        next(error);
    }
});
router.post('/stop', auth_1.authenticate, async (req, res, next) => {
    try {
        const { deploymentId } = req.body;
        const userId = req.userId;
        if (!deploymentId) {
            return res.status(400).json({
                error: 'Deployment ID is required'
            });
        }
        const deployment = await database_1.default.botDeployment.findFirst({
            where: {
                id: deploymentId,
                userId
            },
            include: {
                strategy: {
                    select: {
                        name: true,
                        code: true
                    }
                }
            }
        });
        if (!deployment) {
            return res.status(404).json({
                error: 'Bot deployment not found'
            });
        }
        if (deployment.status === client_1.BotStatus.STOPPED) {
            return res.status(400).json({
                error: 'Bot is already stopped'
            });
        }
        try {
            await strategyExecutor_1.strategyExecutor.stopStrategy(deployment.id);
            res.json({
                message: 'Bot stopped successfully',
                deployment: {
                    id: deployment.id,
                    strategyName: deployment.strategy.name,
                    strategyCode: deployment.strategy.code,
                    status: client_1.BotStatus.STOPPED,
                    stoppedAt: new Date()
                }
            });
        }
        catch (stopError) {
            return res.status(500).json({
                error: 'Failed to stop bot',
                details: stopError instanceof Error ? stopError.message : 'Unknown error'
            });
        }
    }
    catch (error) {
        next(error);
    }
});
router.get('/deployments', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { status, page = 1, limit = 10 } = req.query;
        const skip = (Number(page) - 1) * Number(limit);
        const whereConditions = { userId };
        if (status) {
            whereConditions.status = status;
        }
        const deployments = await database_1.default.botDeployment.findMany({
            where: whereConditions,
            include: {
                strategy: {
                    select: {
                        name: true,
                        code: true,
                        author: true,
                        instrument: true
                    }
                }
            },
            orderBy: {
                deployedAt: 'desc'
            },
            skip,
            take: Number(limit)
        });
        const deploymentsWithStats = await Promise.all(deployments.map(async (deployment) => {
            let executionStats = null;
            if (deployment.status === client_1.BotStatus.ACTIVE || deployment.status === client_1.BotStatus.STARTING) {
                executionStats = await strategyExecutor_1.strategyExecutor.getStrategyStatus(deployment.id);
            }
            return {
                ...deployment,
                executionStats
            };
        }));
        const total = await database_1.default.botDeployment.count({
            where: whereConditions
        });
        res.json({
            deployments: deploymentsWithStats,
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                totalPages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        next(error);
    }
});
router.get('/deployments/:id', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id } = req.params;
        const userId = req.userId;
        const deployment = await database_1.default.botDeployment.findFirst({
            where: {
                id,
                userId
            },
            include: {
                strategy: true
            }
        });
        if (!deployment) {
            return res.status(404).json({
                error: 'Bot deployment not found'
            });
        }
        let executionStats = null;
        if (deployment.status === client_1.BotStatus.ACTIVE || deployment.status === client_1.BotStatus.STARTING) {
            executionStats = await strategyExecutor_1.strategyExecutor.getStrategyStatus(deployment.id);
        }
        res.json({
            deployment: {
                ...deployment,
                executionStats
            }
        });
    }
    catch (error) {
        next(error);
    }
});
router.delete('/deployments/:id', auth_1.authenticate, async (req, res, next) => {
    try {
        const { id } = req.params;
        const userId = req.userId;
        const deployment = await database_1.default.botDeployment.findFirst({
            where: {
                id,
                userId
            }
        });
        if (!deployment) {
            return res.status(404).json({
                error: 'Bot deployment not found'
            });
        }
        if (deployment.status !== client_1.BotStatus.STOPPED && deployment.status !== client_1.BotStatus.ERROR) {
            return res.status(400).json({
                error: 'Cannot delete active deployment. Stop the bot first.'
            });
        }
        await database_1.default.botDeployment.delete({
            where: { id }
        });
        res.json({
            message: 'Bot deployment deleted successfully'
        });
    }
    catch (error) {
        next(error);
    }
});
router.post('/heartbeat', async (req, res) => {
    try {
        const { deploymentId, status, metadata } = req.body;
        if (!deploymentId) {
            return res.status(400).json({
                error: 'Deployment ID is required'
            });
        }
        await database_1.default.botDeployment.update({
            where: { id: deploymentId },
            data: {
                lastHeartbeat: new Date(),
                ...(status && { status })
            }
        });
        if (metadata) {
            await database_1.default.processLog.create({
                data: {
                    botDeploymentId: deploymentId,
                    level: 'INFO',
                    message: 'Heartbeat received',
                    metadata
                }
            });
        }
        res.json({ success: true });
    }
    catch (error) {
        console.error('Heartbeat error:', error);
        res.status(500).json({
            error: 'Failed to process heartbeat'
        });
    }
});
//# sourceMappingURL=bot.js.map