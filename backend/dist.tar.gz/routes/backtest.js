"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.backtestRoutes = void 0;
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const backtest_engine_1 = require("../services/backtest-engine");
const backtest_engine_2 = require("../services/backtest-engine");
const logger_1 = require("../utils/logger");
const logger = new logger_1.Logger('BacktestRoutes');
const router = (0, express_1.Router)();
exports.backtestRoutes = router;
router.post('/run', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { strategyId, symbol, resolution, startDate, endDate, initialCapital = 10000, riskPerTrade = 0.02, leverage = 1, commission = 0.001, } = req.body;
        if (!strategyId || !symbol || !resolution || !startDate || !endDate) {
            return res.status(400).json({
                error: 'Missing required fields: strategyId, symbol, resolution, startDate, endDate',
            });
        }
        const start = new Date(startDate);
        const end = new Date(endDate);
        if (isNaN(start.getTime()) || isNaN(end.getTime())) {
            return res.status(400).json({
                error: 'Invalid date format',
            });
        }
        if (start >= end) {
            return res.status(400).json({
                error: 'Start date must be before end date',
            });
        }
        const { default: prisma } = await Promise.resolve().then(() => __importStar(require('../utils/database')));
        const strategy = await prisma.strategy.findUnique({
            where: { id: strategyId },
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found',
            });
        }
        logger.info(`Starting backtest for strategy ${strategyId} by user ${userId}`);
        const result = await backtest_engine_1.backtestEngine.runBacktest({
            strategyId,
            symbol,
            resolution,
            startDate: start,
            endDate: end,
            initialCapital,
            riskPerTrade,
            leverage,
            commission,
        });
        res.json({
            success: true,
            result: {
                metrics: result.metrics,
                totalTrades: result.trades.length,
                executionTime: result.executionTime,
                equityCurve: result.equityCurve.slice(-100),
                recentTrades: result.trades.slice(-20),
            },
        });
    }
    catch (error) {
        logger.error('Backtest failed:', error);
        next(error);
    }
});
router.get('/status/:strategyId', auth_1.authenticate, async (req, res, next) => {
    try {
        const { strategyId } = req.params;
        const { default: prisma } = await Promise.resolve().then(() => __importStar(require('../utils/database')));
        const exists = await prisma.strategy.findUnique({ where: { id: strategyId }, select: { id: true } });
        if (!exists) {
            return res.status(404).json({ error: 'Strategy not found' });
        }
        const status = (0, backtest_engine_2.getBacktestStatus)(strategyId);
        res.json({ status });
    }
    catch (error) {
        next(error);
    }
});
router.get('/history/:strategyId', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { strategyId } = req.params;
        const { limit = 10 } = req.query;
        const { default: prisma } = await Promise.resolve().then(() => __importStar(require('../utils/database')));
        const strategy = await prisma.strategy.findUnique({
            where: { id: strategyId },
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found',
            });
        }
        const results = await backtest_engine_1.backtestEngine.getBacktestResults(strategyId, Number(limit));
        res.json({
            results: results.map(result => ({
                id: result.id,
                createdAt: result.createdAt,
                startDate: result.startDate,
                endDate: result.endDate,
                totalReturn: result.totalReturn,
                totalReturnPct: result.totalReturnPct,
                winRate: result.winRate,
                totalTrades: result.totalTrades,
                backtestDuration: result.backtestDuration,
            })),
        });
    }
    catch (error) {
        logger.error('Failed to fetch backtest history:', error);
        next(error);
    }
});
router.get('/result/:backtestId', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { backtestId } = req.params;
        const { default: prisma } = await Promise.resolve().then(() => __importStar(require('../utils/database')));
        const result = await prisma.backtestResult.findUnique({
            where: { id: backtestId },
            include: {
                strategy: {
                    select: {
                        name: true,
                        code: true,
                    },
                },
            },
        });
        if (!result) {
            return res.status(404).json({
                error: 'Backtest result not found',
            });
        }
        res.json({
            result: {
                id: result.id,
                createdAt: result.createdAt,
                startDate: result.startDate,
                endDate: result.endDate,
                initialBalance: result.initialBalance,
                finalBalance: result.finalBalance,
                totalReturn: result.totalReturn,
                totalReturnPct: result.totalReturnPct,
                maxDrawdown: result.maxDrawdown,
                sharpeRatio: result.sharpeRatio,
                winRate: result.winRate,
                profitFactor: result.profitFactor,
                totalTrades: result.totalTrades,
                tradeHistory: result.tradeHistory,
                equityCurve: result.equityCurve,
                monthlyReturns: result.monthlyReturns,
                backtestDuration: result.backtestDuration,
                strategy: {
                    name: result.strategy.name,
                    code: result.strategy.code,
                },
            },
        });
    }
    catch (error) {
        logger.error('Failed to fetch backtest result:', error);
        next(error);
    }
});
router.get('/latest/:strategyId', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { strategyId } = req.params;
        const { default: prisma } = await Promise.resolve().then(() => __importStar(require('../utils/database')));
        const strategy = await prisma.strategy.findUnique({
            where: { id: strategyId },
        });
        if (!strategy) {
            return res.status(404).json({
                error: 'Strategy not found',
            });
        }
        const result = await backtest_engine_1.backtestEngine.getLatestBacktestResult(strategyId);
        if (!result) {
            return res.json({
                result: null,
                message: 'No backtest results found for this strategy',
            });
        }
        res.json({
            result: {
                id: result.id,
                createdAt: result.createdAt,
                startDate: result.startDate,
                endDate: result.endDate,
                totalReturn: result.totalReturn,
                totalReturnPct: result.totalReturnPct,
                winRate: result.winRate,
                totalTrades: result.totalTrades,
                backtestDuration: result.backtestDuration,
                tradeCount: result.tradeHistory.length,
            },
        });
    }
    catch (error) {
        logger.error('Failed to fetch latest backtest result:', error);
        next(error);
    }
});
router.delete('/result/:backtestId', auth_1.authenticate, async (req, res, next) => {
    try {
        const userId = req.userId;
        const { backtestId } = req.params;
        const { default: prisma } = await Promise.resolve().then(() => __importStar(require('../utils/database')));
        const result = await prisma.backtestResult.findUnique({
            where: { id: backtestId },
            include: {
                strategy: {
                    select: {
                        name: true,
                    },
                },
            },
        });
        if (!result) {
            return res.status(404).json({
                error: 'Backtest result not found',
            });
        }
        await prisma.backtestResult.delete({
            where: { id: backtestId },
        });
        res.json({
            success: true,
            message: 'Backtest result deleted',
        });
    }
    catch (error) {
        logger.error('Failed to delete backtest result:', error);
        next(error);
    }
});
//# sourceMappingURL=backtest.js.map