"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const passport_1 = __importDefault(require("passport"));
const passport_google_oauth20_1 = require("passport-google-oauth20");
const database_1 = __importDefault(require("../utils/database"));
const simple_jwt_1 = require("../utils/simple-jwt");
passport_1.default.serializeUser((user, done) => {
    done(null, user.id);
});
passport_1.default.deserializeUser(async (id, done) => {
    try {
        const user = await database_1.default.user.findUnique({
            where: { id },
            select: {
                id: true,
                email: true,
                createdAt: true,
                updatedAt: true
            }
        });
        done(null, user);
    }
    catch (error) {
        done(error, null);
    }
});
passport_1.default.use(new passport_google_oauth20_1.Strategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: `${process.env.BACKEND_URL || 'http://localhost:3001'}/api/auth/google/callback`
}, async (accessToken, refreshToken, profile, done) => {
    try {
        const email = profile.emails?.[0]?.value;
        if (!email) {
            return done(new Error('No email found in Google profile'), null);
        }
        let user = await database_1.default.user.findUnique({
            where: { email }
        });
        if (!user) {
            user = await database_1.default.user.create({
                data: {
                    email,
                    password: 'google-oauth-' + Date.now()
                }
            });
        }
        const token = (0, simple_jwt_1.generateToken)({
            userId: user.id,
            email: user.email
        });
        const userWithToken = {
            ...user,
            token
        };
        return done(null, userWithToken);
    }
    catch (error) {
        console.error('Google OAuth Error:', error);
        return done(error, null);
    }
}));
exports.default = passport_1.default;
//# sourceMappingURL=passport.js.map