import passport from 'passport';
export default passport;
//# sourceMappingURL=passport.d.ts.map