"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticate = authenticate;
const simple_jwt_1 = require("../utils/simple-jwt");
async function authenticate(req, res, next) {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                error: 'Access token is missing or invalid'
            });
        }
        const token = authHeader.substring(7);
        if (token.startsWith('xcoin_')) {
            const { authenticateApiKey } = await Promise.resolve().then(() => __importStar(require('../routes/settings')));
            const user = await authenticateApiKey(token);
            if (!user) {
                return res.status(401).json({
                    error: 'Invalid API key'
                });
            }
            req.userId = user.userId;
            next();
        }
        else {
            const decoded = (0, simple_jwt_1.verifyToken)(token);
            req.userId = decoded.userId;
            next();
        }
    }
    catch (error) {
        return res.status(401).json({
            error: 'Invalid or expired authentication token'
        });
    }
}
//# sourceMappingURL=auth.js.map